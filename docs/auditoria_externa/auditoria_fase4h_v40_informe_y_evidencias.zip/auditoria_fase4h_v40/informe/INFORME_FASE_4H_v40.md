# Auditoría 4H: revisión acotada de v38 a v40

## Dictamen

**Cálculo y presentación de la variante: CONFORMES. Para la v40 exactamente entregada: CONFORME CON UNA RESERVA PUNTUAL DE REDACCIÓN.** El CONFORME de la v38 / `acb66ef` permanece intacto. La única corrección necesaria surgida de este delta está en la línea 427 de la v40: atribuir al jurado la respuesta a la independencia de la clasificación excede lo que hizo. La sustitución propuesta en el apartado 5 cierra esta reserva sin modificar ni repetir ningún cálculo.

No se reabren las condiciones cerradas en 4G. No se revisa el artículo II. Tampoco se certifican las nuevas propuestas filológicas de la Monografía IV: se comprueba el efecto cuantitativo de la clasificación declarada por su autor.

## 1. Material, integridad y alcance

Paquete recibido: `revision_v40_delta.zip`, SHA-256 **f2566049a37584e6740aa8d7b3a154c123550ab054710d0c756ce6613fa5d172**. Coincide con el comunicado y contiene siete archivos. La v40 tiene SHA-256 **4da4b5cb7945c0ff86c7709fcdfb9f667831f64a2ed380f4b379c0e4cdb1ec91**.

Se recuperó la v38 exacta entregada en 4G y se aplicó el diff incluido en la petición: reproduce la v40 **byte a byte**, sin conflictos ni tolerancia de contexto. Los cambios efectivos son la cabecera, tres filas de variantes en 8.4, el párrafo de procedencia, el punto 3 de las conclusiones, las dos siglas y su nota de errata, y las anotaciones de D.3. Fuera de esos bloques el texto coincide con la v38. La referencia de la cabecera al «punto 3 de la síntesis» corresponde, en el diff efectivo, al punto 3 de las conclusiones (§12).

Se reconstruyó el clon hasta `acb66ef10773066685a24819f49d2d7f560a284f` con los bundles ya recibidos. El parche documental nuevo se aplica a ese estado sin conflictos. Se añadió t31 tal como fue entregado, sin modificarlo; los **36 programas Python anteriores** permanecen idénticos al estado aprobado. No se ejecutó el resto de la batería inalterada.

Evidencia: [integridad.json](../evidencias/integridad.json), [diff verificado](../evidencias/diff_verificado_v38_v40.patch), [matriz del delta](../evidencias/delta_articulo.json).

### Límite de la comprobación cronológica

El paquete contiene el texto de la declaración 16, la nota de resultado y los identificadores `2694d28` y `da4b512`; **no contiene un bundle nuevo ni los objetos de esos commits**. Los bundles previos llegan a `acb66ef`, y tampoco contienen `6092368` o `b20d621`. Por tanto, esta revisión verifica el contenido de la declaración y su concordancia con el cálculo, pero **no verifica independientemente la anterioridad en el grafo Git de los dos commits nuevos**. Las horas 23:05 y 23:20 son las consignadas en el documento, no horas de Git comprobadas aquí.

Esto no invalida el cálculo ni retira la verificación histórica realizada en las fases anteriores; delimita qué puede acreditarse con este delta. Para documentar además esa precedencia haría falta un incremental que incluya los nuevos objetos. No se presenta la variante como confirmación independiente: se formuló después de conocer los resultados principales y utiliza los mismos datos.

## 2. Errata de D.2

**Corregida correctamente.** En la v40, líneas **861 y 875**, A16 (*akari*) y A30 (*ekiar/egiar*) remiten a **B.11.01**. La nota de la línea **877** conserva el historial de la errata.

Se contrastó contra los CSV de Hesperia entregados en 4b, cuyos hashes coinciden con los exigidos por el descargador del repositorio aprobado. B.10.01 es L’Aubreda y su texto no contiene esas formas; B.11.01 es La Joncosa, Jorba, y el texto contiene *akari* y *ekiarḿi*. No se hizo una nueva consulta a Hesperia ni una nueva validación filológica del texto.

La corrección es de una referencia descriptiva del artículo. No altera formas, glosas, diccionarios ni cálculos. Para máxima precisión, en la nota y en `ERRATAS.md` puede decirse «ningún programa lee esta columna del anexo» en vez de «ningún programa usa estas siglas»: algunos programas sí leen siglas del corpus para otros fines. Es una precisión editorial, no una incidencia numérica.

Evidencia: [cotejo del corpus y hashes](../evidencias/errata_hesperia.json).

## 3. Declaración e implementación de t31

La declaración 16 identifica las tres unidades, mantiene su clase de obtención (a), distingue A17 de nivel I de A7/A18 de nivel II, fija los tres grupos, conserva los 500 sorteos y exige reproducir las cifras anteriores. También explicita previsiones y el compromiso de publicar la variante sin sustituir el análisis principal. Su contenido es suficiente para reconstruir esta sensibilidad.

`t31_reclasificacion_m4.py:12–39` cumple ese diseño. Solo A7 y A18 pasan al subgrupo de nivel II con paralelo; **A17 no se traslada de I a II ni se retira de los análisis anteriores**. El grado C de la correspondencia propuesta no es un cambio al nivel III de procedencia. Los grupos nominales cambian de 6/13/9 a 8/11/7. Se conserva la selección inicial de lenguas con al menos 12 de las 30 unidades y, dentro de cada grupo, el mínimo de cuatro unidades comparables y un z definido.

No se agregan nuevas formas candidatas como *baserri* o *jaun*, no se cambian los significados ni se introducen etimologías en la medida. Cambia únicamente la pertenencia a esos subgrupos. Reutilizar las funciones y claves de t15 permite atribuir las diferencias al cambio de composición y no a otra semilla.

### Ejecución y cotejo independiente

Se ejecutó t31 íntegramente mediante `runpy`, sin alterar su código, guardando las tablas generadas para un segundo cálculo. **JSON y log coinciden byte a byte con los entregados.** Una implementación separada de la agregación y del z, sin importar t15, t31 ni su función `_z`, reproduce los **42 campos de resumen**. Esta segunda comprobación comparte las matrices generadas por t15: no es una réplica independiente del lector, la distancia o los sorteos. Los tres grupos originales coinciden también con el JSON de t15 de la versión aprobada.

| Clasificación | Grupo de nivel II | Nominal / comparables en euskera | z euskera | Puesto | Mejor otra lengua | z otra | Lenguas comparadas |
|---|---|---:|---:|---:|---|---:|---:|
| Original | Con correspondencia señalada | 6 / 6 | −7,27 | 1 | Gallego | −2,83 | 25 |
| Original | Sin correspondencia señalada | 13 / 12 | −4,43 | 1 | Tagalo | −4,25 | 32 |
| Original | Sin correspondencia y sin cuatro préstamos propuestos | 9 / 8 | −3,15 | 1 | Albanés | −2,41 | 31 |
| Reclasificada | Con correspondencia señalada | 8 / 8 | −8,17 | 1 | Gallego | −3,08 | 28 |
| Reclasificada | Sin correspondencia señalada | 11 / 10 | −3,44 | 2 | Tagalo | −4,56 | 31 |
| Reclasificada | Sin correspondencia y sin cuatro préstamos propuestos | 7 / 6 | −1,85 | 2 | Hawaiano | −1,95 | 29 |

Las tres filas nuevas del artículo (líneas **416–418**) y su descripción (líneas **427 y 669**) concuerdan con estas salidas. No se oculta la pérdida del primer puesto.

La previsión del grupo con correspondencias se cumple: primero y z ≤ −5. En el grupo sin correspondencias, la diferencia absoluta con la mejor otra lengua es **1,1122226908**, inferior al umbral descriptivo registrado de 1,5, aunque el euskera queda por detrás. En el último grupo la diferencia es **0,1016165328**. Esos umbrales no son contrastes de igualdad entre lenguas. La comparación no produce una nueva prueba de independencia semántica ni una probabilidad histórica.

### Semilla y entorno

**Python 3.13.5; NumPy 2.3.5.** Generador `random.Random` (Mersenne Twister), inicialización de cadena versión 2. Semilla base **20261120**; cadena por diccionario **`20261120|solidez|plomos|<nombre>`**, por ejemplo **`20261120|solidez|plomos|Basque`**. Son las mismas claves de t15; no se usa `np.random` en este cálculo. Quinientos sorteos conjuntos por diccionario, sin reposición dentro de cada longitud y conservando las candidatas compartidas. Ordenación con z sin redondear; presentación a dos decimales.

Evidencias: [salida JSON](../salidas/t31_reclasificacion_m4.json), [log](../salidas/t31_reclasificacion_m4.log), [cotejo independiente](../evidencias/cotejo_independiente.json), [comprobación contra t15](../evidencias/cotejo_original_v38.json), [semillas](../evidencias/semillas.json), [hashes de entradas y dependencias](../evidencias/manifest_entradas.json).

## 4. La variante y el análisis principal

Es correcto conservar la clasificación registrada antes de los resultados como análisis principal y publicar la reclasificación posterior como sensibilidad explícitamente fechada. La nueva tabla no se usa para reemplazar resultados menos favorables ni para fingir que el subgrupo original tenía otra composición.

Los resultados describen dónde se concentra la señal cuando el autor identifica paralelos. Como la etiqueta «con correspondencia» depende parcialmente del parecido, esa concentración **no es evidencia independiente que resuelva la circularidad**. La declaración 16 lo reconoce correctamente. Los niveles I/II/III y el análisis global no cambian por esta división interna. No se ha vuelto a calcular la batería global porque esta reclasificación no modifica sus entradas.

La edición final de la Monografía IV no está entre los siete archivos de esta entrega. Se audita la clasificación declarada y su efecto, no la validez de *baśir–baserri*, *kutu–gutun* o *iunstir–jaun*.

## 5. Única corrección necesaria para extender el CONFORME sin reservas

**Archivo:** `BORRADOR_v40_articulo_estadistica_2026-11-21.md`, **línea 427**, §8.4. La frase nueva termina así:

> «…indica dónde está el parecido, no si la clasificación es independiente; esa pregunta la responde el jurado ciego».

La última proposición es excesiva. El jurado recodificó fichas redactadas por el autor; no verificó las fuentes ni certificó la independencia histórica de las glosas. La propia v40 lo explica correctamente en las líneas 429 y 431. La frase nueva no debe atribuirle más que esos párrafos.

**Sustitución propuesta del tramo completo:**

> Como esa división depende en parte del propio parecido con el euskera, indica dónde se concentra el parecido, no si la clasificación es independiente. El jurado ciego aporta una segunda codificación de las fichas, descrita a continuación; no verifica las fuentes ni certifica la independencia histórica de cada glosa.

No requiere cambiar programas, cifras, grupos ni semillas. Tampoco exige un jurado nuevo. Corregido ese tramo, no queda una objeción material surgida de los cambios examinados que impida mantener el CONFORME.

## 6. Precisiones no bloqueantes

**Nombre del comparador de t31.** En `t31_reclasificacion_m4.py:32–34`, `siguiente` significa «mejor lengua distinta del euskera», no necesariamente la situada inmediatamente después de él. En las dos últimas filas es la primera lengua, por delante del euskera. El artículo la presenta bien. Se recomienda aclarar esa semántica en §4.28 de la especificación o renombrar la clave como `mejor_otra_lengua`, sin alterar cifras. No es un fallo del ranking.

**Anclaje de la clasificación original.** En la línea 427, después de describir los grupos nuevos, la frase conservada sobre «las seis de nivel II» se refiere a la clasificación original. Añadir «en la clasificación original» evita que parezca contradecir las ocho de la variante. La cabecera puede decir «punto 3 de las conclusiones» en lugar de «punto 3 de la síntesis» para identificar el cambio real.

Estas precisiones no son nuevas exigencias estadísticas. El único impedimento de redacción identificado para un CONFORME sin reservas de la v40 exacta es la atribución al jurado señalada en el apartado 5.

## 7. Conclusión acotada

La errata está respaldada por el corpus; t31 ejecuta la sensibilidad declarada y reproduce íntegramente sus salidas; los resultados desfavorables en los subgrupos restantes se publican y no sustituyen al análisis principal. No se detectan discrepancias numéricas en el delta. El CONFORME de v38 se mantiene. Para extenderlo sin reservas a v40, basta la sustitución puntual de §8.4 indicada arriba. La verificación cronológica de los nuevos commits queda limitada por no haberse entregado sus objetos Git, sin afectar al cotejo del contenido y los resultados realizado aquí.
