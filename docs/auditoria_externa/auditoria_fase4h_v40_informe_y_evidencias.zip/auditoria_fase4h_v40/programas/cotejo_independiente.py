"""Reagrupa las matrices regeneradas sin importar t15, t31 ni su función z.
Uso: python cotejo_independiente.py DIRECTORIO_AUDITORIA
"""
import argparse, json, math, statistics
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser();p.add_argument('base',type=Path); a=p.parse_args(); base=a.base
index=json.loads((base/'evidencias/indice_tablas.json').read_text())
f=np.load(base/'evidencias/tablas_t31.npz')
I={'A1','A2','A3','A17','A30'};III={'A24','A25','A26','A27','A28','A29'}
II={f'A{i}' for i in range(1,31)}-I-III
old={'A8','A10','A14','A15','A19','A20'};new=old|{'A7','A18'};lat={'A6','A9','A11','A13'}
res={}; expected=json.loads((base/'salidas/t31_reclasificacion_m4.json').read_text())
allchecks=[]
for version,P in [('original_v38',old),('reclasificada_m4_final',new)]:
 res[version]={}
 for label,G in [('nivel II con correspondencia vasca señalada después',P),('nivel II sin correspondencia señalada',II-P),('nivel II sin correspondencia señalada y sin los préstamos latinos',II-P-lat)]:
  values=[]
  for n,d in index.items():
   cols=[i for i,x in enumerate(d['ids']) if x in G]
   if len(cols)<4:continue
   real=statistics.fmean(float(f[f'real_{n}'][j]) for j in cols)
   null=[statistics.fmean(float(row[j]) for j in cols) for row in f[f'azar_{n}']]
   mu=statistics.fmean(null);sd=math.sqrt(statistics.fmean((x-mu)**2 for x in null))
   if max(null)-min(null)<=1e-12*max(1,max(map(abs,null))):continue
   values.append({'lengua':d['lengua'],'z':(real-mu)/sd,'comparables':len(cols),'real':real,'media_nula':mu,'sd_nula':sd})
  values.sort(key=lambda r:r['z']); eus=next(r for r in values if r['lengua']=='Basque'); rival=next(r for r in values if r['lengua']!='Basque')
  summary={'unidades_del_grupo':len(G),'comparables_con_el_euskera':eus['comparables'],'z_euskera':round(eus['z'],2),'puesto':values.index(eus)+1,'siguiente':rival['lengua'],'z_siguiente':round(rival['z'],2),'lenguas_comparadas':len(values)}
  checks={k: v==expected[version][label][k] for k,v in summary.items()}; allchecks.extend(checks.values())
  res[version][label]={'ids':sorted(G,key=lambda x:int(x[1:])), 'resumen':summary,'coincidencias':checks,'ranking_completo':values}
out={'campos_comprobados':len(allchecks),'campos_coincidentes':sum(allchecks),'todos_coinciden':all(allchecks),'resultados':res}
(base/'evidencias/cotejo_independiente.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
print('Campos',len(allchecks),'coincidentes',sum(allchecks))
