"""Ejecuta t31 sin cambiarlo y conserva sus tablas para el cotejo independiente.
Uso: python ejecutar_t31.py RUTA_REPOSITORIO DIRECTORIO_SALIDA
"""
from pathlib import Path
import argparse, json, runpy, time, platform, hashlib, traceback
import numpy as np
p=argparse.ArgumentParser(); p.add_argument('repo',type=Path); p.add_argument('salida',type=Path); a=p.parse_args()
a.salida.mkdir(parents=True,exist_ok=True)
script=a.repo/'4_programas/t31_reclasificacion_m4.py'
t0=time.time()
try:
    g=runpy.run_path(str(script),run_name='__main__')
    arrays={}; index={}
    for n,(lengua,(ids,real,azar)) in enumerate(g['T'].items()):
        index[str(n)]={'lengua':lengua,'ids':ids}
        arrays[f'real_{n}']=real; arrays[f'azar_{n}']=azar
    np.savez_compressed(a.salida/'tablas_t31.npz',**arrays)
    (a.salida/'indice_tablas.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')
    meta={'segundos':time.time()-t0,'python':platform.python_version(),'numpy':np.__version__,
          'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'lenguas':len(g['T']),'estado':'terminado'}
    (a.salida/'ejecucion.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
except Exception:
    (a.salida/'ejecucion.json').write_text(json.dumps({'estado':'error','traza':traceback.format_exc()},indent=2),encoding='utf-8')
    raise
