# Auditoría 4H, v40

Informe: `informe/INFORME_FASE_4H_v40.html` o `.md`.

`salidas/` contiene el JSON y log regenerados. `evidencias/` incluye hashes, el delta verificado, las matrices de t31, sus índices, semillas y cotejos. `fuentes_citadas/` conserva las fuentes con numeración de líneas.

## Repetición

Requiere Python 3 y NumPy. Entorno usado: Python 3.13.5, NumPy 2.3.5. En una copia del repositorio aprobado `acb66ef`, sitúe el programa t31 original entregado por el autor en `4_programas/t31_reclasificacion_m4.py`; no sustituya t15 ni ibcomp.

```sh
python programas/ejecutar_t31.py /ruta/al/repositorio /ruta/a/evidencias
```

La salida original se escribe en `resultados/t31_reclasificacion_m4.json` del repositorio. Para revalidar las matrices incluidas en este paquete:

```sh
python programas/cotejo_independiente.py /ruta/a/auditoria_fase4h_v40
```

Este último programa vuelve a agregar y ordenar sin usar la función z del estudio; comparte las matrices de la ejecución original, no rehace el lector ni las distancias. No contiene nuevas simulaciones.

Los datos lingüísticos grandes y el historial Git completo no se duplican en este ZIP. No se inspeccionó una nueva edición de la Monografía IV ni se verificó el grafo de los commits 2694d28 y da4b512, cuyos objetos no estaban en el delta recibido.
