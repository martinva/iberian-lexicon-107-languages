# El léxico de los plomos ibéricos ante 107 lenguas: una comparación estadística en la que el euskera ocupa el primer lugar

**Borrador v40 (21-11-2026).** Respecto a la v39: reclasificación posterior de tres unidades en la edición final de la Monografía IV (A7, A17, A18), declarada antes de recalcular (declaración 16) y añadida como variante en el apartado 8.4, el punto 3 de la síntesis y el anexo D.3; el análisis principal no cambia. **v39:** idéntico a la v38 (dictamen CONFORME, fase 4G) salvo una errata de sigla en el anexo D.2, corregida con nota (*akari* y *ekiar*: B.11.01, La Joncosa, en lugar de B.10.01). **v38:** respecto a la v37, correcciones de la sexta revisión de la auditoría (fase 4f): síntesis condicionada a los modelos nulos especificados; resumen del contacto restringido a las 17 parejas; encabezamiento de S1 sin «falsos positivos»; §8.4 con las siete previsiones, tres retornos y cuatro no retornos de la segunda pregunta del jurado, sin «grupo limpio»; §11.4 sin presentar la regularidad como discriminador suficiente; §11.6 precisando que los p cuentan préstamos de cualquier donante y que «no se detecta» no demuestra ausencia. Respecto a la v36 (v37), correcciones de la quinta revisión de la auditoría (fase 4e): t27 versión 2 (unión por lema elegible, donante desglosado, dos colas, fonotaxis fuera de muestra) y 11.6 reescrito; matriz de sustituciones en la síntesis y la tabla S1; fila «fuente latina o romance común» de 12.4e reescrita; frase de tipología retirada; controles de la segunda ronda del jurado corregidos (6/6, 5/6, 5/6). Respecto a la v35 (v36), correcciones de la cuarta revisión de la auditoría (fase 4d): tabla 12.4e reescrita sin exclusiones no probadas; 8.4 como sensibilidad a la codificación, con la subida de A5 y el balance de las cuatro previsiones; 11.4 (lituano 0,385, P:M, nulo condicional y sensibilidades de la auditoría); 11.5 («no se establece un gradiente concluyente»; desviación de protocolo anotada); 12.3; 8.4 tamaño de los diccionarios sin causalidad; horas de la tabla de trazabilidad corregidas. Respecto a la v34 (v35): prueba nueva declarada antes de ejecutar (entrada 11): origen etimológico y fonotaxis de las palabras vascas emparejadas (11.6, antes «Valoración conjunta», ahora 11.7); fila «contacto» de la tabla de explicaciones, tabla S1 y Anexo E; referencia Miller y otros 2020. Respecto a la v33 (v34): se añade la «Síntesis para lectura rápida» (nivel 1) con la guía de lectura en tres niveles, y la segunda pregunta del jurado ciego (declaración 10) en 8.4, tabla 10 bis y conclusiones. Respecto a la v32 (v33): (1) resultado del jurado ciego de procedencia (declaración 7): fila nueva en la tabla 10 bis, párrafo en «Procedencia y circularidad», conclusiones 3 y 4 y Anexo D.3; (2) correcciones de redacción pedidas por la tercera revisión de la auditoría (fase 4c): resumen, 7.2, 7.4, 8.1, 8.3, 8.4, 8.5, 9, 11.1, 12.2, 12.4, A.2 y F.3; (3) tabla de las explicaciones posibles en las conclusiones; (4) dos pruebas nuevas sobre herencia y préstamo, declaradas antes de ejecutar (entradas 8 y 9): regularidad de las correspondencias (11.4) y gradiente de prestabilidad (11.5). Cambios anteriores: v32, tamaño de los diccionarios; v31, calibración del perfil; v30, fila sin lecturas alternativas; v29, respuesta a la segunda revisión de la auditoría; v28, título definitivo; v27, variación entre semillas; v26, cifras con los programas corregidos. [PENDIENTE: títulos y DOI de las monografías; dirección del repositorio y DOI del depósito. Referencias Ferrer 2024 y Rix 1998 verificadas el 21-11-2026 en la fuente (ICAC/TRAMA 12; Lexicon Leponticum).]

Marcas de este borrador:
- **[PENDIENTE]**: falta el dato, el texto o una decisión.
- **[REF. POR VERIFICAR]**: referencia conocida solo por ficha o resumen; debe comprobarse en la fuente antes de citarla.
- **[A COTEJAR]**: dato tomado de una lectura parcial.

---

## Resumen

Se compara, mediante procedimientos matemáticos, un conjunto delimitado del léxico ibérico con el léxico de más de cien lenguas. El conjunto ibérico está formado por el léxico con soporte metrológico (serie numeral y unidades de medida) y por el vocabulario de los plomos de contenido económico. Los significados empleados son los propuestos en la bibliografía y en trabajos anteriores del autor, y se apoyan en la metrología, en la posición de las palabras en los asientos contables y en las casillas funcionales propias de la práctica documental grecolatina. Se aplican pruebas de dos tipos. La principal compara cada palabra ibérica con las palabras del mismo significado en diccionarios completos. La segunda prescinde del significado: compara el perfil de combinaciones de sonidos de todo el corpus ibérico con el de 107 lenguas (las 107 son las de esa base; la prueba con significados compara entre 4 y 34 diccionarios, según la fuente). Los datos, los formatos y parte de los instrumentos proceden de la lingüística comparada computacional desarrollada en los últimos años por J.-M. List y otros autores (clases de sonidos, bases léxicas normalizadas, pruebas de permutación). Los criterios se fijaron de antemano y se aplicaron por igual a todas las lenguas, y el método se contrastó con seis lenguas de control: cuatro de filiación conocida y dos sin parientes entre las lenguas comparadas. En la prueba con significados, que en los controles reconoce al pariente entre el 79 % y el 100 % de las veces, el euskera ocupa el primer lugar con todos los diccionarios, a gran distancia de la lengua siguiente, y conserva su posición al retirar los préstamos latinos propuestos, mientras las lenguas romances pierden la significación. Al permutar los significados entre las propias unidades, ninguna de 100.000 permutaciones iguala la asignación propuesta (probabilidad corregida por las 32 lenguas comparadas: 0,0003), y tampoco cuando los significados solo se intercambian entre unidades de la misma longitud. En la prueba sin significados, que en los controles reconoce la familia de cuatro de cada cinco lenguas, el euskera es también la lengua más próxima al ibérico entre 107. En seis lenguas de control, el vecino más próximo pertenece a la familia esperada en el 79-100 % de las muestras de las cuatro lenguas con parientes, y ninguna de 200 muestras de las dos sin parientes en la base alcanza los umbrales fijados a partir del caso ibérico; son dos medidas distintas, que no estiman una tasa general de falsos positivos ni la probabilidad de parentesco. La serie numeral ibérica tiene en el euskera su vecino más próximo entre más de 3.800 lenguas, a una distancia que, en esa muestra mundial, se da casi siempre entre lenguas de una misma familia. Las probabilidades son condicionales a la lista de unidades y de significados analizada. Se discuten las causas posibles de la afinidad (herencia común, préstamo) y lo que los datos permiten afirmar sobre cada una. En una segunda parte, menos concluyente por el corto número de significados disponibles, se examina de qué tipo es esa relación. Se compara la proximidad en los significados que rara vez se prestan con la proximidad en los que se prestan con facilidad, en el ibérico y en 42 parejas de lenguas de relación conocida: el reparto que presentan el ibérico y el euskera es el de las parejas emparentadas y no el de las que solo han tenido contacto. La proximidad al euskera es la misma en las cinco zonas del territorio ibérico, sin aumento hacia el norte. En 17 parejas de lenguas con préstamo léxico masivo, la lengua donante no es en ningún caso la de perfil más próximo; el dato es descriptivo y no excluye el contacto. La prueba etimológica no detecta un exceso de préstamos romances entre las palabras vascas emparejadas (2 de 31 con nota elegible, solo 1 de donante romance o latino), pero su control de recuperación solo se cumple en 1 de 4 casos y limita el alcance de esa ausencia. Son indicios: el patrón observado se parece al de las parejas emparentadas de la muestra, pero las pruebas no estiman la probabilidad relativa de herencia y contacto ni cubren todos los tipos de contacto, y no permiten establecer una preferencia firme entre las dos explicaciones.

**Palabras clave:** ibérico; euskera; plomos ibéricos; metrología; comparación léxica; prueba de permutación.

---

## Síntesis para lectura rápida

*Este apartado resume el trabajo entero en cuatro páginas, sin tecnicismos. Es el primer nivel de lectura. El segundo nivel (apartados 1 a 12) explica cada prueba, su justificación y sus límites; el tercero (anexos A a F y el repositorio) contiene el detalle que permite reproducir y comprobar cada cifra. Cada afirmación de esta síntesis remite al apartado donde se sostiene.*

### Qué se propone

Los plomos ibéricos de contenido económico contienen unas pocas decenas de palabras que se repiten en posiciones fijas: delante de cifras, entre nombres de persona y medidas, al cierre de las cuentas. En trabajos anteriores (Monografías I–IV) se propuso un significado para 30 de ellas a partir de esa posición, y se analizan además 10 valores numerales propuestos en la bibliografía: algunos tienen apoyo material externo (monedas, pesos) y otros se asignan por su posición en la serie. Este trabajo no propone ningún significado nuevo: toma esos 40 y hace una sola pregunta, con métodos de la lingüística comparada computacional: **¿a qué lengua se parecen más esas palabras, y es ese parecido mayor de lo que produciría el azar?** (apartado 1).

### Cómo se ha hecho

- **Dos pruebas independientes en sus supuestos.** La primera usa los significados: para cada palabra ibérica busca, en el diccionario completo de cada lengua, las palabras de ese mismo significado y mide cuánto se parecen; después repite la medida miles de veces con palabras tomadas al azar del mismo diccionario, para saber qué parecido se obtiene sin ninguna relación. La segunda prescinde de los significados: compara la manera de combinar los sonidos en todo el corpus ibérico (unas 1.600 inscripciones) con la de 107 lenguas de Eurasia (apartado 5).
- **Las mismas reglas para todas las lenguas.** Transcripción, clases de sonidos, medida de distancia y descuento del azar se fijaron por escrito antes de ejecutar cada prueba y se aplicaron igual al euskera, al latín, al húngaro o al tagalo (apartados 4 y 6).
- **Controles.** El método se probó con cuatro lenguas de filiación conocida (umbro, gótico, córnico, dálmata), para ver si reconoce al pariente, y con dos sin parientes en la base (etrusco, sumerio), para ver qué valores alcanza sin relación (apartado 8.3).
- **Declaración previa y comprobaciones posteriores identificadas.** Las pruebas añadidas después de la primera versión se registraron en el repositorio, con su previsión y con lo que contaría en contra, antes de correr el programa, y las comprobaciones añadidas tras ver un resultado se señalan como exploratorias; los resultados se publican sean cuales sean (apartado 9; `resultados/DECLARACIONES_PREVIAS.md`).
- **Revisión externa.** El código y las cifras pasaron tres rondas de auditoría independiente, con todas las correcciones en el historial; y la clasificación de la procedencia de cada significado la revisó un jurado ciego que no conocía ni los términos ni las lenguas (apartados 8.4 y 9).

### Qué se ha encontrado

**Tabla S1. Los resultados principales en una página**

| Pregunta | Resultado | Dónde |
|---|---|---|
| ¿Qué lengua queda primera en la prueba con significados? | El euskera, con los siete diccionarios probados (modernos, dialectal, clásico y reconstruido): entre −7,2 y −12,8 según la fuente (el azar da 0), frente a −4,3 de la siguiente (gallego) con el Wikcionario | Tabla 6; 7.2 |
| ¿Es más de lo que da el azar? | Ninguno de 20.000 sorteos de palabras (p corregida 0,0016) ni ninguna de 100.000 permutaciones de los significados (p corregida 0,00032) iguala la asignación propuesta | 8.5 |
| ¿Depende de unas pocas palabras? | No: se mantiene al quitar cualquiera; primero en 1.975 de 2.000 subconjuntos aleatorios de diez unidades; y hasta quitar 12 de las 28 más favorables | Tabla 10 bis; 8.4 |
| ¿Depende de las cuatro unidades propuestas como préstamos latinos? | No: sin las cuatro unidades propuestas como latinas el euskera conserva su valor y las lenguas romances pierden la significación | 8.1; 8.5 |
| ¿Depende de que el autor tuviera el euskera a la vista al proponer los significados? | El primer puesto persiste con las dos recodificaciones de un jurado ciego (las 11 unidades sin mención a una lengua viva dan −6,6 frente a −2,2; con la pregunta de suficiencia, −8,6 frente a −3,1); el sesgo no se cuantifica y la historia de cada glosa no se valida | 8.4; tabla 10 bis |
| ¿Y la prueba que no usa significados? | El euskera es la lengua más próxima entre 107 en todos los remuestreos; solo 5 de 4.618 parejas de familias distintas de la base están a una distancia igual o menor | Tabla 8; 7.4 |
| ¿Reconoce el método a los parientes y qué valores alcanza en los controles sin parientes? | Reconoce al pariente entre el 79 % y el 100 % de las veces; ninguna de 200 muestras de lenguas sin parientes alcanza los valores del ibérico con el euskera | Tabla 10 cuater; 8.3 |
| ¿Qué pasa con la serie numeral? | El euskera es su vecino más próximo entre 3.800 lenguas, a una distancia que en esa base se da casi siempre entre lenguas de la misma familia | Tabla 5; 7.1 |
| ¿Herencia o préstamo? | No se decide. El reparto entre significados estables y poco estables es el de las parejas emparentadas; no hay gradiente geográfico; en las 17 parejas examinadas la donante no es el vecino de perfil más próximo, lo que no excluye el contacto; las correspondencias son más regulares que el azar pero apenas más que las de otras lenguas; no se establece un gradiente concluyente de prestabilidad; la prueba etimológica no detecta un exceso de etiquetas de préstamo entre las palabras vascas emparejadas (2 de 31, 1 de donante romance o latino), lo que no excluye ni cuantifica una fuente común | 11; 12.4 |

### Qué no se afirma

Este trabajo **no** afirma que el ibérico y el euskera estén emparentados. Afirma que, con los significados propuestos y las reglas declaradas, el parecido entre ese léxico ibérico y el euskera es el mayor entre las lenguas comparadas; con las unidades, los significados y las reglas adoptados, la afinidad es extrema bajo los modelos nulos especificados y persiste en las comprobaciones de robustez realizadas. Las probabilidades son condicionales a la lista de palabras y de significados; los significados son propuestas, no hechos; y faltan los dos criterios que la lingüística histórica considera decisivos para un parentesco, la gramática compartida y un sistema de correspondencias regulares, que 40 palabras no permiten establecer (apartado 12).

### Cómo leer el resto y cómo comprobarlo

- **Nivel 2, el cuerpo (apartados 1 a 12).** Qué material se usa y por qué (3), cómo se mide (4), qué pruebas se hacen (5), qué lenguas y diccionarios (6), resultados (7), comprobaciones de solidez (8), reproducción (9), límites (10), tipo de relación (11) y conclusiones (12). Un lector sin formación estadística puede leer 3, 7 y 12 y consultar 8 solo donde tenga una objeción concreta.
- **Nivel 3, los anexos y el repositorio.** La medida de distancia (A), las pruebas estadísticas (B), las fuentes (C), las 40 palabras una a una con su procedencia (D), los programas (E) y el uso de los métodos de J.-M. List (F). El repositorio [PENDIENTE: dirección pública y DOI] contiene los datos, los programas, la especificación funcional (que permite reescribirlos desde cero), las declaraciones previas con su historial, las tres auditorías con sus hallazgos, las respuestas íntegras del jurado y una página interactiva en la que el lector puede quitar palabras de la lista y ver qué pasa con el resultado. Los 40 términos se publican también en formato CLDF validado, el estándar de las bases léxicas comparativas, y todo el cálculo puede ejecutarse en el navegador sin instalar nada [PENDIENTE: enlace a Colab].

---

## 1. Objeto del estudio

Las monografías I–IV proponen un significado para un conjunto de términos de los plomos ibéricos de contenido económico, a partir de su posición en los documentos y de su relación con cifras y unidades de medida. Propuesto ese léxico, el paso siguiente es comprobar si guarda relación con el de otras lenguas, y en primer lugar con las que le fueron vecinas en el tiempo y en el espacio: el euskera, en sus formas moderna, histórica y reconstruida, y el latín. Si la relación con alguna de ellas resulta más marcada que con las demás, queda por establecer de qué tipo es: préstamo, contacto prolongado u origen común. Este trabajo sigue ese orden.

La primera parte (apartados 3 a 10) mide la proximidad de un conjunto delimitado de palabras ibéricas al léxico de otras lenguas mediante dos pruebas matemáticas: una que tiene en cuenta los significados propuestos para esas palabras y otra puramente fonética, que prescinde de todo significado y compara la manera de combinar los sonidos. La segunda parte (apartado 11) examina qué tipo de relación explica mejor la que se observa.

Las lenguas de comparación se han elegido con dos criterios. Por cercanía histórica y geográfica se incluyen el euskera, en su forma moderna, en su documentación clásica y en sus reconstrucciones, y el latín y las lenguas romances. Como contraste se añaden lenguas más alejadas, hasta completar un repertorio de 107 lenguas de Eurasia en la prueba fonética y de varios miles de lenguas de todo el mundo en la comparación de la serie numeral.

Todos los criterios (delimitación del léxico, regla de medida, tratamiento de las grafías, forma de descontar el azar) se fijaron por escrito antes de ejecutar cada prueba y se aplicaron del mismo modo a todas las lenguas.

## 2. Antecedentes

**El léxico ibérico con significado propuesto.** La investigación de las últimas décadas ha delimitado un grupo de palabras ibéricas cuyo valor se apoya en hechos materiales y en paralelos con la práctica documental del mundo grecolatino: marcas de valor en monedas, pesos, indicaciones de capacidad, expresiones numerales y términos que designan predios y bienes en documentos de carácter económico (Orduña 2005; Ferrer i Jané 2009, 2022; Moncunill y Velaza 2019; Martín Valladolid 2026a-d; estado de la cuestión reciente en Orduña Aznar 2025). Ese grupo es el que aquí se somete a análisis.

**La comparación automática previa.** Luo y otros (2021) aplicaron al ibérico un modelo de desciframiento automático y lo compararon con seis lenguas (castellano, árabe, húngaro, turco, latín y euskera), sin hallar indicios sólidos de proximidad con ninguna. La razón es de método. El modelo trabaja sobre el corpus sin segmentar (3.466 secuencias de signos tomadas de Hesperia, cada una con un número desconocido de palabras) y debe resolver a la vez dónde empieza y acaba cada palabra y a qué palabra de la otra lengua corresponde. Para ello busca en el texto tramos de cuatro a diez signos que se parezcan a raíces de la lengua conocida, sin contar con ningún significado. En esas condiciones lo que se compara son segmentos breves y de límites inciertos, y esos segmentos encuentran parecidos en cualquier lengua (apartado 10). El presente trabajo parte, en cambio, de palabras ya delimitadas y, en una de las pruebas, de sus significados propuestos.

**Los métodos y los datos.** Las pruebas empleadas pertenecen a una tradición consolidada en lingüística histórica: la valoración estadística de listas de palabras mediante permutación o simulación (Ringe 1992; Kessler 2001; Ceolin 2019), el uso de clases de sonidos para comparar formas (Dolgopolsky 1986; Turchin y otros 2010) y la medición de distancias entre palabras (Wichmann y otros 2010; Jäger 2015). Se han aplicado a cuestiones semejantes a esta: el euskera y el indoeuropeo (Blevins y Sproat 2021), el sustrato pregriego (Kilani 2015), el indoeuropeo y el urálico, o el altaico (Kassian y otros 2021; Ceolin 2019). El trabajo se apoya además en la infraestructura creada por J.-M. List y sus colaboradores para la comparación léxica asistida por ordenador: el formato normalizado de datos CLDF y la colección Lexibank, de la que forma parte la base de 107 lenguas aquí empleada, y los métodos de comparación por clases de sonidos (List 2012; Forkel y otros 2018; List y otros 2022). Sin esos recursos, que ofrecen el mismo vocabulario con la misma transcripción para todas las lenguas, una comparación con controles como la presente no sería practicable. El funcionamiento de las pruebas, sus precedentes y su aceptación se detallan en el Anexo B.

## 3. El material ibérico

### 3.1 Representatividad del léxico empleado

El corpus ibérico reúne unas 1.600 inscripciones auténticas, en su mayoría muy breves. El texto continuo se concentra en los plomos.

**Tabla 1. Palabras por soporte**

| Soporte | Inscripciones | Palabras | Palabras distintas | Vocabulario distinto que no es nombre propio |
|---|---|---|---|---|
| Plomo | 143 | 1.171 (41 %) | 1.020 (45 %) | 388 (56 %) |
| Cerámica | 1.217 | 1.237 (44 %) | 848 (38 %) | 164 (24 %) |
| Piedra | 214 | 379 (13 %) | 339 (15 %) | 122 (18 %) |
| Otros | 25 | 41 (1 %) | 40 (2 %) | 13 (2 %) |
| Total | 1.599 | 2.828 | 2.095 en todo el corpus (2.247 sumando los soportes) | 679 en todo el corpus (687 sumando los soportes) |

*Los plomos son el 9 % de las inscripciones, pero reúnen el 41 % de las palabras, el 45 % de las palabras distintas y más de la mitad del vocabulario que no es nombre propio. Los porcentajes de las dos últimas columnas se calculan sobre la suma de los soportes (2.247 y 687); como una misma forma puede aparecer en más de un soporte, el número de formas distintas del corpus entero es algo menor (2.095 y 679).*

La comparación con la cerámica, que es el soporte más numeroso, muestra que la diferencia no es solo de cantidad.

**Tabla 2. Plomo y cerámica: extensión de los textos y tipo de palabras**

| Rasgo | Plomo | Cerámica |
|---|---|---|
| Palabras por inscripción (media) | 8,2 | 1,0 |
| Inscripciones con una palabra o menos | 33 de 143 (23 %) | 1.103 de 1.217 (91 %) |
| Inscripciones con cinco palabras o más | 71 (50 %) | 9 (menos del 1 %) |
| Inscripciones con diez palabras o más | 39 | 2 |
| Longitud media de la palabra completa | 7,7 letras | 5,3 letras |
| Palabras completas de dos o tres letras | 81 de 729 (11 %) | 258 de 639 (40 %) |
| Palabras completas de seis letras o más | 512 (70 %) | 236 (37 %) |
| Palabras que son nombre personal, marca o abreviatura | 33 % | 60 % |
| Palabras que pertenecen a una forma repetida en el soporte | 15 % | 32 % |
| Palabras que repiten una forma ya presente en el soporte (sin contar la primera aparición) | 9,3 % | 20,3 % |
| Formas no onomásticas con sufijo reconocible | 177 | 77 |

*En la cerámica, nueve de cada diez inscripciones constan de una sola palabra, que en la mayoría de los casos es un nombre, una marca o una abreviatura. En los plomos, la mitad de los textos tiene cinco palabras o más, las palabras son más largas y dos de cada tres no son nombres.*

De la tabla se siguen tres consecuencias para la elección del material:

1. **Contexto.** Solo en los plomos las palabras aparecen de forma regular dentro de un texto, junto a cifras, a otras palabras y en posiciones que se repiten de un documento a otro. Ese contexto (cifras, unidades de medida y casillas funcionales) es el que sustenta los significados propuestos.
2. **Tipo de palabra.** El vocabulario común, que es el comparable entre lenguas, se concentra en los plomos; en la cerámica predominan los nombres propios y las marcas.
3. **Longitud.** Las palabras breves no permiten distinguir entre lenguas (apartado 10). El 40 % de las palabras de la cerámica tiene dos o tres letras.

La proporción de formas con sufijo es similar en los dos soportes (en torno al 40 % del vocabulario no onomástico); la diferencia está en el número: los plomos aportan más del doble.

**Criterios del recuento.** Se han seguido los separadores de palabra y los saltos de línea de la edición de Hesperia. Las variantes gráficas equivalentes cuentan como una sola forma: las que solo difieren en b/p, t/d, k/g, s/ś, r/ŕ o m/n/ḿ. Se considera nombre personal probable la palabra clasificada como tal en el léxico de Moncunill y Velaza (2019) y, para las que ese léxico no recoge, la que se analiza como combinación de dos formantes de la lista de Rodríguez Ramos (2014), con sufijo o sin él; la categoría incluye, por tanto, leyendas, marcas y abreviaturas, y es una aproximación. Se consideran sufijos los de una lista cerrada de trece terminaciones frecuentes, tomadas de la descripción de Moncunill y Velaza (2017): *-ka*, *-te*, *-en*, *-ar*, *-e*, *-ban*, *-sken*, *-ḿi*, *-ir*, *-bi*, *-ki*, *-ite*, *-ke*. Las leyendas monetales no entran en el recuento, porque Hesperia las recoge en un módulo aparte.

### 3.2 El léxico con soporte metrológico

El primer grupo lo forman las palabras cuyo valor se apoya en hechos materiales (monedas con marca de valor, pesos, recipientes) y en su combinación dentro de un sistema: la serie numeral y las unidades de medida (Ferrer i Jané 2022). Son once términos numerales (½, 1 a 8, 10 y 20) y las unidades del sistema metrológico. La lista completa, con el apoyo de cada término, está en el Anexo D.1. El castellano «numeral» se usa aquí en sentido amplio: incluye la marca de mitad. En las pruebas, el léxico metrológico comparado son los diez términos del 1 al 8, el 10 y el 20; la serie numeral del apartado 7.1 usa los nueve del 1 al 8 y el 10, que son los que ofrece la base mundial.

El grado de apoyo no es el mismo para todos, y el propio Ferrer i Jané (2022) lo distingue. Las marcas de valor de las monedas de *untikesken* permiten validar de forma objetiva el significado de *ban* (1) y de *erder* (½) (Ferrer i Jané 2022: 16-17). El valor 10 de *abaŕ* / *baŕ* se infiere de un peso de piedra de Puig Castellar, de 420 g, con la inscripción *ustainabaŕarban* (Hesperia B.40.04), y de la unidad de unos 42 g (2022: 17). El 20 descansa en una marca de capacidad sobre un dolium de Ruscino, donde la forma es *ogei* (Hesperia PYO.01.23), lectura que el autor califica de plausible (2022: 19; edición y estudio en Ferrer i Jané 2024); *oŕkei* es la forma de las expresiones compuestas. Son, por tanto, tres apoyos de naturaleza distinta: una marca monetal, un peso y una marca de capacidad. Los valores intermedios se asignan por la posición de cada forma en las expresiones compuestas del propio sistema. Por ese motivo los resultados se dan siempre de dos maneras: para la serie completa y para los tres valores con apoyo externo (apartado 7.1).

### 3.3 El léxico de los plomos

El segundo grupo lo forman 30 palabras o familias de palabras de los plomos de contenido económico. El conjunto no procede de una selección hecha para este trabajo: son las unidades léxicas que resultan del análisis de esos documentos en las monografías I–IV (Martín Valladolid 2026a-d), que a su vez parten de las propuestas de Orduña (2005) y Ferrer i Jané (2009, 2022) y de la segmentación y clasificación de Moncunill y Velaza (2019).

Los significados son propuestas. Se apoyan en la metrología, en la serie numeral y en las casillas funcionales de los documentos: la posición de cada palabra respecto a las cifras y a las unidades de medida, y las casillas que se repiten de un plomo a otro (Orduña 2005; Ferrer i Jané 2009, 2022; Moncunill y Velaza 2019; monografías I–IV). Por su contenido, las 30 unidades se reparten en léxico contable y monetario, léxico predial y geográfico (fincas, cultivos, pastos, aguas, caminos), y léxico de las personas y de los actos documentados. Cuatro de ellas se han propuesto como préstamos del latín. La lista completa está en el Anexo D.2.

**Procedencia de cada significado.** La manera en que se obtuvo cada significado consta en el inventario cerrado de la Monografía IV (apartado 5.1, tabla 5), anterior a este trabajo, que separa las entradas en tres clases: (a) significado deducido de la metrología interna, del contexto formular o de la casilla, sin comparación vasca previa; (b) significado adoptado de bibliografía que ya había empleado la comparación con el euskera; (c) convergente, es decir, independiente en la obtención pero no en la comprobación. De las 30 unidades, 24 son de clase (a) y 6 de clase (c); ninguna es de clase (b). Sobre esa base se distinguen aquí tres niveles: I, propuesta previa de terceros apoyada en prueba material o en contexto interno (5 unidades); II, propuesta de las monografías deducida de la casilla documental (19); III, unidades convergentes (6). La ficha de cada unidad está en el Anexo D.3. Esta clasificación es del autor de las monografías; su revisión por codificadores independientes está en curso.

El Anexo D.2 da, para cada unidad, las inscripciones en que se documenta, la casilla o función que ocupa y el grado de certeza que se le asigna en las monografías: A, valor asegurado por la metrología o por la bibliografía; B, regularidad documentada en un texto o grupo de textos; C, hipótesis de trabajo. La mayoría de las unidades son de grado B o C, y así deben leerse los resultados.

### 3.4 Léxico no incluido

No se incluye el léxico interpretado por otros autores fuera de los dos grupos anteriores. A diferencia del léxico metrológico y del de las monografías, no se ha contrastado, palabra por palabra, en qué medida esas interpretaciones descansan en hipótesis etimológicas; incorporarlas sin ese examen introduciría un riesgo de circularidad.

## 4. La medida del parecido

La comparación exige una regla fija, igual para todas las lenguas y reproducible por terceros.

**La regla.** Cada palabra se reduce a su esqueleto fónico: cada sonido se sustituye por su clase en el modelo SCA de List (2012), que agrupa las consonantes en quince clases de sonidos próximos; las vocales se reducen a cinco. A continuación se cuenta el número mínimo de operaciones (sustituir, añadir o suprimir un sonido) necesarias para pasar de un esqueleto al otro. Las operaciones que afectan a una vocal cuentan la mitad que las que afectan a una consonante. El resultado se divide por la longitud media de las dos palabras, de modo que va de 0 (formas idénticas) a 1 o más (formas sin nada en común).

**Su justificación.** Los tres componentes de la regla son de uso corriente en la comparación cuantitativa de lenguas:

- La agrupación de los sonidos en clases procede de Dolgopolsky; es la base del método de Turchin, Peiros y Gell-Mann (2010) y de los métodos de alineamiento de List (2012), cuyo modelo SCA, el aquí empleado, es una versión ampliada de aquellas clases y se distribuye con el programa LingPy.
- El recuento de operaciones entre dos palabras (distancia de edición), dividido por su longitud, es la medida del programa ASJP de clasificación automática de las lenguas del mundo (Wichmann y otros 2010) y el punto de partida de Jäger (2015).
- El menor peso de las vocales responde a un hecho bien establecido: las consonantes son más estables que las vocales en la evolución de las lenguas.

La definición exacta, su expresión matemática y la comprobación de que la medida reconoce parentescos conocidos se dan en el Anexo A, con el detalle suficiente para reproducirla. En la fase inicial del trabajo las pruebas se hicieron también con una agrupación más simple, de ocho clases, y el euskera fue la primera lengua con las dos (Anexo F).

**Reglas de transcripción.** Las formas ibéricas se toman de Hesperia sin modificar. Para compararlas se aplican las reglas siguientes, las mismas para todas las lenguas en lo que les afecta.

| Regla | Justificación |
|---|---|
| Las oclusivas sordas y sonoras van en la misma clase (*b* / *p*, *d* / *t*, *g* / *k*) | Así lo hace el modelo SCA. Además, la escritura ibérica no dual no las distingue, y la dual solo en parte |
| Las dos vibrantes (*r*, *ŕ*) van en una clase y las dos sibilantes (*s*, *ś*) en otra | Su valor fonético exacto se discute; agruparlas evita decidirlo, y el modelo SCA tampoco las separa |
| *ḿ* se asigna a la clase de *m* | Convención de transcripción de Hesperia |
| En las fuentes con transcripción fonética (NorthEuraLex) se aplica la tabla SCA de referencia, con las adaptaciones explícitas del Anexo A.2 (entre ellas, ʜ→H y la reducción de seis clases vocálicas a cinco) | Es el uso para el que está hecha |
| En los diccionarios, que solo ofrecen ortografía, las clases SCA se aplican a la ortografía de cada lengua mediante una tabla de equivalencias; los dígrafos que notan un solo sonido cuentan como uno (*rr*, *ll*, *tx*, *tz*, *ts*) | Fonología de cada lengua; en euskera, la vibrante fuerte es un fonema (Michelena 1990, cap. 17, «Vibrantes», pp. 327-347) |
| En los diccionarios, la *h* inicial no se cuenta, e *i* inicial ante vocal cuenta como semiconsonante | La aspiración inicial es secundaria en buena parte del léxico del euskera (Michelena 1990, cap. 11, «La aspiración», pp. 203-224); la regla se aplica a todas las lenguas |

No se aplica ninguna regla de correspondencia particular entre el ibérico y una lengua determinada, ni se usa ninguna etimología.

## 5. Las pruebas

### 5.1 Prueba con significados

**Pregunta:** ¿se parece cada palabra ibérica a la palabra que tiene el mismo significado en una lengua dada?

Para cada unidad se toman del diccionario de esa lengua las palabras cuyo significado coincide con el propuesto, se mide la distancia a la más próxima y se calcula la media.

Es la prueba que aúna forma y sentido, y la que se corresponde con el modo de proceder de la comparación lingüística tradicional. Depende de que los significados propuestos sean correctos.

### 5.2 Prueba sin significados: el perfil de combinaciones de sonidos

**Pregunta:** ¿combina el ibérico los sonidos como lo hace alguna de las lenguas comparadas?

Las pruebas estadísticas de parentesco establecidas (Oswalt 1970; Ringe 1992; Kessler 2001) comparan palabras del mismo significado. Sin significados existe otra vía documentada: el parentesco deja señal en la fonotaxis, es decir, en la frecuencia con que cada sonido sigue a cada otro en el vocabulario de una lengua. Macklin-Cordes, Bowern y Round (2021) lo muestran con 111 lenguas de una misma familia (pama-ñungana): las frecuencias de transición entre sonidos, y más aún entre clases de sonidos, se reparten según el árbol genealógico conocido y no al azar. Aquí se aprovecha esa propiedad de otro modo, que es propio de este trabajo: en lugar de contrastar cada transición con un árbol ya establecido, se mide la distancia entre los perfiles completos de dos lenguas, y el procedimiento se valida comprobando si reconoce las familias conocidas de la base (apartado 7.4). Los mismos autores señalan que la geografía puede confundirse con la herencia, cautela que vale también aquí.

Para cada lengua se calcula la frecuencia de cada par de clases de sonidos consecutivas, con el inicio y el fin de palabra, en todo su vocabulario disponible; la distancia entre dos lenguas es la divergencia entre esos dos perfiles (Anexo B.8). Del ibérico se usan todas las formas distintas del corpus (2.229) y, por separado, las de los plomos (1.072).

Esta prueba no supone nada sobre el significado de las palabras ibéricas ni exige segmentarlas en unidades léxicas, y usa todo el corpus. A cambio, la fonotaxis refleja también tipología y contacto de área, no solo herencia.

### 5.3 Complementariedad

Las dos pruebas se apoyan en supuestos distintos. Una parte de los significados propuestos; la otra prescinde de ellos. La prueba sin significados no depende de cómo se hayan interpretado las palabras, y la prueba con significados no se apoya en parecidos formales sin relación de sentido: ofrecen, por ello, información complementaria. Su coincidencia no excluye sesgos compartidos de corpus, transcripción, tipología o selección, y no se combina aquí como dos confirmaciones independientes. Las dos se han contrastado con lenguas de control (apartado 8.3).

No usan el mismo material: la primera, las 30 unidades de los plomos y el léxico metrológico; la segunda, todas las formas del corpus. Aun así proceden de los mismos textos y no deben sumarse como confirmaciones independientes.

### 5.4 El descuento del azar

Un parecido solo es informativo si supera al que se obtendría por casualidad. La referencia de azar se construye así:

- **En la prueba con significados:** cada candidata se sustituye por una palabra tomada al azar del mismo diccionario y de su misma longitud, y la operación se repite varios centenares de veces. En cada repetición ninguna palabra se usa dos veces, y una candidata que sirve a varias unidades recibe la misma sustituta en todas, de modo que el conjunto sorteado tiene la misma estructura que el real (Anexo B.6). Con ello se descuentan el tamaño del diccionario, la abundancia de sinónimos de cada lengua y el hecho de que las palabras de significado común son más cortas que la media. Esta última condición se añadió a raíz de los casos de control (Anexo B.6).

- **En el perfil de combinaciones de sonidos** no hay un sorteo: el resultado es una distancia, y lo que se lee es el puesto de cada lengua. Su valor se establece comprobando cuántas veces la prueba acierta la familia de una lengua conocida (apartados 7.4 y 8.3) y repitiéndola con muestras al azar de las palabras ibéricas.

En las tablas de la prueba con significados el valor indica cuánto se aparta el resultado de lo esperable por azar: **cuanto más bajo (más negativo), más alejado de la casualidad**; un valor próximo a 0 es el que da el azar. Junto al valor se indica siempre el puesto de cada lengua entre las comparadas, que es el dato de lectura más directa. El detalle está en el Anexo B.

## 6. Lenguas y diccionarios

**Tabla 3. Fuentes léxicas**

| Fuente | Lenguas | Uso |
|---|---|---|
| NorthEuraLex (Dellert y otros 2020), en formato CLDF | 107 lenguas de Eurasia, entre ellas el euskera, el latín, el castellano y las demás lenguas romances | Prueba fonética. Mismo vocabulario básico y misma transcripción para todas |
| Chan (2019), *Numeral Systems of the World's Languages* | 3.811 lenguas de 239 familias con la serie completa | Serie numeral |
| Wikcionario inglés | 35 lenguas (32 con candidatas suficientes en la prueba con significados) | Prueba con significados; comprobación del perfil de combinaciones de sonidos |
| Diccionarios bilingües de traducción automática (Apertium) | Con el castellano de puente: portugués, gallego, aragonés, asturiano, occitano, francés, italiano, rumano y euskera. Con el inglés de puente: euskera, castellano, catalán, alemán, galés, finés, serbocroata, islandés, sueco y turco | Prueba con significados, con diccionarios del mismo tipo para todas |
| WordNet multilingüe | Euskera, castellano, catalán, gallego | Prueba con significados, concepto a concepto |
| Léxico del Gobierno Vasco (Open Data Euskadi) | Euskera | Prueba con significados |
| Diccionarios históricos y reconstrucciones | Euskera: Azkue (1905-1906), que recoge el léxico dialectal y de los textos clásicos; léxico reconstruido de Trask (2008). Latín | Prueba con significados |

La prueba sin significados requiere un vocabulario del mismo tamaño y contenido en todas las lenguas, transcrito fonéticamente, para que los perfiles sean comparables. La prueba con significados requiere diccionarios completos, porque el vocabulario básico no recoge la mayor parte de los términos propios de un documento económico. Para evitar que el resultado dependa de un diccionario concreto, cada lengua se ha medido, cuando ha sido posible, con más de una fuente independiente. El castellano no figura como lengua comparada en los diccionarios que lo usan de puente; sí en las demás fuentes.

El euskera histórico y reconstruido está representado ya por dos fuentes: el diccionario de Azkue, que recoge el léxico dialectal y de los textos clásicos, y el léxico reconstruido de Trask. Tres ampliaciones quedan como tarea futura: incorporar las reconstrucciones de Lakarra, de las que no se dispone por ahora de una fuente en formato informatizado; añadir más documentación anterior al siglo XX (por ejemplo, el vocabulario de Landucci, de 1562); y disponer de diccionarios bilingües equivalentes para más lenguas no romances. Las fuentes, sus versiones y sus licencias se detallan en el Anexo C.

## 7. Resultados

Las cifras son las que dan los programas publicados con su semilla fija (apartado 9), y se reproducen con exactitud. Los valores que dependen de sorteos cambian con otra semilla. Medido con 40 secuencias de sorteos distintas (Anexo B.7), el valor del euskera en la prueba de la tabla 6 va de −11,6 a −13,3 (mediana −12,4), y el de las demás lenguas se mueve en torno a media unidad; el euskera es la primera lengua en las 40, y la separación con la siguiente no baja de 7,3. El valor de la tabla 6 (−12,8) queda, por tanto, en la parte más marcada de ese intervalo. Las diferencias de menos de una unidad entre fuentes o entre variantes no deben interpretarse; es variabilidad de la simulación, no del efecto.

### 7.1 El léxico con soporte metrológico: la serie numeral

La serie numeral se ha comparado con la de 3.811 lenguas de todo el mundo (una por lengua; 239 familias), valor a valor.

**Tabla 4. Lengua más próxima a la serie ibérica**

| Términos comparados | Primer puesto | Segundo |
|---|---|---|
| Serie completa (1 a 8 y 10) | Euskera, a distancia 0,32 | Una lengua de Nigeria, a 0,76 |
| Solo los tres valores con apoyo externo (1, 10 y 20) | Euskera, a 0,44 | La siguiente, a 0,58 |

*La serie numeral más próxima a la ibérica es la del euskera, y ninguna otra lengua se le acerca (figura 3).*

Para valorar ese dato se ha medido, con la misma regla, qué ocurre entre las lenguas del mundo cuya relación se conoce.

**Tabla 5. Qué significa una distancia de 0,32 entre series numerales**

| Pregunta | Resultado |
|---|---|
| De 110 lenguas que no tienen ningún pariente en la base, ¿cuántas tienen una lengua a 0,32 o menos? | Ninguna. La más próxima está a 0,41 |
| En una muestra de 400 lenguas con parientes, cuando la lengua más próxima está entre 0,3 y 0,4, ¿es de su misma familia? | Sí en los 63 casos |
| ¿Y en el tramo más amplio, entre 0,2 y 0,5? | Sí en 162 de 165 casos (98 %) |

*En la muestra mundial, dos series numerales tan próximas como la ibérica y la del euskera pertenecen casi siempre a lenguas de la misma familia. Las excepciones son series tomadas en préstamo de otra lengua.*

![Figura 3. Serie numeral: distancia de cada una de las 110 lenguas sin parientes a su lengua más próxima, y distancia entre el ibérico y el euskera.](figuras/figura_3_serie_numeral.png)

Si los valores se reordenan al azar dentro de una misma lengua (comparando el «uno» ibérico con el «siete», y así sucesivamente), la proximidad desaparece: las formas se parecen a las de su mismo valor. Con el léxico reconstruido de Trask (2008), la prueba con significados da para el léxico metrológico un valor del mismo orden que con los diccionarios modernos (−10,7; tabla 7).

Deben tenerse en cuenta dos límites. Los valores con apoyo externo son tres, y con ellos solos la ventaja del euskera es menor. Y la asignación de los valores intermedios procede de la bibliografía (apartado 3.2); la distancia de la serie completa depende de que esa asignación sea correcta.

### 7.2 Las 30 unidades de los plomos

**Tabla 6**

| Prueba | Diccionarios (lenguas) | Primer puesto | Siguientes |
|---|---|---|---|
| Con significados, Wikcionario y dos diccionarios del euskera (Azkue y léxico reconstruido) | 34 (32) | Euskera (−12,8 con el Wikcionario; −10,3 con Azkue; −7,2 con el léxico reconstruido) | Gallego (−4,3), tagalo (−3,9) |
| Con significados, diccionarios con el castellano de puente | 10 (9) | Euskera (−10,9 y −10,0) | Gallego (−4,8), italiano (−2,9), aragonés (−2,8) |
| Con significados, diccionarios bilingües, puente inglés | 9 (9) | Euskera (−9,7) | Catalán (−3,6), islandés (−3,2), castellano (−3,1) |
| Con significados, concepto a concepto (WordNet) | 4 (4) | Euskera (−11,9) | Gallego (−3,3), catalán (−2,4), castellano (−1,7) |
| Sin significados, perfil de combinaciones de sonidos (apartado 7.4) | 107 lenguas | Euskera | Latín (yakuto, con las lenguas reducidas a lo que el ibérico escribe) |

*Con todas las fuentes y en todas las pruebas, la lengua más próxima es el euskera. En la prueba con significados la distancia con la lengua siguiente es grande. El valor de las lenguas que siguen (gallego, tagalo, catalán) procede en buena parte de las cuatro unidades propuestas como préstamos latinos: su retirada reduce la afinidad de esas lenguas, y los cambios de significación dependen de la lengua y de la variante de permutación (apartados 8.1 y 8.5).*

![Figura 1. Arriba, valor de cada lengua en la prueba con significados (30 unidades de los plomos; azar corregido por longitud). Abajo, distancia de cada lengua al ibérico en el perfil de combinaciones de sonidos (todo el corpus).](figuras/figura_1_las_dos_pruebas.png)

![Figura 2. La prueba con significados y el perfil de combinaciones de sonidos a la vez, para las doce lenguas presentes en ambas bases.](figuras/figura_2_nube_dos_pruebas.png)

En la prueba con significados, el léxico con soporte metrológico da valores del mismo orden (de −10,2 a −11,4 para el euskera según la fuente; −3,3 y −3,4 para la segunda lengua, el turco).

### 7.3 Coherencia entre fuentes

**Tabla 7. Valores del euskera según el diccionario empleado**

| Fuente | 30 unidades | Léxico metrológico |
|---|---|---|
| Wikcionario | −12,8 | −10,6 |
| Open Data Euskadi | −10,9 | −11,3 |
| WordNet | −11,9 | −10,5 |
| Apertium (castellano / inglés) | −10,0 / −9,7 | −10,2 / −10,4 |
| Azkue (1905-1906) | −10,3 | −11,4 |
| Léxico reconstruido (Trask 2008) | −7,2 (15 unidades comparables) | −10,7 |

*El resultado no depende de la fuente, ni de que se use el léxico moderno, el dialectal y clásico o el reconstruido. El léxico reconstruido, de solo 391 formas, permite comparar la mitad de las unidades y se mantiene entre los primeros puestos. Las siete fuentes del euskera no son lenguas distintas ni son independientes entre sí (describen la misma lengua y comparten buena parte del léxico): se dan por separado para mostrar que el resultado no descansa en un diccionario concreto.*

### 7.4 El perfil de combinaciones de sonidos

Resultados de la prueba sin significados descrita en el apartado 5.2.

**Tabla 8. Perfil de combinaciones de sonidos**

| Comprobación | Resultado |
|---|---|
| Dentro de las 107 lenguas: ¿la lengua más próxima es de la misma familia? | Sí en 77 de las 98 que tienen parientes en la base (79 %); por azar se esperaría el 20 % |
| Córnico | Galés primero, bretón segundo |
| Umbro | Latín primero |
| Dálmata | Rumano segundo (primero, sueco) |
| Gótico | Islandés segundo (primero, lak) |
| Etrusco, sumerio | Lenguas diversas, a mayor distancia |
| Ibérico, todo el corpus | Euskera primero de 107; latín segundo |
| Ibérico, plomos | Euskera primero de 107; latín segundo |
| Ibérico, 500 remuestreos de las palabras y 500 mitades al azar | Euskera primero en todos |
| Todas las lenguas reducidas a los sonidos que la escritura ibérica anota | Euskera primero (0,070); después, yakuto (0,094) |
| Calibración: percentil de la distancia ibérico–euskera entre las parejas de familias distintas de la base (4.618) / de la misma familia (1.053) | Clases completas: 0,1 / 6,5. Reducidas: 0,02 / 2,4 |
| Frente a 35 lenguas de otra base, con lenguas de África, Oceanía, el sudeste asiático y América (suajili, zulú, hawaiano, fiyiano, tagalo, malgache, quechua, náhuatl y otras) | Euskera primero (0,106); después, finés (0,131). Reducidas a lo que el ibérico escribe: euskera 0,058; finés 0,090. Primero en todos los remuestreos |

*El perfil de combinaciones de sonidos reconoce la familia en cuatro de cada cinco lenguas, y sitúa al euskera como la lengua más próxima al ibérico entre 107.*

**Lectura.** El puesto es el dato firme: la lengua propuesta de antemano resulta la primera de 107, en todos los remuestreos. La distancia, en cambio, no prueba por sí sola un parentesco: con las clases completas, el ibérico queda del euskera a 0,153, y el propio euskera, que no tiene parientes en la base, tiene su lengua más próxima a 0,154. Reducidas todas las lenguas a los sonidos que el ibérico escribe, la distancia entre el ibérico y el euskera (0,070) es menor que la del euskera a cualquier otra lengua (0,098) y que la distancia mediana entre una lengua y su pariente más próximo (0,091).

**Calibración con la propia base.** Esta prueba no construye una distribución de azar: dice qué lengua queda primera y cuán estable es el puesto, no con qué frecuencia dos lenguas sin relación quedan a una distancia como la observada. Para dar esa referencia, declarada antes de calcularla, se tomaron las 5.671 parejas que forman las 107 lenguas entre sí: 1.053 de la misma familia y 4.618 de familias distintas. Con las clases completas, solo 5 de las 4.618 parejas de familias distintas tienen una distancia igual o menor que la ibérico–euskera (0,153); las otras 4.613 la tienen mayor (percentil 0,1; las cinco: sueco–vepsio, 0,135; komi–ruso, finés–canarés, checheno–persa y bengalí–burushaski). La distancia ibérico–euskera es menor que la del 93 % de las parejas de la misma familia. Reducidas las lenguas a lo que el ibérico escribe, una sola pareja de familias distintas queda a distancia igual o menor (estonio–hindi, 0,068), y la distancia ibérico–euskera es menor que la del 98 % de las de la misma familia; de las nueve lenguas sin parientes en la base, ninguna tiene un vecino a esa distancia. La previsión era que la distancia quedara por debajo del percentil 10 (clases completas) y del 5 (reducidas) de las parejas de familias distintas; se cumple con margen. Es una calibración descriptiva, no un valor *p*. La existencia de parejas de familias distintas a distancias iguales o menores muestra que una distancia pequeña no identifica por sí sola un parentesco; este cálculo no determina la causa de la semejanza de cada pareja (el programa clasifica por familia, no por contacto), y por eso la frase central de este trabajo se apoya en la prueba con significados.

**Límites.** La fonotaxis refleja también tipología y contacto de área, y no solo herencia; esta prueba, como las demás, no distingue entre esas causas. La base principal comprende solo lenguas del norte de Eurasia; la comprobación con 35 lenguas de otra base, que incluye lenguas de sílaba sencilla de otras zonas, da el mismo primer puesto, pero esa base está en ortografía y no en transcripción fonética, y su validación interna es más modesta (la lengua más próxima es de la misma familia en 17 de 24). Y las comprobaciones de robustez se hicieron después de ver el resultado, por lo que valen como control y no como predicción.

## 8. Comprobaciones

### 8.1 Con los préstamos latinos y sin ellos

**Motivo.** El latín ha dejado un gran número de préstamos en todas las lenguas de su entorno, incluido el euskera. Si parte del léxico ibérico analizado fuera de origen latino, coincidiría con el de esas lenguas sin que ello informara de ninguna relación más antigua. Cuatro de las 30 unidades se han propuesto como préstamos latinos: *bale*, *koŕta*, *saltu* y *oŕtin*.

**Procedimiento.** Las pruebas se repitieron con las otras 26 unidades y, por separado, con esas cuatro.

**Tabla 9. Prueba con significados, con los préstamos latinos y sin ellos**

| | Euskera | Lenguas romances |
|---|---|---|
| Las 26 unidades restantes | Sin cambio respecto a las 30: primer puesto en todas las fuentes (−9,6 a −12,1 en los diccionarios completos; −7,3 en el léxico reconstruido) | Entre +0,4 y −3,5, el mismo tramo que ocupan lenguas sin relación posible (islandés, −3,1; tagalo, −2,2). Los valores más marcados son el del gallego con el castellano de puente (−3,5) y el del catalán con el inglés de puente (−2,9). El latín queda en +0,4 |
| Los cuatro préstamos, solos | Puestos intermedios (−1,5 a −3,4) | Primeros puestos: gallego (−4,6, −4,5 y −5,0), asturiano (−4,6 y −3,9), aragonés (−4,1), occitano (−4,0), catalán (−3,7) |

*Sin los préstamos latinos, el euskera conserva su posición y las lenguas romances quedan en el tramo de las lenguas sin relación. Los cuatro préstamos, por sí solos, se aproximan a las lenguas romances.*

De aquí se siguen dos consecuencias. La proximidad al euskera no depende de estas cuatro unidades propuestas como préstamos latinos (retirarlas no excluye todo léxico latino compartido). Y la prueba separa por sí misma las cuatro palabras que el análisis de los textos había identificado como latinas, lo que es coherente con ese análisis. Debe tenerse en cuenta que se trata de cuatro palabras.

**El tagalo.** El tagalo aparece entre las lenguas que siguen al euskera en la tabla 6 (−3,9) y queda igualado con el gallego en cabeza con los cuatro préstamos solos (−4,6). La causa es conocida: el tagalo tomó del castellano varios miles de palabras durante tres siglos, y en ese vocabulario se comporta como una lengua romance. De las cuatro unidades, dos encuentran en tagalo un hispanismo casi idéntico: *bale* frente a *bale* («valor», del castellano *vale*) y *oŕtin* frente a *hardin* («jardín, huerto», del castellano *jardín*). Sin las cuatro unidades, el tagalo queda en −2,2 y, en la prueba de permutación del apartado 8.5, en el nivel del azar (−1,6). Es el mismo efecto que se observa en el gallego, y sirve de control involuntario: una lengua sin relación alguna con el ibérico, pero con léxico de origen latino, obtiene valor en esas cuatro unidades y solo en ellas. Por el mismo motivo figura entre las parejas de solo contacto de la segunda parte (apartado 11.1).

### 8.2 Formas flexionadas y sinónimos

Un texto no presenta las palabras en la forma de cita del diccionario, y un mismo significado puede expresarse con más de un término. La prueba se repitió añadiendo, para todas las lenguas, las formas flexionadas de cada palabra y una lista ampliada de sinónimos. Esta comprobación es exploratoria: la lista ampliada de sinónimos se redactó después de conocer los primeros resultados, y no forma parte del contraste principal. El euskera ocupa el primer puesto entre 24 lenguas tanto en las 30 unidades como en el léxico metrológico. En las 30 unidades el valor es −12,1 en la forma de cita, −10,8 con las formas flexionadas, −12,1 con los sinónimos y −11,1 con ambas cosas a la vez (la segunda lengua, entre −2,9 y −4,6). En el léxico metrológico, −10,1 en la forma de cita y −11,9 con las formas flexionadas (la segunda lengua, −3,6 y −1,7).

### 8.3 Casos de control: lenguas de filiación conocida y lenguas sin parientes en la base

Para saber qué valor tienen las cifras anteriores se aplicaron las dos pruebas, sin cambiar nada, a seis lenguas cuya filiación se conoce. Cuatro tienen parientes entre las lenguas de comparación: el umbro (itálica), el gótico (germánica), el córnico (céltica) y el dálmata (romance). Dos no tienen parientes entre las lenguas de comparación: el etrusco y el sumerio. De cada una se sacaron al azar muestras de 30 palabras con su glosa. Las lenguas, los parientes esperados y las reglas se fijaron antes de ejecutar (Anexo F).

**Tabla 10. Casos de control, prueba con significados (cinco muestras de 30 palabras por lengua)**

| Lengua de prueba | Parientes esperados | Muestras en que la primera lengua es pariente | Valor de la primera lengua |
|---|---|---|---|
| Dálmata | Latín y romances | 5 de 5 | −12,1 a −15,5 |
| Córnico | Galés, irlandés | 4 de 5 (en la quinta, rumano −9,7 y galés −9,4) | −6,7 a −13,6 |
| Umbro | Latín y romances | 5 de 5 (latín en 4, rumano en 1) | −4,6 a −8,1 |
| Gótico | Islandés | 4 de 5 | −3,0 a −6,8 |
| Etrusco | Ninguno | — | −2,4 a −4,8 (rumano, asturiano, latín) |
| Sumerio | Ninguno | — | −1,6 a −2,8 |

*La prueba con significados reconoce al pariente en 18 de 20 muestras, con valores que crecen con la cercanía; en el sumerio, lengua aislada y sin contacto con las de comparación, la primera lengua no pasa de −2,8.*

**La prueba con significados distingue.** Los valores más altos corresponden al dálmata frente a las lenguas romances; después, al córnico frente al galés, al umbro frente al latín y, a distancia, al gótico frente al islandés. El sumerio no señala a ninguna lengua. El etrusco señala, con valores moderados, al latín y a lenguas romances (y al tagalo, por sus hispanismos), lo que es compatible con el contacto histórico entre el etrusco y el latín. El valor del euskera con las 30 unidades ibéricas (entre −9,7 y −12,8 según el diccionario completo) es del orden de los que obtiene el córnico frente al galés.

**El perfil de combinaciones de sonidos distingue también.** Con las mismas seis lenguas, sitúa al galés y al bretón como las más próximas al córnico y al latín como la más próxima al umbro; con el dálmata y el gótico, el pariente queda segundo; el etrusco y el sumerio no señalan a ninguna familia (tabla 8). Al reducir todas las lenguas a los sonidos que el ibérico escribe, la prueba distingue peor: la validación baja del 79 % al 70 %, y el umbro deja de tener al latín como lengua más próxima (portugués 0,120; euskera 0,124; latín 0,133). Por eso el resultado con las lenguas reducidas se da como comprobación y no como resultado principal.

**Acierto de clasificación y frecuencia de resultados tan extremos como el caso ibérico.** Cinco muestras por lengua no permiten dar una proporción. La prueba se repitió con 100 muestras de 30 palabras por lengua; lo que se esperaba y lo que contaría en contra se publicó en el repositorio antes de ejecutarla. Se miden dos cosas distintas, que no forman una misma regla de decisión: en las lenguas con parientes, con qué frecuencia la primera lengua es un pariente, sea cual sea el valor; en las lenguas sin parientes, con qué frecuencia se alcanzan un valor y una separación tan extremos como los del ibérico con el euskera. No es, por tanto, un par de potencia y error de tipo I de un mismo contraste, y una pareja con contacto puede dar semejanzas reales que no serían un falso positivo de afinidad, aunque sí lo serían de parentesco.

**Tabla 10 cuater. Cien muestras por lengua de control**

| Lengua | Muestras con un pariente en primer lugar | Valor de la primera lengua (mediana; mejor) | Mayor separación con la segunda |
|---|---|---|---|
| Dálmata | 100 | −14,0; −18,0 | 4,7 |
| Umbro | 95 | −6,2; −9,4 | 5,8 |
| Córnico | 90 | −9,8; −15,1 | 8,1 |
| Gótico | 79 | −4,6; −9,8 | 6,4 |
| Etrusco (sin parientes en la base) | — | −3,44; −6,85 | 2,64 |
| Sumerio (sin parientes) | — | −2,17; −3,75 | 1,69 |

*En las cuatro lenguas con parientes, la primera lengua pertenece a la familia esperada entre el 79 % y el 100 % de las muestras. En 200 muestras de las dos lenguas sin parientes en la base, ninguna alcanza los umbrales declarados de antemano (−9,3 de valor y 5,6 de separación, que eran los del diccionario menos favorable en la versión anterior) ni los valores actuales del diccionario menos favorable (−9,7 y 5,2): el mejor valor es −6,85 y la mayor separación, 2,64 (los extremos de esta tabla se dan con dos decimales, redondeados una sola vez desde los registros).*

El valor del ibérico con el euskera (−12,8 con el mismo diccionario, y 8,5 de separación) queda fuera de todo lo observado en las lenguas sin parientes y en la zona de las lenguas emparentadas. En dálmata y umbro la separación es pequeña porque tienen varios parientes entre las lenguas de comparación, que quedan juntos en cabeza. Las cien muestras de cada lengua se sacan de un mismo léxico y se solapan, sobre todo en el etrusco (108 palabras elegibles). Cero casos de 200 no es una tasa general: son dos lenguas y dos léxicos fijos, cuyos significados son conocidos y no propuestos, de modo que los controles no reproducen el proceso de selección de significados del caso ibérico.

**El caso del etrusco.** El etrusco es la lengua sin parientes que alcanza los valores más altos, y conviene precisar por qué. No es una lengua aislada en sentido estricto: se le reconocen dos parientes, el rético y la lengua de la estela de Lemnos (Rix 1998), pero ninguno figura entre las lenguas de comparación, de modo que en esta prueba se comporta como una lengua sin parientes. Su primera lengua es el latín en 39 de las 100 muestras, otra lengua romance en 41 (asturiano 17, rumano 12, siciliano 9, y una vez el sardo, el gallego y el occitano) y una lengua de otra familia en 20. Esa concentración es compatible con el contacto histórico entre el etrusco y el latín, sin que el análisis permita atribuir a ese contacto cada coincidencia: el programa no clasifica etimológicamente las parejas ni estima qué valor habría tenido ese léxico sin contacto. Los máximos observados, −6,85 de valor y 2,64 de separación, describen estas cien muestras; el ibérico frente al euskera da −12,8 y 8,5. No se deduce de ello un techo de lo que otro contacto podría producir.

**Límites de los controles.** Las palabras de control proceden del mismo diccionario en línea que los diccionarios de comparación, con glosas del mismo estilo, lo que favorece a la prueba con significados; y son palabras tomadas al azar con significado conocido, mientras que los significados ibéricos son propuestas (apartado 3.3). Los controles dicen cómo se comporta el método, no si las propuestas son correctas.

### 8.4 Solidez frente a la lista de unidades

Los significados de las 30 unidades son propuestas. Conviene saber, por tanto, si el resultado depende de unas pocas unidades o de que todos los significados sean correctos. Se hicieron cinco comprobaciones con las lenguas del Wikcionario que tienen palabras para al menos el 40 % de las unidades (32). Para ello se calculó, unidad por unidad, la distancia real y la del azar en 500 sorteos conjuntos (los mismos para todas las unidades); el valor de cualquier subconjunto se obtiene de esa tabla. Las comprobaciones y lo que contaría en contra se fijaron antes de ejecutarlas.

**Tabla 10 bis. La prueba con significados al reducir o alterar la lista de unidades**

| Comprobación | Resultado |
|---|---|
| Lista completa, con los sorteos conjuntos de este apartado | Euskera primero (−12,5; siguiente, el gallego, −4,1) |
| Quitando una unidad cada vez (30 casos) | Euskera primero en los 30; valor entre −11,8 y −13,0; la lengua siguiente queda siempre a más de 7 unidades |
| 20 unidades tomadas al azar (2.000 veces) | Euskera primero en las 2.000; valor mediano −10,1 |
| 15 unidades tomadas al azar (2.000 veces) | Euskera primero en 1.999; valor mediano −8,8 |
| 10 unidades tomadas al azar (2.000 veces) | Euskera primero en 1.975; valor mediano −7,2 |
| Solo las 5 unidades de nivel I (propuesta previa de terceros; 4 comparables: *kitar* no tiene candidatas en euskera) | Euskera primero (−5,8; siguiente, −3,2) |
| Solo las 19 de nivel II (casilla documental; 18 comparables) | Euskera primero (−8,1; siguiente, −3,8) |
| Solo las 6 con apoyo de la toponimia (nivel III, convergentes) | Euskera primero (−8,3; siguiente, −2,4) |
| Niveles I y II juntos: las 24 de clase (a), obtenidas sin comparación vasca según la Monografía IV (22 comparables) | Euskera primero (−9,3; siguiente, −4,0) |
| Nivel II, las 6 para las que la Monografía IV señala después una correspondencia vasca | Euskera primero (−7,3; siguiente, −2,8) |
| Nivel II, las 13 sin correspondencia señalada (12 comparables) | Euskera y tagalo prácticamente igualados (−4,4 y −4,3) |
| Las mismas, sin los cuatro préstamos latinos (9; 8 comparables) | Euskera primero, sin separación apreciable (−3,2; siguiente, el albanés, −2,4) |
| Variante: nivel II con la tabla 5 de la edición final de la Monografía IV (reclasificación del 21-11-2026; declaración 16), las 8 con correspondencia | Euskera primero (−8,2; siguiente, el gallego, −3,1) |
| Variante: las 11 restantes sin correspondencia (10 comparables) | Tagalo primero (−4,6); euskera segundo (−3,4) |
| Variante: las mismas, sin los cuatro préstamos latinos (7; 6 comparables) | Sin separación: hawaiano −1,95, euskera −1,85 |
| Sin las 5 unidades para las que las monografías dejan abierta una lectura alternativa, como nombre de persona o como otro término (*oŕtin*, *selki*, *saltu*, *akari*, *laku*; 25 unidades) | Euskera primero (−11,8; siguiente, el gallego, −3,6) |
| Quitando una a una las unidades más favorables al euskera | Sigue primero hasta quitar 12 de las 28 comparables; lo pierde al quitar la decimotercera |
| Niveles I y II según la clasificación menos favorable de un jurado ciego (12 unidades; 11 comparables; véase «Procedencia y circularidad») | Euskera primero (−6,6; siguiente, el albanés, −2,2) |
| Nivel III según esa misma clasificación (18 unidades; 17 comparables) | Euskera primero (−10,8; siguiente, el gallego, −4,2) |
| Niveles I y II según la clasificación menos favorable del mismo jurado con la segunda pregunta, la de suficiencia (12 unidades; 11 comparables) | Euskera primero (−8,6; siguiente, el catalán, −3,1) |

*El resultado no depende de ninguna unidad aislada: se mantiene con un tercio de la lista tomado al azar, y, en el orden de retirada adversa empleado, pierde el primer puesto al retirar la decimotercera unidad (no se ha comprobado que trece sea el mínimo entre todas las selecciones adversas posibles). Sí depende del grupo que se considere: en las 13 unidades de nivel II sin correspondencia vasca señalada, el euskera no se separa de la lengua siguiente.*

**Procedencia y circularidad.** El resultado se mantiene con las 24 unidades cuyo significado, según la clasificación del propio autor en la Monografía IV, se obtuvo sin comparación vasca, y con las cuatro de nivel I solas; el repositorio reproduce esa clasificación, no certifica la historia de cada propuesta. Dentro del nivel II, el valor procede sobre todo de las seis unidades para las que la Monografía IV señala una correspondencia vasca después de fijado el significado; en las demás el valor es mucho menor (−4,4, y −3,2 sin los cuatro préstamos latinos), del orden del que alcanzan otras lenguas con la lista completa, y el euskera queda prácticamente igualado con el tagalo, como corresponde a unidades para las que esa monografía no encuentra correspondencia. Después de la auditoría, en la edición final de la Monografía IV (21-11-2026), el autor reclasificó tres unidades como posibles correspondencias de nivel C, señaladas después de obtenido el significado: *baśir* (vasc. *baserri*), *kutu* (*gutun*) e *iunstir* (*jaun*). Con esa clasificación, declarada antes de recalcular (declaración 16), el grupo de nivel II con correspondencia pasa a 8 unidades y da −8,2 (siguiente, el gallego, −3,1); en las 11 que quedan sin correspondencia el euskera es segundo, con −3,4, tras el tagalo (−4,6), y sin los préstamos latinos no se distingue de otras lenguas (−1,85; hawaiano, −1,95). El análisis principal sigue siendo el de la clasificación registrada antes de los resultados, y la lectura no cambia: el valor del nivel II se concentra en las unidades con correspondencia señalada. Como esa división depende en parte del propio parecido con el euskera, indica dónde está el parecido, no si la clasificación es independiente; esa pregunta la responde el jurado ciego. El resultado global descansa, por tanto, en las unidades de nivel I, en las de nivel III y en las seis de nivel II con correspondencia señalada. Tampoco depende de incluir conjuntamente las cinco unidades para las que las monografías dejan abierta una lectura como nombre de persona o como otro término: sin ellas el euskera queda en −11,8 y el gallego en −3,6 (previsión declarada antes de ejecutar: entre −9 y −12, y la siguiente no más allá de −4,5). No se ha comprobado que esa lista de alternativas sea exhaustiva, ni se validan con ello las interpretaciones restantes. Se ensayó también cuánto valor puede obtenerse eligiendo los significados a conveniencia de cada lengua (programa `t17_techo_circularidad.py` del repositorio). La prueba no es concluyente: con esa libertad, otras lenguas alcanzan valores tan altos como el del euskera (el malayo, −15,9, frente a −15,0 del euskera con la misma libertad y −13,7 con los significados propuestos). La respuesta a la objeción de circularidad no descansa, por tanto, en el valor estadístico, sino en la procedencia documentada de cada significado (Anexo D.3).

**Segunda codificación de la procedencia por un jurado ciego.** La clasificación anterior es del autor. Para contrastarla, declarado antes de enviar las fichas (declaración 7), se sometieron a tres modelos de lenguaje de tres fabricantes distintos, en sesiones nuevas y sin memoria, 42 fichas que describen la prueba con que se propuso cada significado sin dar el término ibérico ni nombrar ninguna lengua (36 unidades y 6 fichas de control inventadas, de nivel evidente), con la única pregunta de si, con esa prueba, el significado puede fijarse sin recurrir al parecido con una lengua viva (nivel I, prueba material externa o contexto sin otra lectura; II, distribución documental; III, no). Dos jueces actuaron como codificadores y uno como crítico, con el encargo de buscar en cada ficha la razón más fuerte para rebajar el nivel; en caso de duda, el nivel más bajo. Resultados (respuestas íntegras, clave y cruce en `2_criterios/jurado/respuestas/`): los tres jueces acertaron cinco de los seis controles, y el sexto estaba mal calibrado (su descripción no deja otra lectura que la que dieron); la concordancia entre los dos codificadores es de 34 de 36 (κ de Cohen 0,91), y la de los tres, 27 de 36 (κ de Fleiss 0,72). Es una sensibilidad a la codificación de las fichas, no una verificación de las fuentes: los jueces leyeron resúmenes redactados por el autor, no las monografías. En la clasificación menos favorable todas las discrepancias son rebajas (dos jueces subieron A5, ficha U11, de II a I, pero el tercero mantuvo II y la subida no pasa a la agregación): los tres jueces bajan a III las seis unidades de nivel II para las que la Monografía IV señala una correspondencia vasca posterior y también *selki* (A12), propuesta por comparación con una palabra prerromana conservada en una lengua romance; el crítico baja además a III las cuatro unidades propuestas como préstamos latinos y *lekaŕ*; y de nivel I bajan a II *kutu* y *ekiar* (contexto documental, no prueba material) por unanimidad, y *śalir*, *kitar* y *oŕkei* según el juez. De las cuatro previsiones del plan se cumple la principal y fallan dos (la cuarta no es evaluable: el grupo I queda con menos de cuatro unidades comparables): con la clasificación menos favorable (el nivel más bajo dado por cualquier juez: 3 unidades de nivel I, 11 de nivel II y 22 de nivel III), el euskera sigue primero en el grupo de niveles I y II, con 11 unidades comparables, a −6,6 frente a −2,2 del albanés; con la clasificación de cada juez por separado, −6,6 en los tres casos. Las dos previsiones secundarias no se cumplen: el jurado rebajó 12 de las 19 unidades de nivel II (se habían previsto entre dos y cinco) y cinco de las ocho de nivel I (se había previsto ninguna), porque aplicó el criterio escrito de forma más estricta que el autor en dos puntos: cualquier paralelo mencionado, aunque posterior, cuenta como apoyo, y el nivel I exige prueba externa al texto. El grupo de nivel III según el jurado (17 comparables) da −10,8, y el de nivel I solo queda con una unidad y no puede calcularse. La lectura es la siguiente: las unidades en que el autor tenía el euskera a la vista se parecen más al euskera que las demás, lo que es compatible con alguna influencia de esa comparación en la magnitud; pero las 11 unidades en cuya prueba un jurado ciego, con el criterio más desfavorable, no encuentra ninguna lengua viva bastan por sí solas para situar al euskera primero con una separación de más de cuatro unidades.

Como la primera pregunta hace contar como apoyo cualquier paralelo mencionado, se hizo al mismo jurado, en sesiones nuevas y también declarada antes de enviar (declaración 10), una segunda pregunta: dejando aparte el paralelo que la ficha mencione, ¿basta la prueba restante por sí sola? Se había previsto que volvieran al nivel II siete unidades: las seis con paralelo posterior y *selki*. Volvieron tres (*bekoŕ*, *alate*, *laku*) y permanecieron en III cuatro (*aŕeka*, *aŕta*, *baites* y *selki*): la expectativa no se cumple. El criterio contrario declarado, que más de dos de las seis con paralelo permanecieran en III, se alcanza con tres. En cambio, los jueces bajan a III otras ocho unidades de nivel II cuya prueba documental es corta (*lekaŕ*, *oŕtin*, *iunstir*, *akari*, *uskeike*, *baŕbin*, *bale*, *saltu*). La concordancia entre jueces es menor con esta pregunta (κ de Fleiss 0,60), que exige más juicio. El grupo clasificado como I o II a partir de las fichas cambia así de composición pero apenas de tamaño (12 unidades en las dos preguntas) y mantiene el primer puesto del euskera, algo mayor en magnitud: −8,6 frente a −3,1 del catalán; esto no certifica la independencia histórica de cada glosa. Las dos preguntas miden cosas distintas (exposición a la objeción de circularidad; suficiencia de la prueba documental) y se publican juntas, con las respuestas íntegras (`2_criterios/jurado/`).

**Tamaño de los diccionarios.** Una lengua con un diccionario grande tiene más candidatas y podría obtener por ello valores más extremos. Declarado antes de calcularlo: la correlación de Spearman entre el número de formas y el valor *z* de las 32 lenguas del Wikcionario es −0,34 (−0,38 sin el euskera), es decir, débil y en el sentido de que los diccionarios grandes obtienen valores algo más marcados; el euskera del Wikcionario tiene 3.814 formas, el puesto 21 de 32 por tamaño (mediana, 6.646), y los cinco diccionarios mayores (finés, 99.103 formas; rumano; latín; húngaro; catalán) quedan entre +1,0 y −3,0. El tamaño del diccionario vasco, el puesto 21 de 32, descarta que el valor del euskera se deba a tener el diccionario mayor; la correlación observada no elimina todos los efectos posibles de tamaño, cobertura o número de candidatas, y aconseja no interpretar diferencias pequeñas entre lenguas de tamaños muy distintos.

**Significados cambiados.** Si la prueba mide una relación entre significados y formas, debe dejar de dar resultado cuando los significados se asignan mal. A un número creciente de unidades, elegidas al azar, se les dio el significado de otra unidad de la lista, y la prueba se repitió 300 veces en cada caso con tres diccionarios del euskera.

| Unidades con el significado cambiado | Open Data Euskadi | Wikcionario | WordNet |
|---|---|---|---|
| Ninguna | −11,0 | −12,6 | −11,6 |
| 5 | −9,4 | −10,7 | −9,8 |
| 10 | −7,5 | −8,8 | −8,0 |
| 15 | −5,7 | −6,6 | −6,3 |
| 20 | −4,0 | −4,6 | −4,5 |
| Las 30 | −0,3 | −0,6 | −0,6 |

*Valor mediano del euskera. Los valores de la primera fila difieren algo de los de la tabla 6 porque este cálculo usa sus propios sorteos (200).*

Con todos los significados cambiados el valor queda en el nivel del azar: las formas ibéricas no se parecen a palabras del euskera en general, sino a las del significado propuesto para cada una. Y el valor desciende de manera gradual: con la mitad de los significados cambiados al azar, el valor mediano (de −5,7 a −6,6) sigue siendo más marcado que el de cualquier otra lengua con la lista completa (−4,1), aunque no en todas las repeticiones: con Open Data Euskadi, el percentil 95 de las 300 es −3,6 y el caso menos marcado, −1,8. Este ensayo describe cómo responde la prueba a errores repartidos al azar; no mide cuántos de los significados propuestos son correctos.

### 8.5 Contraste principal: permutación de los significados y corrección por el número de lenguas

Las pruebas anteriores miden el azar sustituyendo las candidatas por palabras del diccionario. Cabe una segunda forma de medirlo, que no sortea ninguna palabra: dejar las formas ibéricas y las candidatas como están y cambiar solo qué significado corresponde a cada unidad. Es el procedimiento de Oswalt (1970) y Kessler (2001), adaptado a la medida de distancia. Si las formas ibéricas se parecieran a las palabras del euskera en general, y no a las del significado propuesto para cada una, cualquier reparto de los significados daría un valor semejante al real.

**Procedimiento.** Con las 30 unidades y las 32 lenguas del Wikcionario que tienen candidatas para al menos el 40 % de ellas, se calcula la distancia de cada unidad a las candidatas del significado de cada una de las demás. El valor real es la media de las distancias de cada unidad a su propio significado. Se compara con 100.000 repartos al azar de los significados entre las unidades. La probabilidad se multiplica por el número de lenguas comparadas (corrección de Bonferroni). La prueba, lo que se esperaba de ella y lo que contaría en contra se fijaron antes de ejecutarla.

**Tabla 10 ter. Permutación de los significados (100.000 permutaciones)**

| Lengua | Valor | Permutaciones que igualan o mejoran la asignación propuesta | Probabilidad corregida |
|---|---|---|---|
| **Las 30 unidades, 32 lenguas** | | | |
| Euskera (Wikcionario) | −10,1 | Ninguna | 0,0003 |
| Gallego | −4,0 | 7 | 0,003 |
| Albanés | −3,1 | 118 | 0,04 |
| Tagalo | −3,1 | 168 | 0,054 |
| Catalán | −2,7 | 473 | 0,15 |
| Asturiano | −2,7 | 582 | 0,19 |
| **Sin las cuatro unidades propuestas como préstamos latinos, 31 lenguas** | | | |
| Euskera (Wikcionario) | −9,8 | Ninguna | 0,0003 |
| Gallego | −2,6 | 603 | 0,19 |
| Albanés | −2,4 | 1.019 | 0,32 |
| Tagalo | −1,6 | 5.576 | 1 |
| **Las 30 unidades, 32 lenguas, intercambiando los significados solo entre unidades de la misma longitud** | | | |
| Euskera (Wikcionario) | −8,3 | Ninguna | 0,0003 |
| Gallego | −4,2 | 5 | 0,002 |
| Tagalo | −3,6 | 33 | 0,01 |
| Catalán | −2,8 | 299 | 0,10 |
| **Las 26 unidades sin los préstamos latinos, 31 lenguas, intercambiando los significados solo entre unidades de la misma longitud** | | | |
| Euskera (Wikcionario) | −7,6 | Ninguna | 0,0003 |
| Gallego | −3,0 | 240 | 0,07 |
| Tagalo | −2,1 | 2.294 | 0,71 |
| Catalán | −1,8 | 3.895 | 1 |

*Con los demás diccionarios del euskera el resultado es el mismo: Open Data Euskadi, −9,1; Azkue, −8,7; WordNet, −9,3; ninguna permutación de 100.000 en ninguno de los tres. Con WordNet, el castellano queda en −1,6.*

**Lectura.** Ninguna de las 100.000 permutaciones muestreadas iguala o mejora la asignación propuesta. El resultado no depende de cómo se sorteen las palabras del diccionario, porque aquí no se sortea ninguna. Con las 30 unidades, el gallego supera también el umbral corregido, y el albanés queda en el límite (0,04); no estaba previsto, y la causa es la del apartado 8.1: retiradas las cuatro unidades propuestas como préstamos latinos, el gallego (0,19) y el albanés (0,32) pierden la significación y el euskera es la única lengua de las 31 que la conserva. El tagalo no la tenía (0,054).

**Permutación condicionada por la longitud.** En la permutación libre, una unidad corta puede recibir el significado de una larga, cuyas candidatas son de otra longitud; parte de la diferencia entre el valor real y los permutados podría deberse a eso y no al significado. Por indicación de la auditoría externa se añadió una variante en la que los significados solo se intercambian entre unidades cuya forma tiene la misma longitud. La variante y su previsión se declararon con fecha pública antes de ejecutarla; la previsión literal era que el euskera conservara la menor probabilidad corregida y que esta quedara por debajo de 0,05. Se cumple, y además ninguna de 100.000 permutaciones iguala la asignación propuesta (probabilidad corregida, 0,0003); 27 de las 30 unidades pueden cambiar de significado, y las permutaciones distintas posibles son del orden de 10^16. El valor es menos extremo bajo este azar (−8,3 frente a −10,1); como cambian a la vez la media y la desviación del azar, la diferencia no cuantifica una proporción de la afinidad atribuible a la longitud. La variante agrupa por la longitud de la primera forma de cada unidad; siete unidades tienen variantes de otra longitud, de modo que no controla todas las longitudes que intervienen en la medida. Con esta variante superan también el umbral corregido el gallego y el tagalo. Sin las cuatro unidades propuestas como préstamos latinos, los dos pierden la significación (0,07 y 0,71) y el euskera la conserva (−7,6; ninguna de 100.000; 0,0003), igual que en la permutación libre.

**La prueba de sustitución con 20.000 sorteos.** Con 500 sorteos la menor probabilidad que puede obtenerse es 0,002, insuficiente para corregir por 32 lenguas. Repetida con 20.000 sorteos para el euskera (Wikcionario), el valor es −12,3 y ningún sorteo iguala al real: la probabilidad es 0,00005 (1 / 20.001) y, corregida por las 32 lenguas, 0,0016.

## 9. Réplica de los resultados

El repositorio que acompaña a este trabajo reproduce los resultados computacionales identificados en el Anexo E; las excepciones (muestras que conservan la semilla numérica original, figuras, repeticiones largas) se indican en los apartados 10, A.5, D.2 y F.3. El artículo y el repositorio dan las mismas cifras: las de las tablas son las que producen los programas publicados con su semilla.

**Qué contiene el repositorio.**

| Carpeta | Contenido |
|---|---|
| `1_fuentes_lexicas/` | Todos los datos empleados, con una ficha de cada fuente: origen, fecha, licencia y si es copia de la fuente pública o archivo derivado de ella |
| `2_criterios/` | Los criterios del estudio, con su justificación y los usos equivalentes publicados |
| `3_algoritmos/` | Los algoritmos, con un ejemplo, su origen y en qué se apartan de sus precedentes |
| `4_programas/` | Un programa por tabla y un paquete común (`ibcomp`) |
| `5_especificacion/` | La especificación funcional detallada, que permite rehacer los programas sin ver el código |
| `resultados/` | La salida de cada programa y los resultados esperados, tabla a tabla |

La documentación está en español y en inglés.

**Datos derivados y fuentes públicas.** Los archivos del corpus ibérico (Hesperia), de la clasificación de las formas (Moncunill y Velaza 2019), del diccionario de Azkue y del léxico reconstruido de Trask son derivados de esas fuentes y se citan como tales. Para una réplica independiente se recomienda, como primer paso, obtener las fuentes públicas de su origen (Anexo C) y usar los archivos derivados como contraste.

**Tres maneras de comprobar el estudio.**

| Nivel | Qué se hace | Qué se obtiene |
|---|---|---|
| Comprobación rápida | Ejecutar `comprobacion_rapida.py` (unos segundos) | Verifica las reglas de reducción, la medida y los valores que no dependen de sorteos |
| Repetición | Ejecutar los programas | Las mismas cifras de las tablas 1, 2 y 4 a 15, de los apartados 8.2, 8.4 y 8.5 y del Anexo A.3 (este último, en su parte con las clases SCA) |
| Réplica independiente | Escribir programas propios a partir de la especificación funcional y de las fuentes públicas | Los valores que no dependen de sorteos deben coincidir; los demás, dentro del margen indicado en los resultados esperados |

**Reproducibilidad.** Cada cálculo con sorteos usa su propio generador, sembrado con un texto fijo, de modo que el resultado no depende del orden en que se ejecuten los programas. Con otra semilla o con otro generador, los valores que dependen de sorteos varían (apartado 7 y Anexo B.7). Las pruebas nuevas, y las correcciones de los programas posteriores a la auditoría del código, se declaran en el repositorio (`resultados/DECLARACIONES_PREVIAS.md`) antes de ejecutarse; la fecha de cada declaración y de cada resultado queda en el historial del repositorio, privado durante la revisión y público con la publicación.

Las 40 unidades ibéricas (30 de los plomos y 10 del léxico metrológico) se ofrecen además en formato CLDF. [PENDIENTE: dirección del repositorio y DOI del depósito]

## 10. La longitud de las palabras y el alcance del método

El método tiene un límite que conviene declarar: necesita palabras de cierta extensión. Cuando lo que se compara son segmentos de una o dos sílabas (raíces aisladas, formantes, secuencias sin delimitar), cualquier lengua de estructura silábica sencilla ofrece formas próximas. En esas condiciones quedan en cabeza lenguas como el suajili o el tamil, sin relación posible con el ibérico: la medida refleja entonces la forma de la sílaba, y no una relación entre léxicos. Por eso el análisis se ha hecho con palabras completas. Las formas muy largas producen un ruido equivalente, en sentido contrario: se aproximan a cualquier lengua de palabras largas, y no hay certeza de que no sean errores de corte, es decir, dos o más palabras escritas sin separador o compuestos sin segmentar. Por eso tampoco se incluyen.

Por la misma razón, las pruebas clásicas basadas en la consonante inicial de cada palabra (Ringe 1992; Kessler 2001) tienen aquí un rendimiento limitado: están concebidas para listas de cien o más conceptos de vocabulario básico, y con el material disponible solo alcanzan resultado en la serie numeral.

Se hicieron además, en la fase inicial, tres ensayos sobre material que queda fuera del objeto de este trabajo, y ninguno dio un resultado específico para lengua alguna; esos ensayos no forman parte del repositorio y lo que sigue es su descripción, no un resultado reproducible con él. Las razones son las expuestas en este apartado. Los sufijos gramaticales son formas de una o dos letras, que coinciden con las de cualquier lengua con declinación. El vocabulario de los plomos tomado en bloque está formado por secuencias largas sin segmentar, que se aproximan a cualquier lengua de palabras largas. Y el léxico de estelas, vasos y monedas interpretado por otros autores es un conjunto de quince palabras, la mitad de ellas nombres del propio objeto inscrito, demasiado reducido y heterogéneo para una prueba de este tipo.

## 11. Segunda parte: el tipo de relación

La primera parte establece que el léxico ibérico analizado es más próximo al euskera que a las demás lenguas comparadas y que esa proximidad es extrema bajo los modelos de azar examinados. Queda por examinar de qué tipo es la relación. Esta segunda parte es menos concluyente que la primera: los significados estables disponibles son once, y las pruebas se apoyan en comparaciones con parejas de control más que en un contraste formal. Sus resultados se presentan como indicios: describen a qué tipo de parejas de control se parece lo observado, y no permiten excluir ninguna de las explicaciones. Se plantean dos preguntas sucesivas. La primera: ¿tiene la afinidad la forma que deja el préstamo o la que deja el origen común? La segunda, dentro del origen común: ¿hay una transición gradual hacia el euskera en el territorio ibérico, como en un continuo de variedades, o la proximidad es la misma en todas partes, como entre dos ramas ya separadas?

Las dos pruebas, las parejas de control, las previsiones y lo que contaría en contra se fijaron por escrito antes de ejecutarlas, conforme a la práctica del registro previo, que separa el análisis confirmatorio del exploratorio (Roettger 2021); aquí el registro es interno y fechado, no un depósito público.

### 11.1 Significados estables y poco estables

**Fundamento.** Los significados básicos (uno, dos, dar, tierra) rara vez se toman en préstamo; los técnicos y culturales se toman con facilidad (Tadmor, Haspelmath y Taylor 2010). En lenguas emparentadas coinciden también los básicos; en lenguas que solo han tenido contacto coinciden sobre todo los demás. Es el principio del análisis por rangos de Chen Baoya, que divide las listas de Swadesh en un rango básico (las 100 palabras) y otro menos básico (las 100 restantes) y considera emparentadas dos lenguas solo si la semejanza es mayor en el primero (expuesto en Wang y Minett 2005: 123-124, que advierten de que su fiabilidad no estaba establecida). Un procedimiento afín, con sublistas de significados muy estables y poco estables, se aplicó al quechua y al aimara, y llevó a sus autores a considerar el contacto la explicación más probable de las semejanzas entre ambos (McMahon *et al.* 2005). Aquí se adapta ese principio al léxico disponible y, dada la advertencia citada, su capacidad de distinguir se comprueba con parejas de lenguas de relación conocida.

**Regla.** Un significado se considera estable si su glosa principal figura en la lista Leipzig–Yakarta de 100 significados o en la lista de Swadesh de 207. De los 40 significados del léxico ibérico analizado resultan estables 11: uno, dos, tres, cuatro, cinco, dar, hacer, tierra, hierba, camino y monte. Los otros 29 son poco estables (los numerales del seis al veinte, mitad, plata, finca, tributo, testigo, etc.).

**Medida.** La de la primera parte. Para cada grupo se da la *ventaja*: la diferencia entre la distancia media a palabras al azar de la misma longitud y la distancia media a las palabras del mismo significado. Un valor de cero corresponde al azar.

**Controles.** La prueba se aplicó, sobre los mismos 40 significados, a 42 parejas de lenguas de relación conocida (Anexo B.9).

**Tabla 11. Parejas de control: ventaja según el tipo de relación**

| Relación | Parejas | Significados estables | Poco estables |
|---|---|---|---|
| Emparentadas cercanas (catalán–occitano, gallego–asturiano, estonio–finés…) | 7 | 0,41 | 0,28 |
| Emparentadas lejanas (irlandés–latín, húngaro–finés, tagalo–malayo…) | 12 | 0,13 | 0,06 |
| Parentesco lejano y préstamos (albanés–latín, galés–latín) | 2 | 0,15 | 0,06 |
| Solo contacto (euskera–latín, maltés–siciliano, húngaro–turco, tagalo–gallego…) | 13 | 0,04 | 0,05 |
| Sin relación | 8 | −0,01 | −0,01 |

*En las lenguas emparentadas la ventaja es mayor en los significados estables (en 20 de las 21 parejas). En las de solo contacto es pequeña y no se concentra en los estables (es mayor en ellos en 5 de 13). Con esta lista de significados, las medias de los dos tipos son distintas; las parejas comparten lenguas y no son observaciones independientes.*

El valor más alto entre las parejas de contacto es el del tagalo con el catalán (0,15 y 0,13) y con el gallego (0,13 y 0,11): el tagalo tomó del castellano, junto a miles de palabras, también los numerales, y por eso su ventaja alcanza a los significados estables. Sin los numerales del dos al cinco, la ventaja en los estables baja a 0,00 y a algo más de 0,05. Es el caso de contacto más intenso de la lista, y queda a menos de un tercio del valor del ibérico frente al euskera.

**Tabla 12. Ibérico frente al euskera**

| Conjunto | Significados | Ventaja |
|---|---|---|
| Estables | 11 | 0,53 |
| Poco estables | 27 | 0,45 |
| Estables, sin los numerales del dos al cinco | 7 | 0,45 |
| Estables, sin *saltu* (préstamo latino propuesto) | 10 | 0,59 |

En los grupos originales (estables y poco estables), las demás lenguas no superan aproximadamente 0,15 frente al ibérico; al retirar los numerales del dos al cinco, el galés alcanza 0,21 en los estables.

**Tabla 13. Ibérico frente al euskera, según cómo se obtuvo el significado**

| Origen del significado | Significados | Ventaja |
|---|---|---|
| Con apoyo externo (grado A): uno, diez, veinte, plata, mitad, hacer, escrito | 7 | 0,56 |
| Por la casilla que ocupa en los documentos | 18 | 0,31 |
| Con apoyo de la toponimia | 6 | 0,55 |
| Numerales del dos al ocho (valor por posición en la serie) | 7 | 0,74 |
| Los cuatro préstamos latinos propuestos | 4 | 0,24 (frente al gallego, 0,34) |

*El reparto del ibérico con el euskera es el que presentan las parejas emparentadas de la muestra: la ventaja es alta en los significados estables, y más alta en ellos que en los demás. Ninguna de las 13 parejas de solo contacto se acerca a esos valores. Con once significados estables y 42 parejas no independientes, es un indicio y no una prueba.*

La ventaja crece con la ayuda que el euskera prestó a la asignación del significado: es máxima en los numerales cuyo valor se establece por su posición en la serie y en los términos con apoyo toponímico. Por eso el valor del conjunto no debe citarse solo. Los dos conjuntos en los que el significado se obtuvo sin esa ayuda dan 0,56 (dato externo) y 0,31 (casilla documental): las dos cifras quedan por encima de todas las parejas de contacto y de la media de las emparentadas lejanas.

**Límites.** Siete y dieciocho significados son pocos. Las parejas de control comparten lenguas y no son observaciones independientes, de modo que las medias por tipo se dan como descripción. La clasificación en estables y poco estables procede de listas generales, no pensadas para este vocabulario. En las parejas de contacto, el gallego y el catalán sustituyen al castellano, y la base no incluye el árabe ni el persa.

### 11.2 La proximidad al euskera por zonas

**Fundamento.** Si el ibérico y el vasco-aquitano hubieran formado un continuo de variedades, las variedades ibéricas más próximas al territorio vasco-aquitano deberían parecérsele más. Ferrer i Jané (2023: 527) considera plausible que el ibérico formara un continuo que pudo llegar a enlazar con el vasco-aquitano, aunque prefiere partir de dos ámbitos separados. La relación entre distancia lingüística y distancia geográfica es el objeto de la dialectometría: en los dominios estudiados, la diferencia lingüística crece con la distancia de forma amortiguada, y la geografía explica en torno a una cuarta parte de la variación (Nerbonne 2010).

**Procedimiento.** El corpus se divide en cinco zonas, de norte a sur, por la sigla de procedencia de Hesperia: Narbonense y Rosellón; Cataluña; valle del Ebro y Castellón; Valencia; sudeste. En cada una se calcula el perfil de combinaciones de sonidos (apartado 5.2), que no usa significados, y su distancia a las 107 lenguas, con todas las formas de la zona. Como las zonas tienen tamaños muy distintos, se comprueba aparte, con muestras igualadas en tamaño (300 por zona), que el puesto del euskera no depende del tamaño.

**Tabla 14. Proximidad al euskera por zona** (distancia relativa, en unidades de desviación respecto a las 107 lenguas; más negativo, más próximo; calculada con todas las formas de cada zona, sin igualar los tamaños)

| Zona | Inscripciones | Plomos | Formas en plomos | Puesto del euskera | Solo plomos | Todas las inscripciones |
|---|---|---|---|---|---|---|
| Narbonense–Rosellón | 607 | 14 | 205 | 1.º | −2,16 | −2,25 |
| Cataluña | 448 | 33 | 206 | 1.º | −2,52 | −2,37 |
| Ebro–Castellón | 205 | 29 | 225 | 1.º | −2,39 | −2,37 |
| Valencia | 221 | 36 | 353 | 1.º | −2,49 | −2,42 |
| Sudeste | 105 | 23 | 134 | 1.º | −2,37 | −2,42 |

*El euskera es la lengua más próxima en las cinco zonas, con los plomos y con todas las inscripciones, y también al reducir todas las lenguas a los sonidos que el ibérico escribe. No hay tendencia de norte a sur: la zona más septentrional no es la más próxima.*

**Un límite en la zona septentrional.** En los plomos de Narbonense–Rosellón, que son solo 14, el euskera (0,197) y el latín (0,200) quedan casi a la misma distancia. Al igualar todas las zonas a 134 formas, el euskera es la lengua más próxima en 197 de 300 muestras de esa zona, y el latín en las demás; en las otras cuatro zonas lo es en las 300. Con todas las inscripciones, el euskera es el primero en las 300 muestras de las cinco zonas. El primer puesto de esa zona con los plomos solos no es, por tanto, firme.

**Variación dentro del ibérico.** Dos muestras de la misma zona difieren en 0,073; de zonas vecinas, en 0,083; de zonas no vecinas, en 0,092; de los dos extremos, en 0,101. El ibérico varía poco de una zona a otra, y lo poco que varía sigue el orden geográfico. En el sudeste se emplean tres signarios, lo que puede explicar parte de esa diferencia. Cualquier zona dista del euskera entre 0,16 y 0,20, bastante más de lo que distan entre sí.

**Lectura y límite.** La proximidad al euskera es uniforme: no se observa, en las zonas documentadas, el gradiente norte-sur que un continuo haría esperar. La ausencia de datos de la posible zona de transición y la naturaleza de la medida impiden convertir esa uniformidad en prueba de dos ramas separadas. Debe tenerse en cuenta que no se conservan textos ibéricos de la zona donde ese enlace habría estado (Navarra, alto Aragón, Pirineo occidental): la prueba informa sobre el ibérico documentado, no sobre posibles variedades de transición.

### 11.3 El perfil de combinaciones de sonidos en parejas de contacto

**Fundamento.** En la prueba sin significados, el euskera es la lengua de perfil más próximo al ibérico (apartado 7.4). Cabe preguntar si esa proximidad podría ser efecto de un préstamo masivo de vocabulario entre las dos lenguas. Como referencia se toman lenguas de las que se sabe que han tomado de otra una parte grande de su léxico, y se anota qué puesto ocupa en ellas la lengua donante. Es una descripción de 17 parejas, no un contraste: no hay grupo de comparación ni previsión cuantificada.

**Procedimiento.** Con la base de 107 lenguas y la misma medida del apartado 5.2, para 17 parejas fijadas de antemano se anota el puesto que ocupa la lengua donante entre las otras 106.

**Tabla 15. Puesto de la lengua donante por proximidad de perfil (de 106)**

| Lengua que toma – lengua que da | Puesto de la donante | Lengua de perfil más próximo |
|---|---|---|
| Euskera – castellano / latín / catalán | 76 / 19 / 65 | Tsez |
| Japonés – chino mandarín | 73 | Ainu |
| Coreano – chino mandarín | 72 | Tsez |
| Persa – árabe | 105 | Checheno |
| Turco – árabe / persa | 94 / 103 | Azerí |
| Armenio – persa | 96 | Hebreo |
| Hindi – persa | 87 | Kurdo |
| Albanés – latín / griego | 17 / 85 | Rumano |
| Inglés – francés | 32 | Alemán |
| Finés – sueco | 27 | Carelio |
| Húngaro – turco | 21 | Sueco |
| Rumano – búlgaro | 7 | Albanés |
| Bretón – francés | 5 | Galés |

*La lengua donante no es en ningún caso la de perfil más próximo, y solo en una pareja está entre las cinco primeras. Su puesto mediano es el 72 de 106.*

**Lectura.** En estas 17 parejas y con esta base, ninguna lengua donante es el vecino de perfil más próximo de la lengua que tomó su léxico: el euskera, tras dos mil años de préstamos latinos y romances, tiene el castellano en el puesto 76. Los dos casos en que la donante queda cerca (bretón y francés, rumano y búlgaro) son lenguas de la misma familia y de la misma área. Lo observado entre el ibérico y el euskera, que es el primer puesto, no se da en ninguna de las parejas de préstamo examinadas.

**Límite.** El dato no permite excluir el contacto como causa de la proximidad de perfil. Las parejas son 17, se eligieron por ser casos conocidos de préstamo léxico y comparten lenguas; no incluyen situaciones de convergencia prolongada entre lenguas vecinas de tipo parecido, que es precisamente lo que el perfil también refleja (apartado 7.4). Y lo que se compara en ellas es el vocabulario básico de NorthEuraLex, el menos afectado por el préstamo.

### 11.4 Regularidad de las correspondencias entre sonidos

En el método comparativo, la regularidad de las correspondencias entre sonidos constituye evidencia relevante que debe examinarse, más que el parecido de las palabras; no identifica por sí sola el mecanismo histórico, porque también puede acompañar a préstamos antiguos. Con 40 parejas no puede establecerse un sistema de correspondencias; sí puede medirse si hay más regularidad de la que da el azar. Declarado antes de ejecutar (entrada 8): para cada unidad se tomó la palabra del euskera (Wikcionario) de su significado a menor distancia y se alineó con la forma ibérica, en clases de sonidos, con los mismos costes que la distancia del estudio; cada columna de la alineación es una correspondencia. La regularidad se mide como la proporción de columnas que van al correspondiente más frecuente de su clase, calculada solo sobre las columnas no idénticas (R′), que son las que prueban una correspondencia sistemática y no una identidad. Azar: 1.000 permutaciones de los significados (cada forma ibérica con la palabra vasca de otra unidad) y, como referencia, el mismo cálculo con las otras 31 lenguas del Wikcionario.

Resultado: 38 parejas, 195 columnas, 77 no idénticas; R′ = 0,44, frente a una mediana de 0,32 en las permutaciones y un percentil 90 de 0,34: ninguna de las 1.000 permutaciones la alcanza. Entre las 32 lenguas, el euskera es primero por R′ (siguiente, el lituano, 0,385). Una comprobación añadida después de ver el resultado (R′ sube por azar cuando hay pocas columnas no idénticas) iguala el tamaño a 77 columnas en todas las comparaciones: frente a la permutación el euskera sigue por encima de las 1.000 (mediana 0,38); entre lenguas sigue primero, pero casi igualado con el lituano (0,442 frente a 0,438). Las correspondencias no idénticas más frecuentes son huecos y alternancias vocálicas (*a*:−, *R*:−, *i*:*a*, *a*:*e*); solo dos consonánticas se repiten (*K*:*R* y *P*:*M*, dos veces cada una). El nulo permuta las candidatas ya seleccionadas (una por significado, la más próxima a su forma ibérica), de modo que es condicional a esa selección; la auditoría independiente repitió la selección en cada emparejamiento permutado y con los costes literales 1/1 (dos ambigüedades del plan, anotadas en la declaración 8) y el resultado se conserva en ambos casos. La previsión (percentil 90 y tres primeros puestos) se cumple, pero la lectura es modesta: hay más regularidad de la que da el azar en los emparejamientos, y la ventaja sobre otras lenguas en la comparación de igual tamaño es mínima. Esta prueba no decide entre herencia y préstamo; una correspondencia regular puede darse también en préstamos de una misma época, y las correspondencias consonánticas, que serían las decisivas, son demasiado pocas.

### 11.5 Gradiente de prestabilidad

La tabla 11 opone dos grupos de significados; aquí se usa una escala continua: la puntuación de prestabilidad de cada significado en la base mundial de préstamos (Haspelmath y Tadmor 2009, archivo `parameters.csv` de la edición CLDF, columna *Borrowed score*), para las 35 unidades cuyo significado figura en su lista central (la correspondencia unidad–significado se fijó y publicó antes de calcular; entrada 9). La herencia predice que los significados más prestables se parezcan menos al euskera (correlación positiva entre el valor *z* individual de cada unidad y la prestabilidad); el préstamo cultural, lo contrario. Resultado: ρ de Spearman −0,15 con el Wikcionario (34 unidades) y −0,04 con Open Data Euskadi (35); en las otras 32 lenguas del Wikcionario la misma correlación va de −0,45 a +0,31, con mediana −0,00. No se cumple la previsión direccional (ρ positiva), pero sí la general: con este material no se establece un gradiente concluyente de la afinidad respecto de la prestabilidad, que era el resultado previsto como más probable. (El programa generó 500 sorteos nuevos donde el plan decía reutilizar los de `t15`; la desviación queda anotada en la declaración 9.) El léxico de los plomos es casi todo del registro económico, con prestabilidades entre 0,1 y 0,6 y sin los campos (cuerpo, pronombres, parentesco) en que la herencia se muestra con más claridad.

### 11.6 Origen etimológico y fonotaxis de las palabras vascas emparejadas

Una explicación alternativa a la herencia y al contacto antiguo es la fuente común: que el ibérico y el euskera se parezcan porque ambos tomaron del latín o del romance las mismas palabras. Si fuera así, las palabras vascas que mejor emparejan con las unidades ibéricas serían, en proporción anómala, préstamos latinos o romances del euskera. Se usaron dos procedimientos de la bibliografía sobre detección de préstamos, en su forma más barata: la clasificación etimológica de cada palabra de la lengua receptora (principio de la base mundial de préstamos, que no incluye el euskera) y la detección de préstamos por su fonotaxis atípica en una lista monolingüe (Miller y otros 2020, de rendimiento modesto según sus autores). La fuente es la nota etimológica del Wikcionario inglés (5.513 registros con nota; una misma forma reducida puede corresponder a varios lemas), clasificada por una regla fija publicada antes de ejecutar (entrada 11): *préstamo* («Borrowed from…», «From Spanish / Latin / French / Occitan…»), *heredado* («Proto-Basque», «Inherited from…»), *desconocido* (lo demás), *sin dato*. Para cada unidad se tomó la candidata vasca a menor distancia (como en 11.4) y la clase de sus lemas elegibles —los que comparten términos de glosa con el significado de la unidad, para no mezclar homógrafos—, y la proporción de préstamos se comparó con la de todas las candidatas de los mismos significados y con la del léxico con nota (hipergeométrica en ambas colas y 10.000 sorteos de una candidata al azar por unidad). Como la hipótesis que se contrasta es la fuente latina o romance, los préstamos se separan por donante (romance/latín frente a otros). Control de recuperación: las cuatro unidades propuestas como préstamos latinos debían emparejar con préstamos. La primera ejecución mezclaba homógrafos y clasificaba la fonotaxis con las candidatas dentro del entrenamiento; la auditoría externa lo señaló y la prueba se corrigió y se reejecutó, con la corrección anotada en la declaración 11 y los resultados de la primera versión conservados en el repositorio.

Resultado (versión corregida). De las 38 unidades con candidata, 31 tienen lemas elegibles con nota: 2 emparejan con préstamos —*koŕta*–*borda*, de fuente romance, y *kutu*–*gutun*, cuya nota lo deriva del árabe, etimología que aquí se recoge como clasificación del Wikcionario y no se da por establecida—, de modo que solo 1 de 31 es de fuente romance o latina; 18 emparejan con heredadas y 11 con palabras de origen desconocido. La proporción de préstamos, 0,065, es menor que la de referencia (0,125 entre las candidatas de los mismos significados; 0,126 en el léxico con nota): la probabilidad hipergeométrica de 2 o más préstamos es 0,96, y la de 2 o menos, 0,16. No se detecta, pues, un exceso de etiquetas de préstamo en conjunto bajo las referencias utilizadas (estas probabilidades cuentan los dos préstamos de cualquier donante, no solo el romance o latino, y por tanto no son un contraste específico de una fuente romance común); el déficit tampoco es significativo, y una probabilidad alta de «2 o más» no prueba nada por sí misma. El análisis no excluye ni cuantifica una fuente común. El control de recuperación solo se cumple en uno de cuatro casos (*koŕta*–*borda*; *bale* empareja con *balio*, sin nota; *oŕtin* con un compuesto cuya nota no encaja en la regla; *saltu* con *mendi*, heredada, porque el Wikcionario no ofrece entre las palabras de «monte, dehesa» un descendiente de *saltus*): la prueba solo detecta un préstamo cuando la candidata más próxima es ella misma el préstamo y tiene nota, y ese control incompleto no calibra la potencia frente a una fuente común. La fonotaxis (modelo de trigramas de clases con suavizado de Kneser–Ney sobre 540 formas heredadas y otro sobre 423 préstamos; acierto en validación cruzada, 0,84 y 0,80), clasificando cada candidata fuera de muestra (excluida del entrenamiento), da 27 de 38 como heredadas y 11 como préstamos (con las candidatas dentro del entrenamiento, como en la primera versión, 8). Trece candidatas llevan en su nota una comparación con el ibérico (*erdi*, *lagun*, *egin* y los diez numerales); esa mención no interviene en la clasificación. Una comprobación posterior, no declarada, con una regla más amplia que recoge «borrowed from» en cualquier posición de la nota da 3 préstamos de 31 (2 romances; 0,097, frente a 0,167 y 0,209 de referencia), con la misma lectura. En conjunto: la prueba no detecta, con sus reglas y su referencia, una concentración de préstamos romances en las parejas; pero el control de recuperación incompleto limita el alcance de esa ausencia, y ni la etimología del Wikcionario ni la fonotaxis distinguen la herencia de un préstamo antiguo ya nativizado, de modo que la prueba no dice nada contra el contacto antiguo.

### 11.7 Valoración conjunta

Las tres pruebas de 11.1 a 11.3 van en el mismo sentido que la serie numeral (apartado 7.1). El reparto entre significados estables y poco estables es el de las parejas emparentadas de la muestra y no el de las de contacto; la proximidad no aumenta hacia el norte; y en las parejas de préstamo examinadas la donante no es la lengua de perfil más próximo. Son indicios, de menor peso que los resultados de la primera parte: no bastan para afirmar un origen común, pero son compatibles con él, con el ibérico ya diferenciado del vasco-aquitano y relativamente homogéneo en su territorio. En los controles seleccionados, el patrón observado se parece al de las parejas emparentadas. Los análisis no estiman la probabilidad relativa de herencia y contacto ni cubren todos los tipos de contacto; las parejas de control son pocas y no son independientes. No permiten, por tanto, establecer una preferencia firme entre las dos explicaciones. Las tres pruebas añadidas (11.4 a 11.6) no la alteran: las correspondencias son más regulares que el azar pero apenas más que las de otras lenguas en comparación de igual tamaño, no se establece un gradiente concluyente de prestabilidad, y la prueba etimológica no detecta una concentración de préstamos romances en las parejas, con un control de recuperación incompleto que limita el alcance de esa ausencia.

---

## 12. Conclusiones

**1. Grado de afinidad.** El léxico ibérico analizado es más próximo al euskera que a cualquiera de las demás lenguas comparadas. En la prueba con significados, el euskera ocupa el primer puesto con todos los diccionarios, con valores entre −9,7 y −12,8 en los diccionarios completos, frente a valores entre −3,3 y −4,8 para la lengua siguiente, que proceden en buena parte de las cuatro unidades propuestas como préstamos latinos. En la serie numeral, el euskera es la lengua más próxima entre 3.811, a menos de la mitad de distancia que la segunda. En la prueba sin significados, el perfil de combinaciones de sonidos, el euskera es también la lengua más próxima entre 107.

**2. Resultado frente a los modelos de azar examinados.** Condicionada a las unidades, los significados y las reglas adoptados, la asignación observada es extrema bajo los modelos de azar examinados. En la prueba con significados, ninguno de 20.000 sorteos iguala la proximidad observada, y ninguna de 100.000 permutaciones de los significados entre las unidades iguala la asignación propuesta, con ninguno de los cuatro diccionarios del euskera probados, ni tampoco cuando los significados solo se intercambian entre unidades de la misma longitud; corregida por las 32 lenguas comparadas, la probabilidad es de 0,0003 (apartado 8.5). Esa probabilidad, obtenida por simulación y corregida como se indica, mide la frecuencia de resultados tan extremos bajo esos modelos de azar; no es la probabilidad de que la afinidad tenga una causa determinada, ni la de que los significados sean correctos, ni la de un parentesco. En la prueba sin significados, que no tiene distribución de azar, solo 5 de las 4.618 parejas de familias distintas de la base tienen una distancia igual o menor que la ibérico–euskera (una sola con las clases reducidas); el cálculo no determina la causa de la semejanza de esas parejas (apartado 7.4). En los casos de control, ninguna de 200 muestras de lenguas sin parientes alcanza el valor ni la separación del ibérico con el euskera (el mejor valor es −6,85, en el etrusco; el sumerio no pasa de −3,75), mientras que el valor del ibérico con el euskera es del orden del que obtiene el córnico con el galés. En la serie numeral, ninguna de las 110 lenguas sin parientes en la base mundial tiene una lengua tan próxima como lo es el euskera del ibérico. En el perfil de combinaciones de sonidos, el euskera es la lengua más próxima en todos los remuestreos.

**3. Solidez y límites.** El resultado de la prueba con significados no depende del diccionario (siete fuentes del euskera: modernas, dialectal y clásica, y reconstruida; no son independientes entre sí, porque describen la misma lengua), ni de incluir las cuatro unidades propuestas como préstamos latinos, ni de ninguna unidad aislada de la lista. Se mantiene con las 24 unidades cuyo significado se obtuvo sin comparación vasca según la Monografía IV, y con las formas flexionadas y los sinónimos. No se mantiene en todos los grupos: en las 13 unidades de nivel II para las que esa monografía no señala correspondencia vasca, el euskera y el tagalo quedan prácticamente igualados, y con la reclasificación posterior de la edición final de esa monografía (11 unidades) el euskera queda segundo, tras el tagalo (apartado 8.4). El del perfil de combinaciones de sonidos se mantiene con el corpus completo y con los plomos solos, al reducir todas las lenguas a los sonidos que el ibérico escribe y frente a lenguas de otras zonas del mundo. Los límites son tres: la prueba con significados depende de que los significados propuestos sean correctos (al cambiar al azar la mitad de ellos el valor mediano sigue siendo el más marcado, pero ese ensayo no mide cuántos lo son; apartado 8.4); la clasificación de la procedencia de cada significado es del propio autor, y un jurado ciego la rebaja en 17 de 36 unidades sin que el euskera deje de ser primero en el grupo clasificado como I o II a partir de las fichas (−6,6 con 11 unidades con la pregunta estricta; −8,6 con la pregunta de suficiencia; apartado 8.4); y el perfil de combinaciones de sonidos no distingue la herencia de la tipología o del contacto de área.

**4. Causas de la afinidad.** Si no se debe al azar, la afinidad puede deberse a herencia de una lengua antecesora común, a préstamo, o a ambas cosas. Conviene precisar qué distingue esas explicaciones y qué dicen los datos sobre cada una.

*a) Qué explica peor el resultado.* La señal no depende exclusivamente de las cuatro unidades propuestas como préstamos latinos: sin ellas el euskera conserva su valor (apartado 8.1) y las lenguas romances pierden la significación en la prueba de permutación (apartado 8.5). Retirarlas no elimina por sí mismo todos los préstamos posibles ni valida la clasificación etimológica de las demás unidades. El resultado se mantiene, además, con el léxico reconstruido del euskera, anterior a su documentación, aunque este solo permite comparar la mitad de las unidades.

*b) Herencia y préstamo antiguo.* Para una palabra aislada, las dos explicaciones son indistinguibles por la forma: una palabra tomada en préstamo hace más de dos mil años ha evolucionado después igual que una heredada. Lo que las distingue es el conjunto. El préstamo se concentra en el vocabulario cultural y comercial y rara vez alcanza al vocabulario básico; la herencia se manifiesta sobre todo en este (numerales bajos, términos elementales) y, de forma decisiva, en la gramática y en la regularidad de las correspondencias entre sonidos.

*c) Lo que aporta el material analizado.* Los plomos son documentos económicos, y su vocabulario pertenece al registro más expuesto al préstamo, como muestran las cuatro unidades de origen latino. No contienen pronombres ni términos del cuerpo, y de los verbos comunes solo los dos propuestos («dar» y «hacer»). La parte de vocabulario básico que sí ofrecen es sobre todo la serie numeral, y esta es la que permite valorar la cuestión con datos:

- La serie ibérica y la del euskera están a una distancia de 0,32. En la muestra mundial de 400 lenguas con parientes, cuando la lengua más próxima está entre 0,2 y 0,5 es de la misma familia en 162 de 165 casos, y en los 63 del tramo de 0,3 a 0,4 (tabla 5; figura 3). Es una frecuencia observada en esa base, entre lenguas que tienen parientes en ella; no es la probabilidad de que el ibérico y el euskera estén emparentados.
- El préstamo de una serie numeral completa, incluidos los valores más bajos, existe (se documenta, por ejemplo, del español al chamorro o de lenguas indoarias a lenguas dravídicas vecinas). En la base, ninguna de las 110 lenguas sin parientes tiene una lengua tan próxima; la base no permite medir con qué frecuencia se presta una serie entera.
- Akbih Verdaguer (2025) ha examinado la misma cuestión desde la tipología, con las 41 lenguas de la base mundial de préstamos (Haspelmath y Tadmor 2009). El préstamo de numerales resulta allí más frecuente de lo que suele suponerse: el «uno» es préstamo seguro en cuatro lenguas, y cuatro tienen prestado todo el sistema (japonés, tailandés, yaqui y wichí) (2025: 414-415); el propio autor advierte de que esa muestra es reducida y sobrerrepresenta las lenguas con muchos préstamos (2025: 413). En los casos estudiados concurren siempre las mismas condiciones: dominio político y económico de la comunidad que presta, adopción de sus instituciones, de su religión y de su escritura, y una lengua donante que presta a varias (2025: 425). A falta de indicios de una relación de ese tipo entre iberos y vascones, el autor concluye que la explicación preferente de la semejanza de los numerales es el parentesco (2025: 426). Los datos de este trabajo son independientes de los suyos y apuntan en la misma dirección.
- La semejanza no es de identidad, como suele ocurrir en las series prestadas recientes, sino graduada: tres términos son casi idénticos y los demás muestran diferencias de detalle (*ban* / *bat*, *lauŕ* / *lau*, *borste* / *bost*, *abaŕ* / *hamar*).
- En el léxico de los plomos, las formas próximas al euskera no se limitan a los términos comerciales: incluyen términos del medio físico (tierra, vega, fuente, hierba, camino), que pertenecen a los campos semánticos menos expuestos al préstamo (Tadmor, Haspelmath y Taylor 2010, que muestran sobre 41 lenguas que la proporción de préstamos difiere de un campo semántico a otro).

*d) Lo que aporta la segunda parte.* Con menor fuerza que lo anterior, y a título de indicio, la comparación de significados estables y poco estables sitúa al ibérico y al euskera con las parejas de lenguas emparentadas de la muestra y lejos de las de solo contacto, también cuando se consideran únicamente los significados con apoyo externo o deducidos de la casilla documental (apartado 11.1). La proximidad al euskera es la misma en las cinco zonas del territorio (apartado 11.2), con la reserva de que en los plomos de la más septentrional el euskera y el latín quedan casi igualados: no se observa el gradiente norte-sur que un continuo haría esperar, lo que no basta para afirmar dos ramas separadas. Y en las 17 parejas de lenguas con préstamo intenso examinadas, la donante no es en ningún caso la de perfil más próximo, dato descriptivo que no excluye el contacto (apartado 11.3).

*e) Las explicaciones posibles, una por una.* La afinidad observada es extrema bajo los modelos nulos especificados (conclusión 2) y persiste en las comprobaciones de robustez realizadas (diccionario, tamaño, formas flexionadas, sinónimos, unidad aislada, lecturas alternativas; apartado 8); esas pruebas rechazan determinados modelos de azar y de artefacto, no todas sus formas posibles. Para discutir el origen de la afinidad se consideran cinco explicaciones, que no se excluyen entre sí y cuyas probabilidades relativas estas pruebas no estiman:

| Explicación | Qué predice | Qué dicen los datos | Estado |
|---|---|---|---|
| Origen común | Semejanza mayor en el vocabulario básico y estable; correspondencias regulares; gramática compartida | Serie numeral próxima y graduada; estables por encima de poco estables (tabla 11); correspondencias más regulares que el azar, pero apenas más que las de otras lenguas a igual tamaño (11.4); sin gradiente concluyente de prestabilidad (11.5); gramática no examinada | Compatible; no demostrado: R′ no sustituye un sistema de correspondencias ni la evidencia gramatical |
| Contacto antiguo e intenso | Semejanza concentrada en el vocabulario cultural; gradiente hacia la zona de contacto; otros indicios históricos | Sin gradiente norte-sur (tabla 14); perfil distinto al de las 17 parejas de préstamo masivo examinadas (tabla 15); sin gradiente concluyente de prestabilidad (11.5); el vocabulario analizado es en su mayoría técnico | No excluido; contribución no cuantificada. No está establecido que todo contacto relevante deba dejar el gradiente norte-sur buscado |
| Fuente latina o romance común (ambas lenguas tomaron las mismas palabras) | Las palabras vascas emparejadas serían préstamos latinos o romances en proporción anómala | 1 de 31 candidatas con nota es préstamo romance (2 de 31 contando el que el Wikcionario deriva del árabe); 0,065 frente a 0,125-0,126 de referencia, p(≥2) = 0,96 y p(≤2) = 0,16; la fonotaxis fuera de muestra clasifica 27 de 38 como heredadas; el control de recuperación solo se cumple en 1 de 4 (11.6) | No excluida ni cuantificada. Las cuatro unidades propuestas como préstamos son compatibles con esa interpretación, pero este análisis no valida su etimología. t27 no detecta un exceso con sus reglas y referencia; el control de recuperación incompleto limita el alcance de esa ausencia |
| Sesgo del proponente (el euskera influyó en los significados) | Señal concentrada en las unidades donde el autor tenía el euskera a la vista; nula en las demás | Las unidades que el jurado ciego sitúa en nivel III dan −10,8; las de niveles I y II, −6,6 frente a −2,2 de la siguiente (pregunta estricta) y −8,6 frente a −3,1 (pregunta de suficiencia) (apartado 8.4) | No descartado por la recodificación: la señal persiste con una clasificación más restrictiva de las fichas, pero la independencia de las glosas exactas no está validada |
| Tipología de área (sonidos y estructura de palabra compartidos por vecindad) | Perfil próximo; prueba con significados cerca del azar | Perfil próximo (0,153), pero prueba con significados muy alejada del azar y de las demás lenguas de la misma área | Puede contribuir al perfil; su contribución, y su combinación con la selección de significados, no están cuantificadas |

*f) Valoración.* El origen común del ibérico de los plomos y del euskera, al menos en su núcleo numeral, es una interpretación compatible con los resultados y merece contraste adicional. Una explicación por préstamo antiguo que alcanzara a la serie numeral entera y a términos elementales del medio físico exigiría contrastar la distribución y la cronología de los posibles préstamos con la evidencia histórica disponible; estos cálculos no determinan la intensidad del contacto que haría falta, ni cuantifican ni establecen una preferencia firme frente al préstamo, la convergencia tipológica o la selección de significados. Para una afirmación genealógica harán falta correspondencias regulares, evidencia gramatical y la validación independiente de las propuestas semánticas. Esta valoración no equivale, pues, a una demostración de parentesco, por cuatro razones: la segunda parte es menos concluyente que la primera, porque sus significados estables son pocos y sus parejas de control no son independientes; la asignación de los valores numerales intermedios procede de la bibliografía y condiciona la distancia medida; los significados de las unidades de los plomos son propuestas; y faltan los dos criterios que la lingüística histórica considera decisivos, la gramática y las correspondencias regulares de sonidos, que el material disponible no permite establecer todavía.

**5. Alcance.** Las conclusiones se refieren al léxico analizado: el de soporte metrológico y el de los plomos de contenido económico. Las probabilidades son condicionales a esa lista, que no se eligió al azar entre el vocabulario ibérico, y a los significados propuestos para ella.

---

## Anexo A. La medida de distancia

**A.1 Validez y aceptación.** La medida combina dos instrumentos de uso general en lingüística cuantitativa:

- *Clases de sonidos.* Dolgopolsky propuso agrupar las consonantes en un número reducido de clases según su tendencia a sustituirse unas por otras en la evolución de las lenguas (Dolgopolsky 1986, versión inglesa del trabajo original en ruso). Turchin, Peiros y Gell-Mann (2010) construyeron sobre esas clases un método de comparación que informan de que clasifica correctamente las lenguas indoeuropeas y semíticas sin falsos positivos. List (2012) las amplió en el modelo SCA, que es el que se usa aquí: es la agrupación de referencia del programa LingPy y de buena parte de la comparación léxica automática actual.
- *Distancia de edición normalizada.* Es la medida del programa ASJP, que compara listas de vocabulario básico de varios miles de lenguas. Wichmann y otros (2010) evalúan sus dos variantes: la distancia dividida por la longitud de las palabras, y esa misma distancia dividida además por la distancia media entre palabras de significado distinto. Concluyen que la segunda corrección es necesaria cuando las lenguas comparadas no tienen parentesco demostrado. Las pruebas de este trabajo incorporan una corrección equivalente mediante la referencia de azar (Anexo B). Jäger (2015) parte de la misma base, con pesos aprendidos de los datos, para 1.161 lenguas de Eurasia y listas de 40 conceptos.

**A.2 Definición.** Sea *r*(*a*) la forma reducida de la palabra *a*: cada consonante sustituida por su clase y cada vocal por una de las cinco vocales. La distancia entre dos palabras *a* y *b* es

> *d*(*a*, *b*) = *E*(*r*(*a*), *r*(*b*)) / ½ [ *L*(*r*(*a*)) + *L*(*r*(*b*)) ]

donde *E* es el coste mínimo de transformar una forma en la otra mediante sustituciones, inserciones y supresiones, y *L* es la longitud ponderada de la forma. Costes: sustituir una vocal por otra, insertar o suprimir una vocal, 0,5; cualquier otra operación, 1. En *L*, cada vocal cuenta 0,5 y cada consonante 1. Dos formas idénticas distan 0.

**Clases de sonidos (modelo SCA).** La tabla completa, sonido a sonido, es la que distribuye LingPy (archivo `converter` del modelo `sca`), con las adaptaciones explícitas que se indican a continuación (ʜ→H, que la tabla no contiene, y la reducción de seis clases vocálicas a cinco). En resumen:

| Clase | Sonidos principales |
|---|---|
| P | p, b |
| B | f, v y otras fricativas labiales |
| W | w |
| T | t, d |
| D | fricativas dentales (como la *z* castellana o la *th* inglesa) |
| C | africadas (*ch*, *ts*, *tz*, *tx*) |
| S | s, z, x y demás sibilantes |
| K | k, g, q |
| G | fricativas velares (como la *j* castellana) |
| H | h y sonidos laríngeos |
| M | m |
| N | n, ñ y demás nasales |
| R | r, rr |
| L | l, ll |
| J | y, j (semiconsonante) |
| Vocales | a; e; i; o; u (las seis clases vocálicas del modelo se reducen a cinco: la sexta contiene solo dos símbolos poco frecuentes y se une a la *o*) |

Formas ibéricas: *b* → P; *t*, *d* → T; *k*, *g* → K; *s*, *ś* → S; *r*, *ŕ* → R; *l* → L; *m*, *ḿ* → M; *n* → N.

**Ejemplos.**

| Ibérico | Otra forma | Formas reducidas | Operaciones | Coste | Longitud media | Distancia |
|---|---|---|---|---|---|---|
| *luŕa* | *lur* | LuRa / LuR | suprimir una vocal | 0,5 | (3 + 2,5) / 2 = 2,75 | 0,18 |
| *śalir* | *zilar* | SaLiR / SiLaR | sustituir dos vocales | 1 | (4 + 4) / 2 = 4 | 0,25 |
| *laku* | *lagun* | LaKu / LaKuN | añadir una consonante | 1 | (3 + 4) / 2 = 3,5 | 0,29 |
| *abaŕ* | *hamar* | aPaR / aMaR | sustituir una consonante | 1 | (3 + 3) / 2 = 3 | 0,33 |
| *borste* | *bost* | PoRSTe / PoST | suprimir una consonante y una vocal | 1,5 | (5 + 3,5) / 2 = 4,25 | 0,35 |

**A.3 Comprobación con parentescos conocidos.** La medida se contrastó con las 106 lenguas de NorthEuraLex clasificadas por familias, usando listas de 40 conceptos, tamaño comparable al del material ibérico y al de las listas de ASJP, en doce sorteos. Se mide con qué acierto la distancia separa las parejas de lenguas de la misma familia de las demás (área bajo la curva: 0,5 es el azar; 1, la separación perfecta). Con las clases SCA el valor es 0,816, y 0,777 si se consideran solo los parentescos antiguos. La regla quedó fijada antes de aplicarla al material de este estudio. (Programa `a3_comprobacion_medida.py`; esta comprobación conserva su semilla original.)

**A.4 Sensibilidad.** La comprobación anterior se hizo con doce sorteos distintos de 40 conceptos. El área bajo la curva varía entre 0,776 y 0,853 según el sorteo (media, 0,816). Para los parentescos antiguos (parejas indoeuropeas o urálicas de ramas distintas, 843 parejas) la media es 0,777: la medida los reconoce, pero peor que los próximos. Con listas más cortas la capacidad de distinguir disminuye; por eso los resultados se leen siempre contra los casos de control (apartado 8.3).

**A.5 Comprobación con otra agrupación de sonidos.** En la fase inicial las pruebas se hicieron también con una agrupación más simple, de ocho clases de consonantes, con formulaciones anteriores de las pruebas. Esas ejecuciones no forman parte del repositorio, no se dan aquí sus cifras y lo que de ellas se dice (Anexo F.3) es un recuerdo del proceso, no un resultado reproducible con él.

## Anexo B. Las pruebas estadísticas

**B.1 Validez y aceptación.** La prueba con significados es una prueba de permutación o de simulación (Monte Carlo): en lugar de suponer una distribución teórica, compara el valor observado con los que se obtienen al repetir muchas veces el mismo cálculo sobre datos en los que, por construcción, no hay relación. Es el procedimiento habitual para valorar el parecido entre listas de palabras desde hace medio siglo, porque no exige supuestos sobre la forma de los datos y admite muestras pequeñas.

Precedentes principales:

| Trabajo | Qué hace | Aplicación |
|---|---|---|
| Oswalt (1970) | Compara las coincidencias entre palabras del mismo significado con las obtenidas al desplazar una lista respecto a la otra | Método general; retomado por Dunn y Terrill (2012) para las lenguas papúes de las Salomón |
| Ringe (1992) | Calcula la probabilidad de que las correspondencias entre consonantes iniciales se deban al azar | Método general |
| Baxter y Manaster Ramer (2000) | Simulación sobre clases de consonantes en listas de vocabulario básico | Parentescos remotos |
| Kessler (2001) | Sistematiza la metodología para decidir si listas breves presentan más correspondencias de las esperables por azar | Monografía de referencia |
| Turchin, Peiros y Gell-Mann (2010) | Clases de consonantes con remuestreo | Indoeuropeo, semítico, altaico |
| Kilani (2015) | Extiende la simulación de Baxter y Manaster Ramer a listas de cualquier tipo y a varios términos por campo semántico | Pregriego frente a protoeuskera, protourálico y «protoaltaico» |
| Ceolin (2019) | Aplica las pruebas de Oswalt, Ringe, Baxter y Manaster Ramer y Kessler | Turco, mongol y manchú |
| Blevins y Sproat (2021) | Genera palabras artificiales con modelos fonotácticos de cada lengua y estima la probabilidad de las correspondencias propuestas; valida con cien pares de lenguas de relación conocida | Protoeuskera y protoindoeuropeo |
| Kassian y otros (2021) | Prueba de permutación sobre reconstrucciones | Macrofamilia altaica |

De estos precedentes, los más cercanos al presente trabajo son tres: Kilani (2015), que admite listas no básicas y varios candidatos por significado, como aquí la prueba con significados; Blevins y Sproat (2021), que validan su procedimiento con pares de lenguas de relación conocida, como aquí los casos de control; y Wichmann y otros (2010), que corrigen la distancia entre palabras del mismo significado con la distancia entre palabras de significado distinto, que es lo que hace la extracción al azar dentro del diccionario.

**B.2 Prueba con significados: formulación.** Para cada unidad *u* con significado *g* se forma el conjunto *C*(*u*, *ℓ*) de palabras del diccionario de *ℓ* glosadas con *g*. El estadístico es

> *T*(*ℓ*) = media, para cada *u* con candidatas, del mínimo de *d*(*u*, *c*) entre las *c* de *C*(*u*, *ℓ*)

La referencia se obtiene sustituyendo las candidatas por palabras extraídas al azar del diccionario de *ℓ*, de su misma longitud (B.6), entre 300 y 500 veces, y 20.000 en el contraste principal (apartado 8.5). De ahí resultan el valor *z*, calculado como en B.2, y la probabilidad empírica *p* = (1 + número de extracciones con *T*\* ≤ *T*) / (1 + número de extracciones). Con 500 extracciones, el menor valor posible es *p* = 0,002: de ahí la expresión «menos de una vez de cada 500».

**B.3 Serie numeral.** Para cada lengua se calcula la distancia media entre cada numeral ibérico y el de igual valor, y las lenguas se ordenan por esa media. Como comprobación, los valores se permutan dentro de la lengua (2.000 permutaciones) para verificar que la proximidad depende de la correspondencia valor a valor.

Para interpretar la distancia obtenida se usa la propia base como referencia (tabla 5). Se toma una variedad por lengua, se excluyen las lenguas sin clasificar, y se calcula para cada lengua de prueba su vecino más próximo entre las 3.811. Las lenguas de prueba son de dos tipos: las 110 que no tienen ningún pariente en la base, cuyo vecino más próximo es necesariamente una lengua no emparentada, y una muestra aleatoria de 400 lenguas pertenecientes a familias de cinco o más miembros, para las que se anota si el vecino más próximo es de la misma familia. Las primeras dan la frecuencia con que el azar o el préstamo producen una serie próxima; las segundas, la proporción de casos de parentesco a cada distancia.

**B.4 Por qué se informa del puesto.** El valor *z* depende del tamaño del conjunto y de la referencia de azar, y no es comparable sin más entre pruebas distintas. El puesto entre lenguas, obtenido con las mismas reglas para todas, es directamente interpretable y no depende de supuestos sobre la distribución.

**B.5 Ejemplo numérico.** Prueba con significados, 30 unidades, léxico de Open Data Euskadi (41.940 formas). La distancia media entre cada unidad ibérica y la palabra más próxima de su mismo significado es 0,45. Sustituyendo cada candidata por una palabra al azar del mismo léxico y de la misma longitud (B.6), la media de 500 repeticiones es 0,74, y ninguna de las 500 da un valor igual o inferior a 0,45: de ahí *p* = 1 / 501 = 0,002 y un valor *z* de −10,9. Con el léxico metrológico, las cifras son 0,23 frente a 0,94.

**B.6 Azar corregido por longitud (prueba con significados).** En la formulación inicial, el azar de cada unidad eran *n* palabras tomadas al azar del diccionario, siendo *n* el número de candidatas. Los casos de control mostraron que así se favorece a todas las lenguas por igual, porque las candidatas, al ser palabras de significado común, son más cortas que la media del diccionario y quedan por ello más cerca de cualquier palabra breve. En la formulación adoptada, cada candidata se sustituye por una palabra al azar del mismo diccionario y de su misma longitud en clases de sonidos. La sustitución se hace una vez por sorteo para el conjunto de las candidatas de todas las unidades: dentro de cada longitud no se repite ninguna palabra, y una candidata compartida por varias unidades recibe la misma sustituta en todas; cada unidad se compara después, con todas sus formas, con las sustitutas de sus candidatas. Esta precisión se introdujo tras una auditoría externa del diseño: en la versión anterior, las unidades con varias formas recibían un sorteo distinto por forma, lo que acercaba el azar al valor real y reducía todos los valores. Los valores de este texto son los de la formulación corregida. Con ello, las lenguas sin parentesco de los controles quedan en torno a cero (sumerio: primera lengua entre −1,6 y −2,8) y los valores de todas las lenguas se reducen. El mismo principio, permutar la correspondencia entre forma y significado solo entre palabras de la misma longitud, lo aplican Dautriche, Mahowald, Gibson y Piantadosi (2017) dentro de cada lengua, en 100 lenguas, por la misma razón: la longitud condiciona por sí sola la distancia entre formas. En la comparación entre lenguas no se ha localizado un precedente.

**B.6 bis Permutación de los significados (apartado 8.5).** Sea *D* la tabla cuyas casillas *D*(*i*, *j*) dan la menor distancia entre las formas de la unidad *i* y las candidatas del significado de la unidad *j*. El valor real es la media de la diagonal. Para cada permutación *π* de las unidades se calcula la media de *D*(*i*, *π*(*i*)); *p* = (1 + número de permutaciones con media menor o igual que la real) / (1 + número de permutaciones), con 100.000 permutaciones. Es la prueba de Oswalt (1970) y Kessler (2001) con una distancia en lugar de un recuento de coincidencias. La corrección de Bonferroni multiplica *p* por el número de lenguas comparadas. En la variante condicionada por la longitud, las unidades se agrupan por la longitud de su primera forma reducida y *π* solo intercambia unidades de un mismo grupo; las unidades que están solas en su grupo conservan su significado.

**B.7 Variación entre ejecuciones.** Los programas usan una semilla fija y sus resultados se reproducen con exactitud. Con otra semilla, los valores que dependen de sorteos cambian. Para medirlo, la prueba de la tabla 6 (30 unidades, lenguas del Wikcionario, 500 sorteos) se repitió 40 veces con secuencias de sorteos distintas (programa `t20_variacion_semillas.py`); la medida y su previsión se declararon antes de ejecutarla. El euskera es la primera lengua en las 40 repeticiones. Su valor va de −11,6 a −13,3, con mediana −12,4 y desviación típica 0,4: una amplitud de 1,7 unidades, mayor que la prevista (menos de 1,5). La mejor de las demás lenguas, que es el gallego o el tagalo, va de −3,9 a −4,4; la separación entre ambas, de 7,3 a 9,1 (mediana 8,3). En las demás lenguas la amplitud es de 0,3 unidades de mediana y no pasa de 0,6. La variación es mayor en el euskera porque su valor es mucho más alto: una misma variación relativa del azar se traduce en más unidades. La mejor de las demás lenguas tiene una desviación típica de 0,1. Es variabilidad de simulación con datos y modelo fijos: no es un intervalo de confianza del efecto ni una banda válida para otra semilla cualquiera. En consecuencia, los valores del euskera en este artículo deben leerse con un margen de en torno a una unidad, y las diferencias menores entre fuentes, variantes o grupos no deben interpretarse. La medida se ha hecho con una sola prueba; en las de menos sorteos (apartados 8.2 a 8.4) el margen es previsiblemente mayor y no se ha medido.

**B.8 Perfil de combinaciones de sonidos.** El punto de partida es Macklin-Cordes, Bowern y Round (2021), que usan listas de al menos 250 palabras, cuentan cada palabra una vez, incluyen el límite de palabra y hallan la señal más fuerte en las transiciones entre clases de sonidos; su análisis contrasta cada transición con un árbol conocido (estadísticos *D* y *K*) y no calcula distancias entre lenguas. La distancia entre perfiles y su validación por familias son de este trabajo. Para cada lengua se cuentan los pares de clases de sonidos consecutivas de cada palabra, incluidos el inicio y el fin de palabra, sobre las formas distintas de su vocabulario, y se convierten en proporciones. La distancia entre dos lenguas es la divergencia de Jensen-Shannon entre sus dos distribuciones (0 = perfiles idénticos; 1 = sin ningún par en común). La validación consiste en comprobar, para cada lengua de la base que tiene parientes en ella, si la lengua de perfil más próximo pertenece a su misma familia. En la variante reducida, todas las lenguas se llevan a las clases que la escritura ibérica distingue (las fricativas labiales con las oclusivas labiales, las dentales y velares fricativas con sus oclusivas, las africadas con las sibilantes, *m* con *n*; se suprimen las laringales y las semiconsonantes pasan a vocal). La estabilidad se midió con 500 remuestreos con reposición de las formas ibéricas y con 500 mitades tomadas al azar.

**B.9 Segunda parte: parejas de control y procedimiento.** Para cada pareja, de la primera lengua se toma, para cada uno de los 40 significados, una palabra al azar entre las que el Wikcionario glosa con los términos de ese significado; se compara con las candidatas de la segunda lengua y con palabras al azar de la misma longitud (120 sorteos); se repite 20 veces y se promedia. Se exige cobertura de al menos cinco significados estables y ocho poco estables. Parejas, fijadas de antemano. Emparentadas cercanas: catalán–occitano, gallego–asturiano, malayo–indonesio, estonio–finés, rumano–latín, catalán–latín, sardo–latín (zulú–shona, descartada por cobertura). Emparentadas lejanas: irlandés–galés, húngaro–finés, irlandés–latín, islandés–latín, lituano–latín, islandés–lituano, tagalo–malayo, malgache–malayo, hawaiano–malayo, fiyiano–malayo, suajili–zulú, hausa–somalí. Parentesco lejano y préstamos: albanés–latín, galés–latín. Solo contacto: tagalo–gallego, tagalo–catalán, quechua–gallego, euskera–latín, euskera–gallego, euskera–catalán, maltés–siciliano, húngaro–turco, finés–islandés, rumano–húngaro, rumano–turco, albanés–turco, malgache–suajili. Sin relación: euskera–finés, quechua–húngaro, hawaiano–irlandés, zulú–islandés, yoruba–lituano, náhuatl–galés, hausa–estonio, fiyiano–latín. Para el ibérico se usan las formas del Anexo D (500 sorteos). En la prueba por zonas, la distancia relativa es la distancia al euskera menos la media de las distancias a las 107 lenguas, dividida por su desviación; las muestras se igualan con 300 sorteos del tamaño de la zona menor.

## Anexo C. Fuentes léxicas

| Fuente | Contenido usado | Versión | Licencia |
|---|---|---|---|
| Hesperia, Banco de datos de lenguas paleohispánicas | 1.599 inscripciones ibéricas auténticas | Consulta del 7-11-2026 | Derechos del proyecto; en el repositorio, archivo derivado (texto de cada ficha) |
| NorthEuraLex (Dellert y otros 2020) | Unos 1.000 conceptos en 107 lenguas, en transcripción fonética | Edición de Lexibank | CC BY 4.0 |
| Chan (2019), en Numeralbank | Numerales de 5.332 variedades; 3.811 lenguas con la serie completa | Edición CLDF | CC BY 4.0 |
| Wikcionario inglés (extracción de kaikki.org) | Entradas de 35 lenguas con su glosa en inglés | 17 y 18-11-2026 | CC BY-SA |
| Apertium | Diccionarios bilingües de 19 pares de lenguas | Repositorio público | GPL |
| WordNet multilingüe (MCR 3.0; Gonzalez-Agirre, Laparra y Rigau 2012) | Euskera (17.989 formas distintas una vez reducidas), castellano, catalán y gallego, enlazados por conceptos | 3.0 | CC BY 3.0 |
| Open Data Euskadi (Gobierno Vasco) | Léxico euskera–castellano, 41.940 formas distintas una vez reducidas | Descarga del 18-11-2026 | CC BY 4.0 |
| Azkue (1905-1906), *Diccionario vasco-español-francés* | Entradas con definición en castellano; 31.253 formas distintas una vez reducidas | Reimpresión de Euskaltzaindia (1984), edición digital | Derechos de Euskaltzaindia; en el repositorio, lista derivada |
| Trask (2008), *Etymological Dictionary of Basque* | Léxico nativo reconstruido, 391 formas (se excluyen las reconstrucciones con un segmento sin determinar) | Edición en línea de la Universidad de Sussex | Derechos del autor y del editor; en el repositorio, lista derivada, con cita |

Tamaños del euskera en las demás fuentes, en formas distintas una vez reducidas: Wikcionario, 3.814; Apertium, 7.028 (puente castellano) y 6.885 (puente inglés).

**Coincidencia de significados.** En la prueba con significados, una palabra del diccionario es candidata para una unidad cuando su glosa coincide exactamente con uno de los términos del significado propuesto (por ejemplo, «plata» o «silver»), una vez retirados artículos y aclaraciones entre paréntesis. No se admiten coincidencias parciales, que inflan el número de candidatas. Los términos de cada unidad se fijaron antes de consultar ningún diccionario. La lista de términos de cada unidad figura en la tabla de significados del conjunto de datos en formato CLDF (Anexo F.4).

**Paso de la ortografía a clases de sonidos.** NorthEuraLex ofrece transcripción fonética, y la reducción se hace sobre ella. En los diccionarios se parte de la ortografía de cada lengua, con una tabla de equivalencias por lengua que acompaña a los programas.

## Anexo D. Palabras ibéricas empleadas, por origen de la propuesta

### D.1 Léxico con soporte metrológico (Ferrer i Jané 2022; Orduña 2005)

| Forma | Valor | Apoyo |
|---|---|---|
| *erder* / *erdi* | ½ | Marca de valor en monedas de bronce (*eterder* = media unidad) |
| *ban* | 1 | Marca de valor en monedas de *untikesken* (*etaban* = una unidad; Ferrer i Jané 2022: 16-17) |
| *bi* / *bin* | 2 | Posición en el sistema |
| *iŕur* | 3 | Posición en el sistema |
| *lauŕ* | 4 | Posición en el sistema |
| *borste* / *bors* | 5 | Posición en el sistema |
| *śei* | 6 | Posición en el sistema |
| *sisbi* | 7 | Posición en el sistema |
| *sorse* | 8 | Posición en el sistema |
| *abaŕ* / *baŕ* | 10 | Peso de piedra de Puig Castellar, de 420 g (*ustainabaŕarban*; Hesperia B.40.04) = diez unidades de unos 42 g (Ferrer i Jané 2022: 17) |
| *oŕkei* / *ogei* | 20 | Marca de capacidad en un dolium de Ruscino (*ogei*; Hesperia PYO.01.23), plausible (Ferrer i Jané 2022: 19); *oŕkei* en las expresiones compuestas |
| *o* / *ota*, *e* / *eta*, *ki* / *kitar* | Unidades del sistema metrológico | Pesos con marca; combinación con numerales |

### D.2 Léxico de los plomos (monografías I–IV)

*Los recuentos de inscripciones por unidad de este anexo proceden de las monografías y no se reproducen con los programas del repositorio.*

Las columnas «Inscripciones» y «Casilla o función» resumen el inventario de la monografía IV, con el grado que allí se asigna a cada propuesta (A, B o C; apartado 3.3). Las dos últimas columnas dan, a título de ejemplo, la palabra más próxima con ese significado en uno de los diccionarios de euskera (Open Data Euskadi) y su distancia (0 = idéntica).

| N.º | Forma ibérica | Significado propuesto | Campo | Inscripciones | Casilla o función [grado] | Forma más próxima | Distancia |
|---|---|---|---|---|---|---|---|
| A1 | *śalir* | plata, valor monetario | contable y monetario | 17 plomos | Unidad de plata o moneda [A] | zilar | 0,25 |
| A2 | *erter* / *erder* | mitad | contable y monetario | 6 inscripciones y leyendas monetales | Fraccionario [A] | erdi | 0,43 |
| A3 | *kitar* / *kidar* | unidad de cuenta | contable y monetario | A.04.06a–b, V.17.02 | Unidad o casilla contable [B] | unitate | 0,67 |
| A4 | *eka* | partida, asiento | contable y monetario | V.07.01 | Partida, frente al cierre [C] | jarleku | 1,07 |
| A5 | *bobaida* / *bobaidinba* | total, suma | contable y monetario | V.07.01 | Posible cierre de cuenta [C] | batuketa | 0,64 |
| A6 | *bale* / *baleś* | valor, tasación | contable; préstamo latino propuesto | V.13.01–03, SP.01.07 | Tasación ante cifra [C] | balio | 0,31 |
| A7 | *baśir* / *baseŕ* | finca, fundo | predial y geográfico | 16 inscripciones (12 plomos) | Unidad divisible por mitades [B/C] | ogasun | 0,71 |
| A8 | *aŕeka* / *eŕeko* | acequia, reguero | predial y geográfico | V.13.01, V.13.03, V.06.006 | Canalización de riego [B/C] | areka | 0,00 |
| A9 | *koŕta* | corral | predial; préstamo latino propuesto | V.13.03 | Recinto pecuario acotado [B/C] | korrale | 0,47 |
| A10 | *bekoŕ* / *bekon* | becerro, res joven | predial y geográfico | 12 inscripciones | Ganado contado (*bekoŕ-ban*) [C] | zekor | 0,25 |
| A11 | *oŕtin* / *oŕtor* | huerto | predial; préstamo latino propuesto | 13 inscripciones | Parcela tasada en plata [B/C] | ortu | 0,43 |
| A12 | *selki* / *selgi* | pasto acotado, majada | predial y geográfico | B.00.01 | Pasto acotado [C] | saroi | 0,67 |
| A13 | *saltu* / *saldu* | monte, dehesa | predial; préstamo latino propuesto | V.17.02 | Monte en régimen de sociedad [C] | bortu | 0,62 |
| A14 | *aŕta* | encina, encinar | predial y geográfico | V.17.02, V.13.02 | Monte de tala [C] | haritz | 0,67 |
| A15 | *alate* | lado, costado | predial y geográfico | V.13.03 (cinco veces) | Deslinde [C] | alde | 0,15 |
| A16 | *akari* | tributo, canon | contable y monetario | B.11.01, V.13.02 | Tributo agropecuario [C] | zergera | 0,78 |
| A17 | *kutu* / *kutur* | escrito, documento | personas y actos | 18 inscripciones (9 plomos) | Instrumento escrito [A/C] | gutun | 0,25 |
| A18 | *iunstir* | titular, señor | personas y actos | 25 inscripciones | Autoridad, frente a *iŕi-ka* [B/C] | andre | 0,70 |
| A19 | *laku* / *lakun* | socio, compañero | personas y actos | 17 inscripciones (8 plomos) | Asociación o cotitularidad [B/C] | lagun | 0,00 |
| A20 | *baites* / *baides* | testigo-depositario | personas y actos | 14 plomos | Garantía del acto, junto a series de nombres de persona [B/C] | testigu | 0,90 |
| A21 | *baŕbin* | otorgar, dar | personas y actos | 7 inscripciones (5 plomos), con A23 | Cláusula de otorgamiento [B/C] | emanarazi | 0,96 |
| A22 | *uskeike* | liberar, soltar | personas y actos | Las mismas que A22 | Cláusula de finiquito [B/C] | askatu | 0,63 |
| A23 | *lekaŕ* / *lokaŕ* | prenda, fianza | personas y actos | 6 inscripciones (5 plomos) | Instrumento junto a *śoŕ* [C] | erres | 1,00 |
| A24 | *luŕa* | tierra | predial y geográfico | 5 inscripciones | Suelo arable [C] | lur | 0,18 |
| A25 | *ibaŕ* | vega | predial y geográfico | 3 inscripciones, con A27 | Vega [C] | ibar | 0,00 |
| A26 | *itur* | fuente, manantial | predial y geográfico | GI.10.11 | Manantial [C] | iturri | 0,15 |
| A27 | *belar* | hierba, prado | predial y geográfico | 4 inscripciones | Prado de siega [C] | belar | 0,00 |
| A28 | *bide* | camino | predial y geográfico | 10 inscripciones (7 plomos) | Servidumbre de paso [B/C] | bide | 0,00 |
| A29 | *daŕadi* | carrascal, monte bajo | predial y geográfico | V.07.02 | Monte [C] | txaradi | 0,22 |
| A30 | *ekiar* / *egiar* | hacer | personas y actos | V.06.010, A.04.06b, T.07.03, B.11.01, AUD.05.32 | Fórmula de autoría, paralela a *fecit* [A] | egin | 0,46 |

Tabla cotejada el 19-11-2026 con las monografías v5.2 (forma y significado de cada unidad). *Errata corregida el 21-11-2026:* en la v38 de este texto, las filas A16 (*akari*) y A30 (*ekiar* / *egiar*) remitían a B.10.01 (L'Aubreda, cerámica, texto `[---]ti`); la inscripción correcta es B.11.01 (La Joncosa, Jorba), en la que figuran *akari* y *ekiarḿi*. La corrección afecta solo a esta columna descriptiva: ningún programa del repositorio usa estas siglas y ningún resultado cambia. El valor de *kitar* / *kidar* (A3) es el aceptado en la bibliografía (Ferrer i Jané 2014); las monografías lo adoptan.

### D.3 Procedencia de cada significado

*La clasificación de esta tabla es la del autor. La segunda codificación por un jurado ciego (apartado 8.4; `2_criterios/jurado/`) la rebaja en 17 unidades con cada una de las dos preguntas; la tabla se conserva tal como se registró antes del jurado. Las tres reclasificaciones de la edición final de la Monografía IV (21-11-2026; declaración 16) se anotan con fecha en su fila, sin retirar la clasificación original.*

Fuente: Monografía IV, apartado 5.1, tabla 5 (inventario cerrado). Clase (a): significado obtenido sin comparación vasca previa; clase (c): convergente, independiente en la obtención pero no en la comprobación. Nivel I: propuesta previa de terceros; II: propuesta de las monografías por la casilla documental; III: convergente.

| N.º | Forma | Clase | Estatus bibliográfico | Prueba aducida | ¿Interviene el euskera? | Nivel |
|---|---|---|---|---|---|---|
| A1 | *śalir* | (a) | propuesta previa adoptada | Unidad argéntea o moneda, en 17 plomos; valor aceptado en la bibliografía (Orduña 2005; Ferrer i Jané 2009, 2014) | No. La tabla 5 descarta el cotejo: vasc. zilhar se discute como préstamo cultural | I |
| A2 | *erter / erder* | (a) | propuesta previa adoptada | Marca de valor en monedas y metrología interna (Ferrer i Jané 2009, 2014) | No en la obtención; el cotejo con vasc. erdi es posterior | I |
| A3 | *kitar / kidar* | (a) | propuesta previa adoptada | Unidad metrológica o monetaria (Ferrer i Jané 2014; sistema a-o-ki) | No. Sin paralelo vasco | I |
| A4 | *eka* | (a) | convergente / propia | Asiento frente al cierre en V.07.01 | No. Sin paralelo vasco | II |
| A5 | *bobaida / bobaidinba* | (a) | convergente / propia | Posible cierre de cuenta en V.07.01 (10 + 10 = 20) | No en la obtención (la tabla 5 remite -baida a la entrada de baites) | II |
| A6 | *bale / baleś* | (a) | propuesta propia (MLH V.2 la registra sin glosa, junto a numerales) | Tasación ante cifra | No. Propuesta como préstamo latino (valere) | II |
| A7 | *baśir / baseŕ* | (a) | propuesta propia (MLH V.2: unidad de cuenta o medida) | Unidad divisible por mitades (baśirerter) | No. La tabla 5 descarta vasc. baso. *Reclasificada el 21-11-2026 (edición final de la Monografía IV; declaración 16): posible correspondencia de nivel C con vasc. baserri, señalada después.* | II |
| A8 | *aŕeka / eŕeko* | (a) | propuesta propia | Conducción de riego en los plomos de Yátova | No en la obtención. Paralelo posterior señalado: vasc. erreka | II |
| A9 | *koŕta* | (a) | propuesta propia | Recinto pecuario acotado (V.13.01, V.13.03) | No. Propuesta como préstamo latino (cohortem) | II |
| A10 | *bekoŕ / bekon* | (a) | propuesta propia | Ganado contado (bekoŕban), junto a koŕta | No en la obtención. Paralelo posterior señalado: vasc. biga | II |
| A11 | *oŕtin / oŕtor* | (a) | propuesta propia | Parcela tasada en plata | No. Propuesta como préstamo latino (hortus) | II |
| A12 | *selki / selgi* | (a) | propuesta propia | Pasto acotado (B.00.01) | No. Sin cognado vasco seguro | II |
| A13 | *saltu / saldu* | (a) | propuesta propia | Monte en régimen de sociedad (V.17.02) | No. Propuesta como préstamo latino (saltus) | II |
| A14 | *aŕta* | (a) | propuesta propia | Monte de tala (V.17.02, V.13.02) | No en la obtención. Paralelo posterior señalado: vasc. arte | II |
| A15 | *alate* | (a) | propuesta propia | Deslinde (V.13.03, cinco veces) | No en la obtención. Paralelo posterior señalado: vasc. alde | II |
| A16 | *akari* | (a) | adoptada / propia | Tributo agropecuario (akari-śalir) | No. Sin paralelo vasco verificado | II |
| A17 | *kutu / kutur* | (a) | adoptada (Ferrer i Jané 2014a; MLH V.2: campo de la escritura) y propia | Abecedarios ku-tu-; posición ante el verbo en los plomos | No en el cómputo estricto. Nota abierta sobre vasc. gutun. *Reclasificada el 21-11-2026 (edición final de la Monografía IV; declaración 16): posible correspondencia de nivel C con vasc. gutun, señalada después.* | I |
| A18 | *iunstir* | (a) | propuesta propia (MLH V.2: saludo o verbo) | Autoridad frente a iŕi-ka (CS.21.07, GI.10.11) | No. La tabla 5 descarta vasc. jaun. *Reclasificada el 21-11-2026 (edición final de la Monografía IV; declaración 16): posible correspondencia de nivel C con vasc. jaun, señalada después.* | II |
| A19 | *laku / lakun* | (a) | adoptada en vaso (Ferrer i Jané 2009: 465) y propia en metal | Particiones a la mitad en plomos y bronce | No en la obtención. Paralelo posterior señalado: vasc. lagun | II |
| A20 | *baites / baides* | (a) | conciliación propia con MLH V.2 y Ferrer i Jané 2026a | Casilla de garantía junto a series de nombres de persona | No en la obtención. Paralelo posterior señalado: vasc. baitha | II |
| A21 | *baŕbin* | (a) | propuesta propia (MLH V.2: votivo) | Cláusula contractual, con uskeike | No | II |
| A22 | *uskeike* | (a) | propuesta propia | Cláusula de finiquito, con baŕbin | No. La tabla 5 descarta vasc. utzi | II |
| A23 | *lekaŕ / lokaŕ* | (a) | propuesta propia | Instrumento junto a śoŕ | No. La tabla 5 descarta vasc. lokarri | II |
| A24 | *luŕa* | (c) | convergente | Suelo arable (A.04.01a) | Sí en la comprobación (vasc. lur); independiente en la obtención | III |
| A25 | *ibaŕ* | (c) | convergente | Vega, con manantial | Sí en la comprobación (vasc. ibar) | III |
| A26 | *itur* | (c) | convergente | Manantial (GI.10.11) | Sí en la comprobación (vasc. iturri) | III |
| A27 | *belar* | (c) | convergente | Prado de siega | Sí en la comprobación (vasc. belar) | III |
| A28 | *bide* | (c) | convergente | Servidumbre de paso | Sí en la comprobación (vasc. bide) | III |
| A29 | *daŕadi* | (c) | convergente | Monte (V.07.02) | Sí en la comprobación (colectivo vasc. -di) | III |
| A30 | *ekiar / egiar* | (a) | adoptada por contexto interno (Ferrer i Jané 2008) | Fórmula de autoría, paralela a fecit | No en la obtención; cotejo posterior con vasc. egin | I |

Serie numeral (bloque B01 de la misma tabla, cuya comparación con el euskera está publicada): nivel I para los tres valores con apoyo externo (uno, diez, veinte; apartado 3.2) y nivel III para los valores del dos al ocho, asignados por su posición en la serie.

## Anexo E. Programas y reproducción

Los programas son los del repositorio (apartado 9). Cada uno se ejecuta sin argumentos y escribe su resultado en la carpeta `resultados/`.

| Tabla o apartado | Programa | Datos de entrada |
|---|---|---|
| Tablas 1 y 2 | `t01_t02_corpus.py` | Corpus de Hesperia; clasificación de Moncunill y Velaza (2019); formantes de Rodríguez Ramos (2014) |
| Tablas 4 y 5 | `t04_t05_numerales.py` | Chan (2019) |
| Figuras 1 a 3 | `figuras.py` | Los resultados de los tres programas anteriores y de `t08_perfil.py`; requiere Matplotlib |
| Tablas 6 y 7 | `t06_t07_significados.py` | Wikcionario, Azkue, léxico reconstruido de Trask, Open Data Euskadi, Apertium, WordNet |
| Tabla 8 | `t08_perfil.py` | NorthEuraLex; Wikcionario; léxico de control; corpus de Hesperia |
| Tabla 9 | `t09_prestamos.py` | Los mismos diccionarios de las tablas 6 y 7 |
| Apartado 8.2 | `s82_formas_y_sinonimos.py` | Wikcionario, con formas flexionadas |
| Tabla 10 | `t10_controles.py` | Wikcionario (umbro, gótico, córnico, dálmata, etrusco, sumerio) |
| Tablas 11 a 13 | `t11_t13_estables.py` | Wikcionario; unidades ibéricas |
| Tabla 10 bis y apartado 8.4 | `t15_solidez_unidades.py` | Wikcionario, Open Data Euskadi, WordNet |
| Tabla 10 ter y apartado 8.5 | `t16_contraste_principal.py` | Wikcionario, Open Data Euskadi, Azkue, WordNet |
| Tabla 14 | `t14_zonas.py` | NorthEuraLex; corpus de Hesperia |
| Tabla 15 | `t18_perfil_contacto.py` | NorthEuraLex |
| Tabla 10 cuater | `t19_potencia_controles.py` | Wikcionario (lenguas de control) |
| Tabla 10 bis, fila sin lecturas alternativas | `t21_lecturas_alternativas.py` | Wikcionario |
| Tabla 10 bis, filas con la clasificación del jurado ciego | `t24_jurado_procedencia.py` | Wikcionario; `2_criterios/jurado/respuestas/` |
| Apartado 11.4, correspondencias | `t25_correspondencias.py` | Wikcionario |
| Apartado 11.5, prestabilidad | `t26_prestabilidad.py` | Wikcionario, Open Data Euskadi; WOLD (35 puntuaciones) |
| Apartado 11.6, origen etimológico y fonotaxis | `t27_etimologia_vasca.py [amplia]` | Wikcionario vasco (columna de etimología) |
| Tabla 8, calibración del perfil | `t22_calibracion_perfil.py` | NorthEuraLex; corpus de Hesperia |
| Apartado 8.4, tamaño de los diccionarios | `t23_tamano_diccionario.py` | Resultado de la tabla 6 |
| Anexo B.7, variación entre semillas | `t20_variacion_semillas.py` | Wikcionario |
| Apartado 8.4, ensayo sobre la circularidad (no concluyente) | `t17_techo_circularidad.py` | Wikcionario |
| Anexo A.3 | `a3_comprobacion_medida.py` | NorthEuraLex |
| Comprobación rápida | `comprobacion_rapida.py` | Unidades ibéricas y cuatro diccionarios del euskera |

La regla de medida, las reglas de reducción a clases de sonidos, los lectores de cada fuente y las pruebas están en el paquete `ibcomp`. Los programas están escritos en Python 3 y solo requieren la biblioteca NumPy. La especificación funcional describe cada paso sin referencia al código. Las versiones y fechas de cada base figuran en el Anexo C. [PENDIENTE: dirección del repositorio y DOI del depósito]

## Anexo F. Uso de los recursos y métodos de J.-M. List

**F.1 Qué se ha tomado de ese marco de trabajo.**

| Recurso o método | Referencia | Uso en este trabajo |
|---|---|---|
| Formato normalizado de datos (CLDF) y colección Lexibank | Forkel y otros 2018; List y otros 2022 | De ahí proceden las dos bases de comparación principales: NorthEuraLex (107 lenguas) y los numerales de Chan (2019), ambas con el mismo formato y la misma transcripción para todas las lenguas |
| Clases de sonidos del modelo SCA | Dolgopolsky 1986; List 2012 | Son las clases empleadas en la regla de medida (apartado 4) |
| Valoración del parecido frente al azar por permutación | Kessler 2001; es también la base del método LexStat de List | Es el tipo de prueba empleado (Anexo B) |
| Análisis manual y explícito antes de cualquier asignación automática | Práctica recomendada en ese marco | Cada palabra ibérica se presenta con su segmentación, sus inscripciones y su significado propuesto (Anexo D); las correspondencias se dan como propuestas, no como cognados establecidos |

**F.2 Qué no se ha usado, y por qué.** No se ha empleado la detección automática de cognados de LingPy (LexStat). Ese procedimiento está pensado para listas de vocabulario básico de varias lenguas, con decenas o centenares de conceptos por lengua, y asigna las palabras a clases de cognados. El material ibérico no cumple esas condiciones: son unas decenas de palabras, de vocabulario en buena parte no básico y con significados propuestos. En esta fase lo adecuado es medir si hay más parecido del esperable por azar, y dejar la identificación de cognados para cuando existan correspondencias regulares.

**F.3 Las clases de sonidos SCA como agrupación principal.** Las primeras pruebas de este trabajo se hicieron con una agrupación propia de ocho clases de consonantes (labiales, dentales, velares, sibilantes, nasales, vibrantes, laterales y semiconsonantes). Después se adoptó el modelo SCA, por tres razones: es un estándar publicado y de uso general; reconoce los parentescos conocidos algo mejor; y evita la objeción de que la agrupación se haya hecho a medida. La decisión se tomó con la comprobación de parentescos conocidos, en la que no interviene el material ibérico.

*Procedimiento.*
1. Se instaló LingPy y se tomó de él la tabla de clases del modelo SCA (archivo `converter` del modelo `sca`; List 2012); las adaptaciones aplicadas sobre ella se describen en el Anexo A.2.
2. Esa tabla asigna cada sonido del alfabeto fonético a una clase. Tiene quince clases de consonantes, frente a las ocho anteriores: separa, entre otras, *m* de *n*, las fricativas labiales (*f*, *v*) de las oclusivas (*p*, *b*), *w*, las africadas, las fricativas velares y la aspiración. Las vocales se reparten en seis clases, que aquí se reducen a cinco.
3. En las pruebas sin significados y en los numerales, la tabla se aplica directamente a la transcripción de las fuentes.
4. En la prueba con significados, los diccionarios no ofrecen transcripción fonética; las clases SCA se aplican a la ortografía normalizada de cada lengua, con una tabla de equivalencias entre letras y clases que acompaña al programa. Es una aproximación, y así debe entenderse.
5. No se cambió nada más: la distancia (con las vocales a mitad de coste), la referencia de azar, las listas de palabras y el número de repeticiones son los mismos.

*Resultado de la comparación.* En las ejecuciones iniciales, hechas con las dos agrupaciones y con formulaciones anteriores de las pruebas, el euskera quedó en primer lugar con una y con otra, y las clases SCA separaron algo mejor los parentescos conocidos. Esas ejecuciones no están en el repositorio y esta afirmación no es reproducible con él; los resultados de este trabajo son todos con las clases SCA.

**F.4 Datos en formato CLDF.** Las listas de palabras ibéricas del Anexo D se ofrecen en formato CLDF (módulo Wordlist): una tabla de significados, con los términos de búsqueda empleados, y una tabla de formas, con sus segmentos, su clase SCA, su grupo, su grado de certeza, su fuente y sus inscripciones. No se incluyen textos de inscripciones. La validación con la herramienta oficial (`cldf validate`) forma parte de las comprobaciones automáticas del repositorio.

## Documentación complementaria

Existen además un registro fechado de todas las ejecuciones y un documento que recoge las pruebas y formulaciones anteriores, los cambios introducidos y su justificación. No se anexan a este trabajo; están a disposición de quien los solicite al autor.

---

## Bibliografía

Verificadas (referencia comprobada en la fuente, en el registro de la revista o en un catálogo bibliográfico; contenido citado comprobado en el texto o en su resumen editorial):
- Baxter, W. H. y Manaster Ramer, A. (2000): «Beyond lumping and splitting: probabilistic issues in historical linguistics», en C. Renfrew, A. McMahon y L. Trask (eds.), *Time Depth in Historical Linguistics*, vol. 1, Cambridge, McDonald Institute for Archaeological Research, 167-188.
- Akbih Verdaguer, K. (2025): «El debat dels numerals bascoibèrics. Una aproximació des de la tipologia lingüística», *Palaeohispanica* 25, 405-429. doi:10.36707/palaeohispanica.v25i1.720.
- Blevins, J. y Sproat, R. (2021): «Statistical evidence for the Proto-Indo-European-Euskarian hypothesis: A word-list approach integrating phonotactics», *Diachronica* 38 (4), 506-564. doi:10.1075/dia.19014.ble.
- Ceolin, A. (2019): «Significance testing of the Altaic family», *Diachronica* 36 (3), 299-336. doi:10.1075/dia.17007.ceo.
- Dautriche, I., Mahowald, K., Gibson, E. y Piantadosi, S. T. (2017): «Wordform similarity increases with semantic similarity: An analysis of 100 languages», *Cognitive Science* 41 (8), 2149-2169. doi:10.1111/cogs.12453.
- Dellert, J. y otros (2020): «NorthEuraLex: a wide-coverage lexical database of Northern Eurasia», *Language Resources and Evaluation* 54, 273-301. doi:10.1007/s10579-019-09480-6.
- Dunn, M. y Terrill, A. (2012): «Assessing the lexical evidence for a Central Solomons Papuan family using the Oswalt Monte Carlo Test», *Diachronica* 29, 1-27. doi:10.1075/dia.29.1.01dun.
- Ferrer i Jané, J. (2009): «El sistema de numerales ibérico: avances en su conocimiento», *Palaeohispanica* 9, 451-479.
- Ferrer i Jané, J. (2022): «El sistema de numerals ibèric més enllà de la semblança formal amb els numerals bascos», *Revista d'Arqueologia de Ponent* 32, 9-42. doi:10.21001/rap.2022.32.1.
- Ferrer i Jané, J. (2024): «Ogei (20): una possible marca de lèxica de capacitat ibèrica expressada en àmfores, sobre un dolium de Ruscino (Perpinyà)», en M. Rueda Prunell y R. Járrega Domínguez (eds.), *Dolia ex Hispania: els dolia a les províncies d'Hispania en època romana. Estat de la qüestió i perspectives*, Tarragona, Institut Català d'Arqueologia Clàssica (TRAMA 12), 55-68. ISBN 978-84-125214-5-0; DOI 10.51417/trama_12.
- Ferrer i Jané, J. (2023): «La inscripción vascónica de la mano de Irulegi desde la perspectiva ibérica», *Fontes Linguae Vasconum* 136, 515-538.
- Forkel, R., List, J.-M., Greenhill, S. J. y otros (2018): «Cross-Linguistic Data Formats, advancing data sharing and re-use in comparative linguistics», *Scientific Data* 5, 180205. doi:10.1038/sdata.2018.205.
- Gonzalez-Agirre, A., Laparra, E. y Rigau, G. (2012): «Multilingual Central Repository version 3.0», en *Proceedings of the Eighth International Conference on Language Resources and Evaluation (LREC'12)*, Estambul, 2525-2529.
- Haspelmath, M. y Tadmor, U. (eds.) (2009): *Loanwords in the World's Languages: A Comparative Handbook*, Berlín, De Gruyter Mouton. [Citado a través de Akbih Verdaguer 2025]
- Jäger, G. (2015): «Support for linguistic macrofamilies from weighted sequence alignment», *Proceedings of the National Academy of Sciences* 112 (41), 12752-12757. doi:10.1073/pnas.1500331112.
- Kassian, A. y otros (2021): «Permutation test applied to lexical reconstructions partially supports the Altaic linguistic macrofamily», *Evolutionary Human Sciences* 3. doi:10.1017/ehs.2021.28.
- Kessler, B. (2001): *The Significance of Word Lists*, Stanford, CSLI Publications.
- Kilani, M. (2015): «Calculating false cognates: An extension of the Baxter & Manaster-Ramer solution and its application to the case of Pre-Greek», *Diachronica* 32 (3), 331-364. doi:10.1075/dia.32.3.02kil.
- Lakarra, J. A. (2010): «Haches, diptongos y otros detalles de alguna importancia: notas sobre numerales (proto)vascos y comparación vasco-ibérica (con un apéndice sobre *hiri* y otro sobre *bat-bi*)», *Veleia* 27, 191-238. doi:10.1387/veleia.4937.
- List, J.-M. y otros (2022): «Lexibank, a public repository of standardized wordlists with computed phonological and lexical features», *Scientific Data* 9, 316. doi:10.1038/s41597-022-01432-0.
- Luo, J., Hartmann, F., Santus, E., Barzilay, R. y Cao, Y. (2021): «Deciphering Undersegmented Ancient Scripts Using Phonetic Prior», *Transactions of the Association for Computational Linguistics* 9, 69-81.
- Miller, J. E., Tresoldi, T., Zariquiey, R., Beltrán Castañón, C. A., Morozova, N. y List, J.-M. (2020): «Using lexical language models to detect borrowings in monolingual wordlists», *PLOS ONE* 15 (12), e0242709. doi:10.1371/journal.pone.0242709.
- Michelena, L. (1990): *Fonética histórica vasca* (Anejos del Anuario del Seminario de Filología Vasca «Julio de Urquijo», IV; Obras completas, I), San Sebastián, Diputación Foral de Gipuzkoa. Edición electrónica: Bilbao, UPV/EHU, 2021. [Paginación de los capítulos tomada del índice digital; confirmar en el impreso]
- Moncunill, N. y Velaza, J. (2017): *Iberian: Language, Writing, Epigraphy* (AELAW Booklet 3), Zaragoza, Prensas de la Universidad de Zaragoza.
- Moncunill, N. y Velaza, J. (2019): *Lexikon der iberischen Inschriften / Léxico de las inscripciones ibéricas* (MLH V.2), Wiesbaden, Reichert.
- Rodríguez Ramos, J. (2014): «Nuevo Índice Crítico de formantes de compuestos de tipo onomástico íberos», *ArqueoWeb* 15, 81-238.
- Macklin-Cordes, J. L., Bowern, C. y Round, E. R. (2021): «Phylogenetic signal in phonotactics», *Diachronica* 38 (2), 210-258. doi:10.1075/dia.20004.mac.
- McMahon, A., Heggarty, P., McMahon, R. y Slaska, N. (2005): «Swadesh sublists and the benefits of borrowing: an Andean case study», *Transactions of the Philological Society* 103 (2), 147-170. doi:10.1111/j.1467-968X.2005.00148.x. [Leídos el resumen y un extracto del método]
- Nerbonne, J. (2010): «Measuring the diffusion of linguistic change», *Philosophical Transactions of the Royal Society B* 365 (1559), 3821-3828. doi:10.1098/rstb.2010.0048.
- Roettger, T. B. (2021): «Preregistration in experimental linguistics: applications, challenges, and limitations», *Linguistics* 59 (5), 1227-1249. doi:10.1515/ling-2019-0048.
- Tadmor, U., Haspelmath, M. y Taylor, B. (2010): «Borrowability and the notion of basic vocabulary», *Diachronica* 27 (2), 226-246. doi:10.1075/dia.27.2.04tad.
- Wang, W. S.-Y. y Minett, J. W. (2005): «Vertical and horizontal transmission in language evolution», *Transactions of the Philological Society* 103 (2), 121-146. [Leída]
- Trask, R. L. (2008): *Etymological Dictionary of Basque*, ed. M. W. Wheeler, Universidad de Sussex.
- Turchin, P., Peiros, I. y Gell-Mann, M. (2010): «Analyzing genetic connections between languages by matching consonant classes», *Journal of Language Relationship* 3, 117-126.
- Wichmann, S., Holman, E. W., Bakker, D. y Brown, C. H. (2010): «Evaluating linguistic distance measures», *Physica A* 389 (17), 3632-3639. doi:10.1016/j.physa.2010.05.011.

Verificada en parte (falta el dato que se indica):
- List, J.-M. (2012): «SCA: Phonetic alignment based on sound classes», en D. Lassiter y M. Slavkovik (eds.), *New Directions in Logic, Language and Computation* (Lecture Notes in Computer Science 7415), Berlín, Springer, 32-51. doi:10.1007/978-3-642-31467-4_3. [Páginas por comprobar]

Citadas a través de otra obra (comprobar en el original):
- Dolgopolsky, A. (1986): «A probabilistic hypothesis concerning the oldest relationships among the language families of Northern Eurasia», en V. Shevoroshkin y T. Markey (eds.), *Typology, Relationship and Time*, Ann Arbor, Karoma, 27-50. [Según Turchin y otros 2010]
- Oswalt, R. L. (1970): «The detection of remote linguistic relationships», *Computer Studies in the Humanities and Verbal Behavior* 3, 117-129. [Según Dunn y Terrill 2012; no localizada en línea]
- Ringe, D. A. (1992): «On calculating the factor of chance in language comparison», *Transactions of the American Philosophical Society* 82, 1-110. [Según Turchin y otros 2010]
- Rix, H. (1998): *Rätisch und Etruskisch*, Innsbruck, Institut für Sprachwissenschaft der Universität Innsbruck (Innsbrucker Beiträge zur Sprachwissenschaft, Vorträge und Kleinere Schriften 68).

Por completar:
- Azkue, R. M. de (1905-1906): *Diccionario vasco-español-francés*, Bilbao. [Datos de la reimpresión usada]
- Chan, E. (ed.) (2019): *Numeral Systems of the World's Languages*. [Cita exacta de la edición de datos en Numeralbank]
- Martín Valladolid, D. (2026a-d): *Contabilidad financiera, contratos mercantiles y catastros en la Hispania prerromana* (I–IV), Serie abierta de historia económica de la Hispania prerromana, edición v5.0. [Títulos completos y DOI de cada monografía]
- Orduña Aznar, E. (2025): «La relación entre el vasco y el ibérico: más allá de los numerales», *Palaeohispanica* 25, 329-357. doi:10.36707/palaeohispanica.v25i1.690.
- Orduña Aznar, E. (2005): «Sobre algunos posibles numerales en textos ibéricos», *Palaeohispanica* 5, 491-505.

Datos: Hesperia, Banco de datos de lenguas paleohispánicas; Wikcionario inglés (extracción de kaikki.org); Apertium; Open Data Euskadi (Gobierno Vasco, CC BY 4.0); Euskal WordNet (MCR 3.0).

*Declaración sobre el uso de herramientas de inteligencia artificial.* En la preparación de este trabajo se han empleado herramientas de inteligencia artificial generativa como apoyo en la programación de los análisis, la revisión de cálculos, la búsqueda bibliográfica y la redacción. Todas las referencias citadas como verificadas se han comprobado en su fuente, y los resultados son reproducibles con los programas que se aportan. El autor ha revisado el contenido y asume la responsabilidad íntegra del trabajo.
