## 9. Condiciones finitas de cierre del artículo I

**Código.** Completar la rama de agregado totalmente vacío de t15 y la de correlaciones no definidas de t26. Añadir pruebas de integración que lleguen hasta esos consumidores y exigir serialización finita o `null`. Conservar los resultados actuales y cotejar que los valores definidos permanecen iguales.

**Texto.** Sustituir la exclusión general de azar y artefactos de la síntesis por la formulación condicionada; restringir el resumen del contacto a las 17 parejas; aplicar al §8.4 la corrección ya registrada de siete previsiones, tres retornos y cuatro no retornos; evitar «grupo limpio». Precisar en t27 que los p se refieren a todas las etiquetas de préstamo y que «no se detecta» no demuestra ausencia.

**Concordancia menor.** Regenerar el log de t15, unificar la tolerancia de §0.4, corregir «registros/lemas», el docstring de t26 y las horas de la tabla de trazabilidad indicadas. Son cambios de documentación, no exigencias de obtener nuevas señales.

No hace falta terminar t28, t29 o t30, ni producir resultados favorables, ni demostrar parentesco para cerrar el artículo I como análisis condicional. Sus resultados fonotácticos y con significados siguen aportando evidencia complementaria de afinidad. La revisión aquí no convierte los problemas de un experimento nuevo del artículo II en una refutación de los cálculos anteriores.

