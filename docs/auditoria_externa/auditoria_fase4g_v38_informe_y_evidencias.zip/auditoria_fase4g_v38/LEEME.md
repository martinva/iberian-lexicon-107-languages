# Entrega de cierre 4G

Dictamen: CONFORME para el artículo I v38 / acb66ef, en el alcance de cierre del §9 de 4F.

Abrir `informe/INFORME_FASE_4G_v38.html`. El informe se ofrece también en Markdown.

- `evidencias/`: integridad, matriz de cierre, comparación de ejecuciones y pruebas de integración.
- `salidas/`: salidas de los originales y logs sintéticos claramente identificados.
- `referencias/`: JSON/logs recibidos antes de ejecutar y alcance exacto de 4F.
- `fuentes_citadas/`: artículo y código/documentos relevantes, con versiones HTML numeradas por líneas.
- `programas/`: programas propios de la auditoría; no son sustitutos de los programas del estudio.

No se incluyen el corpus, los diccionarios grandes ni claves prospectivas en claro. No se ha revisado ni vuelto a puntuar el artículo II.

## Reproducción de la auditoría

Se necesita un clon del repositorio en acb66ef, con las fuentes ya presentes, y Python con NumPy.

```sh
python programas/verifica_integridad.py /ruta/al/repo /ruta/a/adjuntos /ruta/a/esta/entrega
python programas/ejecuta_cierre.py /ruta/al/repo /ruta/a/esta/entrega
python programas/prueba_integracion.py /ruta/al/repo /ruta/a/esta/entrega
```

`ejecuta_cierre.py` conserva las referencias antes de ejecutar, escribe los resultados del estudio en la carpeta normal del repositorio y copia las salidas a la entrega. Usar un clon de trabajo, no un depósito de evidencias inmutable. Las funciones del estudio no se modifican. `prueba_integracion.py` ejecuta los bloques principales originales con entradas sintéticas en directorios temporales.

Las semillas se conservan y se documentan en el informe. `MANIFIESTO_SHA256.json` registra los archivos entregados, salvo el propio manifiesto.
