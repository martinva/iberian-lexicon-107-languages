"""Pruebas independientes de cierre de los dos consumidores de 4F.
Importa las funciones originales. En las pruebas de flujo ejecuta el bloque
__main__ original (AST sin modificar), sustituyendo únicamente entradas por
matrices sintéticas. No usa ni escribe resultados lingüísticos.
Uso: python prueba_integracion.py REPO DIRECTORIO_ENTREGA
"""
from pathlib import Path
import argparse, ast, contextlib, csv, hashlib, importlib, io, json, sys, tempfile, types, warnings
import numpy as np

def main():
    ap=argparse.ArgumentParser();ap.add_argument('repo',type=Path);ap.add_argument('entrega',type=Path);a=ap.parse_args()
    r=a.repo.resolve();o=a.entrega.resolve();sys.path.insert(0,str(r/'4_programas'))
    t15=importlib.import_module('t15_solidez_unidades');t26=importlib.import_module('t26_prestabilidad')
    checks=[]; avisos=[]
    def add(name,result):
        json.dumps(result,allow_nan=False);checks.append({'prueba':name,'superada':True,'salida':result})
    for name,data in [('sin_filas',{}),('todas_indefinidas',{'a':(None,None,None,None,1),'b':(None,None,None,None,0)}),('mixto',{'a':(None,None,None,None,1),'b':(-5.,1,'X',-2.,2),'c':(-4.,2,'Y',-4.5,2)})]:
        out=t15.agrega_quitando_una(data)
        if name=='mixto': assert out==dict(z_mas_debil=-4.,z_mas_fuerte=-5.,primero_en=1,casos=3,indefinidos=1,menor_separacion=-.5)
        else: assert out['z_mas_debil'] is out['z_mas_fuerte'] is out['menor_separacion'] is None and out['indefinidos']==len(data)
        add('t15_agrega_'+name,out)
    for name,data in [('sin_lenguas',{}),('todas_indefinidas',{'a':dict(unidades=2,rho=None),'b':dict(unidades=1,rho=None)}),('mixto',{'a':dict(unidades=2,rho=None),'b':dict(unidades=9,rho=.3),'c':dict(unidades=9,rho=-.1)}),('solo_una_valida',{'a':dict(unidades=2,rho=None),'b':dict(unidades=9,rho=.3)})]:
        out=t26.agrega_referencia(data);assert out['por_lengua']==data
        if name=='mixto':assert out['sin_rho']==1 and abs(out['rho_mediana']-.1)<1e-12 and out['rho_minima']==-.1 and out['rho_maxima']==.3
        elif name=='solo_una_valida':assert out['rho_minima']==out['rho_maxima']==out['rho_mediana']==.3 and out['sin_rho']==1
        else:assert out['rho_minima'] is out['rho_maxima'] is out['rho_mediana'] is None and out['sin_rho']==len(data)
        add('t26_agrega_'+name,out)
    # Bloques __main__ originales completos, con diccionarios y matrices sintéticos.
    def run_main(module,env):
        src=Path(module.__file__).read_text(encoding='utf-8');tree=ast.parse(src)
        block=next(n for n in tree.body if isinstance(n,ast.If) and '__name__' in ast.unparse(n.test))
        code=compile(ast.Module(body=block.body,type_ignores=[]),module.__file__,'exec')
        stdout=io.StringIO()
        with warnings.catch_warnings(record=True) as ws,contextlib.redirect_stdout(stdout):
            warnings.simplefilter('always');exec(code,env)
        avisos.extend({'categoria': w.category.__name__, 'mensaje': str(w.message)} for w in ws)
        numericos=[w for w in ws if issubclass(w.category, RuntimeWarning)]
        assert not numericos,[str(w.message) for w in numericos]
        json.dumps(env['res'],allow_nan=False)
        return env['res'],stdout.getvalue()
    # t15: todas las nulas constantes, incluidas las rutas b/c/d/e.
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);(root/'4_programas').mkdir();(root/'resultados').mkdir()
        u=[{'id':f'A{i}','formas':['a']} for i in range(1,31)]
        db=types.SimpleNamespace(nombre='sintetico')
        fake=types.SimpleNamespace(unidades_plomos=lambda:u,wikcionario=lambda:{'Basque':db,'X':db},opendata=lambda:db,wordnet=lambda:{'Euskera, WordNet':db})
        def tabla(us,*args,**kw):return [v['id'] for v in us],np.zeros(len(us)),np.full((20,len(us)),.1)
        def pares(us,d,c,s,rnd):
            ids=[x['id'] for x in us]
            return {(i,j):0. for i in ids for j in ids},{(i,j):np.full(s,.1) for i in ids for j in ids}
        env=dict(vars(t15),fuentes=fake,tabla=tabla,pares=pares,__file__=str(root/'4_programas/t15.py'))
        result,log=run_main(t15,env);assert result['a_quitando_una']['indefinidos']==30
        assert all(v['indefinidos']==2000 and v['z_mediano'] is None for v in result['b_subconjuntos'].values())
        add('t15_main_todas_indefinidas',result)
        (o/'salidas/t15_sintetico_nulo.log').write_text(log,encoding='utf-8')
    # t26: mismo bloque original para referencia totalmente nula y mixta.
    actual=list(csv.DictReader(open(r/'1_fuentes_lexicas/wold_prestabilidad_35_unidades.csv',encoding='utf-8')))
    u=[{'id':v['id'],'formas':['a']} for v in actual];n=len(u)
    for mode in ['todas_indefinidas','mixto']:
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'4_programas').mkdir();(root/'resultados').mkdir();(root/'1_fuentes_lexicas').mkdir()
            (root/'1_fuentes_lexicas/wold_prestabilidad_35_unidades.csv').write_bytes((r/'1_fuentes_lexicas/wold_prestabilidad_35_unidades.csv').read_bytes())
            db={name:types.SimpleNamespace(nombre=name) for name in ['Basque','X','Y']}
            fake=types.SimpleNamespace(unidades_plomos=lambda:u,unidades_numerales=lambda:[],wikcionario=lambda:db,opendata=lambda:None)
            def tabla26(us,d,*args,**kw):
                z=np.tile(np.linspace(.2,.8,20)[:,None],(1,len(us))) if mode=='mixto' and d.nombre=='X' else np.full((20,len(us)),.1)
                return [v['id'] for v in us],np.linspace(0,1,len(us)),z
            env=dict(vars(t26),fuentes=fake,tabla=tabla26,AQUI=str(root/'4_programas'))
            result,log=run_main(t26,env)
            assert result['lenguas']['sin_rho']==(3 if mode=='todas_indefinidas' else 2)
            assert (result['lenguas']['rho_mediana'] is None)==(mode=='todas_indefinidas')
            add('t26_main_'+mode,result)
            (o/f'salidas/t26_sintetico_{mode}.log').write_text(log,encoding='utf-8')
    evidence={'pruebas':len(checks),'superadas':sum(x['superada'] for x in checks),'sin_modificar_codigo_original':True,'json_estricto':True,'notas':'Matrices sintéticas, no son cálculos lingüísticos. El bloque main conserva todas sus instrucciones; se sustituyen fuentes y matrices, y se redirigen las salidas a un directorio temporal.','comprobaciones':checks,'avisos':avisos,'nota_avisos':'ResourceWarning de cierre implícito de archivos no es un fallo numérico; se conserva en este registro. La prueba exige ausencia de RuntimeWarning y JSON estricto.'}
    (o/'evidencias/pruebas_integracion.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({k:v for k,v in evidence.items() if k!='comprobaciones'},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
