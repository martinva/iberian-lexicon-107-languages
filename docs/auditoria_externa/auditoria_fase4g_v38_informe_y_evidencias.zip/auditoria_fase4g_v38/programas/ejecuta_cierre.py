"""Ejecuta originales sin alterarlos y coteja salidas con hashes.
Uso: python ejecuta_cierre.py REPO DIRECTORIO_ENTREGA
Copia los resultados de referencia ANTES de ejecutar cada programa.
"""
from pathlib import Path
import argparse, hashlib, json, os, platform, subprocess, sys, time
import numpy as np

def sha(b): return hashlib.sha256(b).hexdigest()
def carga_estricta(p):
    def invalido(s): raise ValueError(f'Constante JSON no estándar: {s}')
    return json.loads(p.read_text(encoding='utf-8'), parse_constant=invalido)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('repo',type=Path);ap.add_argument('entrega',type=Path);a=ap.parse_args()
    r=a.repo.resolve();o=a.entrega.resolve()
    for d in ['evidencias','salidas','referencias']: (o/d).mkdir(parents=True,exist_ok=True)
    before={str(p.relative_to(r)):sha(p.read_bytes()) for p in (r/'4_programas').rglob('*.py')}
    (o/'evidencias/entorno.json').write_text(json.dumps({'python':sys.version,'numpy':np.__version__,'plataforma':platform.platform(),'PYTHONHASHSEED':'0'},indent=2),encoding='utf-8')
    jobs=[('casos_limite',[]),('comprobacion_rapida',[]),('t15_solidez_unidades',[]),('t26_prestabilidad',[])]
    records=[]
    for name,args in jobs:
        refs={}
        for ext in ['json','log']:
            p=r/'resultados'/f'{name}.{ext}'
            if p.exists(): refs[ext]=p.read_bytes();(o/'referencias'/p.name).write_bytes(refs[ext])
        cmd=[sys.executable,'-u',str(r/'4_programas'/f'{name}.py'),*args]
        start=time.perf_counter();print('EJECUTANDO',name,flush=True)
        with (o/'salidas'/f'{name}.log').open('wb') as log, (o/'salidas'/f'{name}.stderr.txt').open('wb') as err:
            res=subprocess.run(cmd,cwd=r/'4_programas',stdout=log,stderr=err,env={**os.environ,'PYTHONHASHSEED':'0','PYTHONDONTWRITEBYTECODE':'1'})
        record={'programa':name,'comando':cmd,'exit_code':res.returncode,'segundos':time.perf_counter()-start}
        logb=(o/'salidas'/f'{name}.log').read_bytes();record['sha256_log']=sha(logb)
        if 'log' in refs: record['log_identico']=refs['log']==logb;record['sha256_log_referencia']=sha(refs['log'])
        p=r/'resultados'/f'{name}.json'
        if res.returncode==0 and p.exists():
            b=p.read_bytes();(o/'salidas'/p.name).write_bytes(b);carga_estricta(p);record.update(json_estandar=True,sha256_json=sha(b))
            if 'json' in refs: record.update(json_identico=refs['json']==b,sha256_json_referencia=sha(refs['json']))
        record['stderr']=(o/'salidas'/f'{name}.stderr.txt').read_text(encoding='utf-8',errors='replace')
        records.append(record);(o/'evidencias/cotejo_ejecuciones.json').write_text(json.dumps(records,indent=2,ensure_ascii=False),encoding='utf-8')
        print('TERMINADO',json.dumps(record,ensure_ascii=False),flush=True)
        if res.returncode: raise RuntimeError(f'{name}: código {res.returncode}')
    after={str(p.relative_to(r)):sha(p.read_bytes()) for p in (r/'4_programas').rglob('*.py')}
    (o/'evidencias/codigo_inalterado.json').write_text(json.dumps({'identico':before==after,'numero_archivos_python':len(after),'sha256':after},indent=2),encoding='utf-8')
if __name__=='__main__':main()
