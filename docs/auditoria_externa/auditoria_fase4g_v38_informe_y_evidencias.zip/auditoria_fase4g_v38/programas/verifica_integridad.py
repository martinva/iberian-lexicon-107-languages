"""Integridad del cierre 4G. No cambia archivos del repositorio."""
from pathlib import Path
import argparse, hashlib, json, subprocess, zipfile

def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('repo',type=Path);ap.add_argument('adjuntos',type=Path);ap.add_argument('entrega',type=Path);a=ap.parse_args()
    r=a.repo.resolve();b=a.adjuntos.resolve();o=a.entrega.resolve();out=o/'evidencias';out.mkdir(exist_ok=True,parents=True)
    def git(*args):return subprocess.check_output(['git','-C',str(r),*args])
    expected={'incremental_4g.bundle':'9340a5100cc96b1b2900eef5c91571b5b5d5749597eea4d91f1b35732a84241d','iberian-basque_fase4g_cambios.zip':'b0c641df701330f664a95f32ff79a637b845daecf199f7dd415a20fcc6a4d09e'}
    hashes={f:{'esperado':s,'obtenido':sha((b/f).read_bytes())} for f,s in expected.items()}
    assert all(v['obtenido']==v['esperado'] for v in hashes.values())
    head=git('rev-parse','HEAD').decode().strip();assert head.startswith('acb66ef')
    subprocess.run(['git','-C',str(r),'merge-base','--is-ancestor','9ed51e4','HEAD'],check=True)
    fsck=subprocess.run(['git','-C',str(r),'fsck','--full'],capture_output=True,text=True);assert fsck.returncode==0
    tracked=set(git('ls-tree','-r','--name-only','HEAD').decode().splitlines())
    changed=git('diff','--name-only','9ed51e4','HEAD').decode().splitlines()
    with zipfile.ZipFile(b/'iberian-basque_fase4g_cambios.zip') as z:
        names=[n for n in z.namelist() if not n.endswith('/')];rows=[]
        for n in names:
            data=z.read(n);rec={'ruta':n,'sha256_zip':sha(data),'bytes':len(data),'en_git':n in tracked}
            if n in tracked:
                blob=git('show',f'HEAD:{n}');rec.update(sha256_git=sha(blob),identico_git=data==blob,identico_clon=data==(r/n).read_bytes());assert rec['identico_git'] and rec['identico_clon']
            rows.append(rec)
    lexical=[]
    for n in sorted(n for n in tracked if n.startswith('1_fuentes_lexicas/')):
        old=git('show',f'9ed51e4:{n}');new=git('show',f'HEAD:{n}');work=(r/n).read_bytes()
        lexical.append({'ruta':n,'sha256_9ed51e4':sha(old),'sha256_acb66ef':sha(new),'sha256_clon':sha(work),'identicos':old==new==work})
    assert all(v['identicos'] for v in lexical)
    keys=[]
    for folder in ['sufijos','prospectiva','prospectiva_v2']:
        d=r/'2_criterios/jurado'/folder
        k=next(d.glob('CLAVE_*.tsv'));s=d/'clave_sha256.txt'
        expected_key=s.read_text().strip().split()[0];real=sha(k.read_bytes())
        keys.append({'ruta':str(k.relative_to(r)),'sha256_compromiso':expected_key,'sha256_clon':real,'coincide':real==expected_key,'bytes':k.stat().st_size});assert real==expected_key
    history=git('log','--reverse','--format=%H %aI %cI %s','9ed51e4..HEAD').decode()
    lexical_diff=git('diff','--name-only','9ed51e4','HEAD','--','1_fuentes_lexicas').decode()
    missing=sorted(set(changed)-set(names));assert not missing
    result={'head':head,'base':git('rev-parse','9ed51e4').decode().strip(),'hashes_adjuntos':hashes,'fsck_returncode':fsck.returncode,'fsck_salida':fsck.stdout+fsck.stderr,'archivos_git_cambiados':len(changed),'archivos_zip':len(names),'faltantes_zip':missing,'archivos':rows,'fuentes_lexicas_archivos':len(lexical),'fuentes_lexicas_diff':lexical_diff,'fuentes_lexicas_identicas':all(v['identicos'] for v in lexical),'claves':keys,'historial':history}
    (out/'integridad.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8');(out/'datos_sin_cambios.json').write_text(json.dumps(lexical,indent=2),encoding='utf-8')
    (out/'historial_incremental.txt').write_text(history,encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['archivos']},indent=2,ensure_ascii=False))
if __name__=='__main__':main()
