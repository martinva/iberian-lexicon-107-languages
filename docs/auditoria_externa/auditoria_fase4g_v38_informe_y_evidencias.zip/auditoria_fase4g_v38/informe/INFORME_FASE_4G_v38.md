# Auditoría de fase 4G: cierre del artículo I

**Artículo v38 · Repositorio `acb66ef` · 21 de noviembre de 2026**

## 1. Dictamen

# CONFORME

**Quedan cerradas las condiciones finitas del §9 del informe 4F.** Este dictamen corresponde al artículo I v38 y al repositorio `acb66ef10773066685a24819f49d2d7f560a284f`, dentro del alcance de la auditoría computacional y de la concordancia entre resultados, especificación y redacción previamente acordado.

No quedan correcciones adicionales exigidas para cerrar esas condiciones. El artículo II está aplazado y no se ha vuelto a evaluar ni a puntuar en esta fase. La comprobación de sus claves se limita a la integridad documental solicitada.

Este conforme no convierte las propuestas semánticas en traducciones verificadas ni establece una filiación histórica. Son limitaciones del estudio que ya se declaran, no defectos pendientes de cierre. La afinidad fonotáctica y la afinidad con significados siguen siendo evidencias complementarias; su convergencia no se trata como independencia estadística ni como una probabilidad causal de parentesco o préstamo.

## 2. Identificación e integridad

| Objeto | Comprobación |
|---|---|
| `incremental_4g.bundle` | SHA-256 `9340a5100cc96b1b2900eef5c91571b5b5d5749597eea4d91f1b35732a84241d`: coincide |
| `iberian-basque_fase4g_cambios.zip` | SHA-256 `b0c641df701330f664a95f32ff79a637b845daecf199f7dd415a20fcc6a4d09e`: coincide |
| Artículo externo al árbol Git | `articulo_v38.md`, SHA-256 `781bb5fa1a5f6fab927f2aeddd1149ebb06f1b76fea9ac63cd1a3a784f2b4533` |
| Diferencia desde `9ed51e4` | 13 archivos versionados; todos están en el ZIP, además del artículo |
| Integridad de Git | `git fsck --full` termina correctamente, sin salida de error |
| Fuentes léxicas | 54 archivos, idénticos byte a byte en base, HEAD y clon actual |
| Claves con compromiso | Las tres coinciden con su SHA-256 desde el clon, sin convertir finales de línea |

Se reconstruyó el historial a partir de los bundles recibidos, se incorporó el incremental y se comprobó la ancestralidad de `9ed51e4`. Los tres nuevos commits son `18b0446` (pausa del artículo II), `5fdf0db` (correcciones) y `acb66ef` (restauración de finales de línea). La comparación de `1_fuentes_lexicas/` entre base y HEAD es vacía. No se interpreta el cambio transitorio de CRLF como una alteración persistente de datos.

El artículo no forma parte del árbol versionado del bundle: queda identificado por su archivo del ZIP y su hash independiente. Evidencias: [integridad](../evidencias/integridad.json), [hashes de las fuentes](../evidencias/datos_sin_cambios.json), [historial](../evidencias/historial_incremental.txt).

## 3. Matriz de cierre

Los números de línea corresponden a los archivos exactos recibidos, sin reformatear. Los programas se expresan con rutas relativas a la raíz del repositorio.

| Condición | Estado | Archivo y líneas | Comprobación |
|---|---|---|---|
| Código: t15 vacío | **Cerrada** | `4_programas/t15_solidez_unidades.py:57–65, 90–92` | La agregación se delega a agrega_quitando_una; sin valores válidos devuelve null y cuenta indefinidos. Se ejecutaron entradas vacías, totalmente indefinidas y mixtas, además del flujo completo con matrices constantes. |
| Código: t26 sin correlaciones | **Cerrada** | `4_programas/t26_prestabilidad.py:34–39, 58–61` | Conserva todas las lenguas, cuenta sin_rho y calcula extremos y mediana solo sobre valores válidos. Sin valores válidos devuelve null y no intenta ordenarlos ni formatearlos como números. |
| Integración y serialización | **Cerrada** | `4_programas/casos_limite.py:54–65` | La comprobación 9 llama a las funciones reales. Se añaden diez pruebas independientes, incluidas tres ejecuciones del bloque principal original con datos sintéticos. Todas generan JSON estricto. |
| Síntesis condicionada | **Cerrada** | `articulo_v38.md:45, 48, 50, 54` | La retirada se limita a cuatro unidades propuestas como préstamos; se distinguen clasificación y controles sin parientes; la conclusión se condiciona a los modelos nulos y a las comprobaciones realizadas. |
| Contacto y fuente común | **Cerrada** | `articulo_v38.md:50, 652, 690` | El contacto se resume solo para las 17 parejas. Se aclara que los p de t27 cuentan préstamos de cualquier donante y no constituyen un contraste específico de fuente romance. Se declara que la fuente común no queda excluida ni cuantificada. |
| Segundo jurado | **Cerrada** | `articulo_v38.md:428` | Siete retornos previstos, tres realizados y cuatro no realizados; se distingue el criterio contrario sobre seis paralelos. Se elimina grupo limpio y se declara que el resultado no certifica independencia histórica de las glosas. |
| Regularidad | **Cerrada** | `articulo_v38.md:640–642` | La regularidad es evidencia relevante, no identificador suficiente del mecanismo histórico. Se conservan el nulo condicional y la igualdad práctica al ajustar tamaños. |
| Tolerancia y vacíos en es/en | **Cerrada** | `5_especificacion/ESPECIFICACION_FUNCIONAL_es.md:37–39; FUNCTIONAL_SPECIFICATION_en.md:37–39` | Coinciden ambas formulaciones con el suelo max(1, máximo absoluto del nulo). Los agregados vacíos de t15 y las correlaciones no calculables de t26 quedan documentados. |
| Registros, no lemas; sorteos de t26 | **Cerrada** | `5_especificacion/ESPECIFICACION_FUNCIONAL_es.md:448; FUNCTIONAL_SPECIFICATION_en.md:448; 4_programas/t26_prestabilidad.py:1–5` | Se habla de 5.513 registros con nota y se documentan los 500 sorteos propios como desviación del plan. La formulación inicial de la declaración se conserva como histórico, no como especificación vigente. |
| Resultados y logs | **Cerrada** | `resultados/t15_solidez_unidades.json y .log; resultados/t26_prestabilidad.json y .log` | Los dos JSON y los dos logs regenerados coinciden byte a byte con HEAD. Frente a 4F, t15 no cambia y t26 solo añade lenguas.sin_rho=0. |
| Horas e incidente documental | **Cerrada** | `resultados/DECLARACIONES_PREVIAS.md:27–28; 2_criterios/jurado/prospectiva_v2/respuestas/DESCARTADA_Mistral_envio1.md:19–23` | Las horas coinciden con Git: aab61f9, 19:28:32; 6661a16, 19:25:42. La nota distingue la intención de adjuntar archivos del texto realmente pegado desde bytes verificados. |
| Finales de línea y datos | **Cerrada** | `.gitattributes:1–5; comparación Git 9ed51e4..acb66ef` | Las tres claves reproducen su compromiso SHA-256 desde el clon. Los 54 archivos de fuentes léxicas tienen los mismos bytes en ambos estados y en el clon actual. El incidente intermedio de CRLF queda documentado. |

La matriz está también en [JSON](../evidencias/matriz_cierre.json). El [§9 de 4F](../referencias/condiciones_finitas_4F_seccion9.md) se conserva como referencia del alcance de esta revisión.

## 4. Ejecuciones reales y regresión

Se ejecutaron los originales sin modificarlos, con Python 3.13.5, NumPy 2.3.5, Linux y `PYTHONHASHSEED=0`. Los archivos de referencia se copiaron antes de ejecutar. Se verificaron después los hashes de los **36 archivos Python originales**, que permanecen inalterados.

| Programa | Terminación | Resultado |
|---|---|---|
| `casos_limite.py` | Código 0 | «todo correcto», incluida la comprobación 9 |
| `comprobacion_rapida.py` | Código 0 | Comprobaciones superadas |
| `t15_solidez_unidades.py` | Código 0 | JSON y log idénticos byte a byte a los entregados |
| `t26_prestabilidad.py` | Código 0 | JSON y log idénticos byte a byte a los entregados |

No se han repetido todos los programas inalterados del estudio ni las pruebas del artículo II. Esta es una reejecución focal del cierre de 4F, que se apoya en las auditorías anteriores para el resto del material inalterado.

**Semillas y generador.** No se cambiaron. Los sorteos emplean `random.Random`, Mersenne Twister, con el texto base `20261120`. En t15, las tablas usan `20261120|solidez|plomos|<nombre del diccionario>`; los subconjuntos, `20261120|solidez|subconjuntos`; y los significados cambiados, `20261120|solidez|cambiados|<fuente>`. t26 genera sus propios 500 sorteos mediante `20261120|solidez|prestabilidad|<nombre del diccionario>`. `PYTHONHASHSEED` no sustituye esas semillas.

### Valores conservados

| Comprobación | Valor obtenido |
|---|---:|
| t15, retirando una unidad: primero | 30 de 30 |
| t15, z más débil / más fuerte | −11,75 / −12,97 |
| t15, separación mínima | 7,48 |
| t15, subconjuntos de 20: primero | 2.000 de 2.000 |
| t15, subconjuntos de 15: primero | 1.999 de 2.000 |
| t15, subconjuntos de 10: primero | 1.975 de 2.000 |
| t26, Wikcionario: ρ | −0,14639364474103508 |
| t26, Open Data Euskadi: ρ | −0,03908110417945866 |
| t26, lenguas sin ρ en estos datos | 0 |

El JSON de t15 es idéntico al de 4F. En t26, retirando el campo añadido `lenguas.sin_rho = 0`, todos los valores y la estructura previa coinciden con 4F. No hay una modificación de las cifras para lograr la conformidad.

Evidencias: [cotejo de ejecuciones](../evidencias/cotejo_ejecuciones.json), [comparación con 4F](../evidencias/cambios_resultados_respecto_4f.json), [código inalterado](../evidencias/codigo_inalterado.json).

## 5. Pruebas independientes de los consumidores

Además de ejecutar `casos_limite.py`, se escribieron y ejecutaron diez comprobaciones independientes. Siete llaman directamente a las funciones de agregación originales con conjuntos vacíos, totalmente indefinidos, mixtos o con una única correlación válida. Las otras tres ejecutan el bloque principal original de t15 o t26, sustituyendo únicamente las fuentes y matrices por entradas sintéticas y redirigiendo las salidas a directorios temporales.

En t15 se recorren también los subconjuntos, grupos, retirada adversa y significados cambiados con todas las nulas constantes. En t26 se recorren tanto una referencia totalmente indefinida como una mezcla de correlaciones válidas e indefinidas.

**Resultado: diez de diez superadas.** No aparecen `ValueError` por extremos vacíos ni `TypeError` por ordenar `None`. Las filas indefinidas se conservan o contabilizan según el procedimiento, los agregados ausentes son `null` y todas las salidas superan `json.dumps(..., allow_nan=False)`. No hubo advertencias numéricas `RuntimeWarning`.

Al activar todas las advertencias, Python informa de cierres implícitos de archivos (`ResourceWarning`); se conservan en la evidencia. No afectan a los valores ni a la serialización, y no constituyen una condición de cierre adicional de esta auditoría. La prueba exige ausencia de advertencias numéricas y serialización estándar, no una certificación general de estilo del código.

Evidencias: [programa independiente](../programas/prueba_integracion.py) y [resultados de integración](../evidencias/pruebas_integracion.json). Estas matrices son diagnósticos sintéticos, no nuevas cifras lingüísticas.

## 6. Cierre de redacción y documentación

La síntesis, la tabla S1 y los pasajes especificados ya no presentan una exclusión general del azar o del contacto. La línea 54 condiciona la conclusión a los modelos nulos examinados. La línea 50 limita la referencia de contacto a las 17 parejas y declara que t27 no excluye ni cuantifica una fuente común.

El segundo jurado, línea 428, diferencia correctamente siete retornos previstos, tres obtenidos y cuatro no obtenidos. También distingue el criterio contrario sobre seis paralelos, alcanzado con tres permanencias en nivel III. La clasificación a partir de fichas no se presenta como certificación de independencia histórica.

El apartado 11.6, línea 652, especifica que las dos colas hipergeométricas cuentan préstamos de cualquier donante, no solo de fuente romance; declara expresamente que esos p no son un contraste específico de fuente romance común. La tabla de explicaciones mantiene las formulaciones «compatible, no demostrado», «no excluido» y «no descartado por la recodificación».

No he encontrado una corrección pendiente que impida cerrar los puntos de redacción de 4F. La lectura de estos pasajes es conjunta con las limitaciones expresamente conservadas en el texto, no una aprobación de frases aisladas privadas de su contexto.

La tolerancia y las salidas vacías se describen de manera concordante en español e inglés. Las horas `aab61f9` y `6661a16` concuerdan con los commits. La corrección del relato del envío conserva la nota inicial como histórico y añade de forma inequívoca el procedimiento real. El aplazamiento de las entradas 12–15 aparece en `DECLARACIONES_PREVIAS.md:562–564` y no retira sus materiales.

Fuentes localizadas: [artículo v38](../fuentes_citadas/articulo_v38.html), [t15](../fuentes_citadas/t15_solidez_unidades.html), [t26](../fuentes_citadas/t26_prestabilidad.html), [especificación española](../fuentes_citadas/ESPECIFICACION_FUNCIONAL_es.html), [especificación inglesa](../fuentes_citadas/FUNCTIONAL_SPECIFICATION_en.html).

## 7. Alcance final del conforme

**CONFORME para el artículo I v38 / acb66ef en el alcance auditado. No quedan condiciones finitas de 4F abiertas.**

Se avala el cierre de los defectos identificados, la repetibilidad de las ejecuciones focales y la adecuación de los pasajes corregidos al alcance de los resultados. No se certifican todas las fuentes filológicas originales ni se afirma la corrección de todas las glosas o una causa histórica determinada. Esos límites ya están declarados y no exigen mantener un «conforme con reservas» por los mismos puntos que ahora han quedado corregidos.

El título descriptivo y la conclusión de afinidad cuantitativa reproducida son compatibles con este dictamen. El cierre del artículo I no requiere finalizar ni obtener resultados favorables del artículo II.
