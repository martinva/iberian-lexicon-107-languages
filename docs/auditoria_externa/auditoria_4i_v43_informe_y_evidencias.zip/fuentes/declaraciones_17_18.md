## 17. Mapa de distancias entre lenguas para el léxico de los plomos (declarada el 22-11-2026, antes de ejecutar; artículo I)

La hora verificable de esta declaración es la de su commit.

**Propósito.** Representación descriptiva, sin contraste ni conclusión: dónde quedan el ibérico de los plomos y el euskera entre sí y respecto de otras lenguas cuando se mide, todas contra todas, la distancia en el mismo léxico. Es el equivalente lingüístico de los mapas de distancia genética (todas las poblaciones contra todas, proyectadas en dos ejes).

**Programa.** `4_programas/t32_mapa_distancias.py` (nuevo). Salidas: `resultados/t32_mapa_distancias.json`, `resultados/figuras/t32_mapa_lexico.png` y `resultados/figuras/t32_mapa_perfil.png`.

**Lenguas.** Todas las del Wikcionario que usa la prueba con significados (los dos archivos de `fuentes.wikcionario()`), más el ibérico. Se excluye la lengua que tenga candidatas en menos de 12 de los significados. La familia de cada lengua es la de la tabla `FAM_WIK` de `t08_perfil.py`, completada con la clasificación de Glottolog para las que no figuran en ella.

**Significados.** Los 30 de las unidades de los plomos (`unidades_plomos.json`) y los del léxico metrológico (`unidades_numerales.json`), con los términos ingleses (`terminos_en`) de la prueba con significados.

**Mapa A (léxico de los plomos).** Para cada pareja de lenguas X e Y y cada significado con candidatas en las dos: la menor distancia (función `dist`, clases de sonidos `reducida`; para el ibérico, sus formas) entre las candidatas de X y las de Y. Las candidatas de cada lengua y significado se limitan a 15, elegidas al azar una sola vez con semilla fija (`generador('mapa', lengua, id)`). Valor bruto de la pareja: media sobre los significados compartidos. Valor normalizado (como la LDND de Wichmann y otros 2010): el bruto dividido por la media de la misma distancia entre significados distintos, sobre 200 pares de significados distintos elegidos con semilla fija. Un valor de 1 corresponde a lo que da el azar; menos de 1, más proximidad que el azar.

**Mapa B (perfil de combinaciones de sonidos).** Divergencia de Jensen-Shannon entre perfiles (función `divergencia` de `pruebas.py`), con el léxico elegible completo de cada lengua del Wikcionario y el corpus ibérico completo, como en el apartado 7.4.

**Proyección y árbol.** Escalamiento multidimensional clásico (Torgerson) en dos ejes, con la proporción de variación que recogen; árbol UPGMA (promedio) de la misma matriz. Incertidumbre del mapa A: 200 remuestreos de los significados con reemplazamiento; cada réplica se proyecta y se alinea con la principal (Procrustes), y se dibuja la nube de cada lengua.

**Previsión.** (1) Las familias con varios miembros (romance, urálica, céltica, austronesia, bantú) forman grupos reconocibles en los dos mapas; es la comprobación de que el mapa refleja relaciones conocidas. (2) En el mapa A, la lengua más próxima al ibérico es el euskera, coherente con la prueba con significados.

**Qué contaría en contra.** Que las familias no se agrupen (el mapa no sería informativo y se diría así), o que la lengua más próxima al ibérico no sea el euskera. Se publica el resultado sea cual sea.

**Qué se hará.** El mapa se presenta en el artículo como descripción, sin conclusión añadida. Los valores de la matriz se publican completos.

## 18. Frecuencia del préstamo conjunto de los significados de los plomos en la base mundial de préstamos (declarada el 22-11-2026, antes de ejecutar; artículo I)

La hora verificable de esta declaración es la de su commit.

**Pregunta.** En las 41 lenguas de la base mundial de préstamos (WOLD; Haspelmath y Tadmor 2009), ¿con qué frecuencia se toman prestados a la vez los numerales y el resto de los significados de los plomos? Se usan las 41 lenguas, no un caso concreto.

**Datos.** Edición CLDF `lexibank/wold`, commit `1df62b9bdc7292b35982aea49b4d5bd1951f6f3e`, archivo `cldf/forms.csv` (columna `Borrowed`). Significados: los 35 de `1_fuentes_lexicas/wold_prestabilidad_35_unidades.csv` (10 numerales, N1 a N20, y 25 más).

**Programa.** `4_programas/t33_prestamo_conjunto_wold.py` (nuevo). Salida: `resultados/t33_prestamo_conjunto_wold.json`.

**Regla.** En cada lengua, un significado cuenta como prestado si alguna de sus palabras está clasificada «1. clearly borrowed» o «2. probably borrowed» (regla amplia); variante estricta: si todas lo están. Un significado sin palabras en esa lengua no se cuenta (el denominador es el de los significados presentes).

**Qué se da.** Para cada lengua, la proporción de numerales prestados y la de los demás significados prestados. Número de lenguas (de 41) con: todos los numerales prestados; al menos la mitad, tres cuartos y todos los demás significados prestados; y las dos cosas a la vez. Frecuencia observada k/41 y, como estimación con muestra pequeña, (k + 1)/(41 + 2), con intervalo binomial exacto del 95 %. Para comparar, la frecuencia que daría el producto de las frecuencias de cada significado si se prestaran independientemente (lo que muestra cuánto pesa la correlación entre préstamos de una misma lengua).

**Previsión.** Pocas lenguas tienen prestado todo el sistema numeral, y menos aún combinan eso con la mayoría de los demás significados. No se fija una cifra.

**Límites declarados.** Es una frecuencia en una muestra de 41 lenguas elegidas por su diversidad, no la probabilidad de un préstamo entre el ibérico y el euskera; no tiene en cuenta la dirección del préstamo ni la antigüedad, y la clasificación de préstamo es la de los autores de cada capítulo de la base.

**Qué se hará.** El resultado se presenta como dato descriptivo junto a la tabla de pruebas, sin conclusión añadida.

### 17–18. English summary (declared 22 November 2026, before running; article I)

17: descriptive all-against-all distance maps (lead lexicon, LDND-style normalised; sound-sequence profile, Jensen-Shannon) for the Wiktionary languages of the meaning test plus Iberian; classical MDS, UPGMA, 200 bootstrap replicates aligned by Procrustes. Predictions: known families cluster; Iberian's nearest language in the lexical map is Basque. 18: frequency in the 41 WOLD languages (CLDF commit 1df62b9) of borrowing the whole numeral set together with the other lead meanings; broad and strict rules; observed k/41, (k+1)/43 and exact 95 % interval; independence product shown for comparison. Both are reported as descriptive data, whatever the result.
