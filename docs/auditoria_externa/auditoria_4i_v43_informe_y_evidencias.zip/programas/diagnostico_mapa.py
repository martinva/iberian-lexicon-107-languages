"""Uso: python diagnostico_mapa.py /ruta/al/repo salida.json. Sensibilidad de la auditoría.
Usa los lectores y la regla de distancia del autor. El remuestreo solo necesita las
35 parejas del ibérico, no el MDS. Conserva el denominador de referencia por pareja.
"""
import sys, json, statistics
from pathlib import Path
from collections import Counter
import numpy as np
from scipy.cluster.hierarchy import to_tree, linkage
from scipy.spatial.distance import squareform
root=Path(sys.argv[1]).resolve(); sys.path.insert(0,str(root/'4_programas'))
import t32_mapa_distancias as m
W, ids=m.candidatas(); keys=sorted(W); ib=W['Iberian']; base_ref={}; unit_d={}
for l in keys:
    if l=='Iberian':continue
    x,y=sorted((l,'Iberian')); X,Y=W[x],W[y]
    sh=[u for u in ids if u in X and u in Y]; par=[(u,v) for u in ids if u in X for v in ids if v in Y and u!=v]; sel=m.generador('mapa-azar',x,y).sample(par,min(200,len(par)))
    base_ref[l]=statistics.mean(m.dmin(X[u],Y[v]) for u,v in sel); unit_d[l]={u:m.dmin(X[u],Y[u]) for u in sh}
rng=np.random.default_rng(20261122); winners=Counter(); empty=0
for _ in range(200):
    samp=rng.choice(ids,len(ids),replace=True); scores={}
    for l,du in unit_d.items():
        ds=[du[u] for u in samp if u in du]; empty+=int(not ds); scores[l]=statistics.mean(ds or du.values())/base_ref[l]
    winners[min(scores,key=scores.get)]+=1
r=json.loads((root/'resultados/t32_mapa_distancias.json').read_text()); out={'bootstrap_vecino_matriz_no_plano':dict(winners),'celdas_ib_sin_peso_en_replicas':empty};fam=r['lexico']['familias']; ibforme=set().union(*(x['formas'] for x in m.fuentes.hesperia())); src=m.fuentes.wikcionario(); out['perfil_iberico_euskera_sin_redondeo']=m.divergencia(m.perfil(ibforme),m.perfil(src['Basque'].formas)); out['perfil_iberico_fines_sin_redondeo']=m.divergencia(m.perfil(ibforme),m.perfil(src['Finnish'].formas))
for part,k in [('lexico','matriz_normalizada'),('perfil','matriz')]:
    z=r[part]; L=z['lenguas']; D=np.array(z[k]); J=np.eye(len(L))-np.ones_like(D)/len(L); eig=np.linalg.eigvalsh(-0.5*J@(D**2)@J)[::-1]; pos=eig[eig>1e-10]; Z=linkage(squareform(D),'average'); tree,nodes=to_tree(Z,rd=True); clades={frozenset(L[i] for i in node.pre_order()) for node in nodes}; X=np.array(z['mds']); famcheck={};
    for f in sorted(set(fam.values())):
        G=[i for i,l in enumerate(L) if fam[l]==f];
        if len(G)<2:continue
        H=[i for i in G if fam[L[np.argsort(D[i])[1]]]==f]; M=[i for i in G if fam[L[np.argsort(np.square(X-X[i]).sum(1))[1]]]==f]; famcheck[f]={'tamano':len(G),'vecino_matriz':len(H),'vecino_plano':len(M),'rama_exclusiva_UPGMA':frozenset(L[i] for i in G) in clades}
    out[part]={'ejes_positivos_desde_matriz_guardada':(eig[:3]/pos.sum()).tolist(),'por_grupo':famcheck,'celdas_sobre_uno_sin_diagonal_un_triangulo':int(np.count_nonzero(np.triu(D,1)>1)),'max':float(D.max())}
Path(sys.argv[2]).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
