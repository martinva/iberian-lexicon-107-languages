"""Recuenta TODOS los umbrales y sus intervalos desde las filas entregadas, no desde forms.csv.
Uso: python auditar_resumen_wold.py resultados/t33_prestamo_conjunto_wold.json salida.json
Las marginales a 4 decimales permiten recuperar la fracción reducida (denominador ≤41).
"""
import sys,json,math
from fractions import Fraction
from pathlib import Path
from scipy.stats import binomtest
r=json.loads(Path(sys.argv[1]).read_text()); out={}; n=r['lenguas']; assert n==41
for rule in ('amplia','estricta'):
    block=r[rule]; rows=block['por_lengua']; assert len({x['lengua'] for x in rows})==n
    N={x['lengua'] for x in rows if x['numerales'][1]>0 and x['numerales'][0]==x['numerales'][1]}; groups={'todos_los_numerales':N}
    for name,rat in [('mitad',Fraction(1,2)),('tres_cuartos',Fraction(3,4)),('todos',Fraction(1))]:
        O={x['lengua'] for x in rows if x['otros'][1]>0 and Fraction(*x['otros'])>=rat};groups['otros_'+name]=O;groups['numerales_y_otros_'+name]=O&N
    for key,G in groups.items():
        k=len(G); ic=binomtest(k,n).proportion_ci(method='exact'); ref=block[key];assert sorted(G)==ref['lenguas'] and k==ref['k'] and ref['frecuencia']==round(k/n,4) and ref['estimacion']==round((k+1)/(n+2),4) and all(abs(a-b)<0.00005000001 for a,b in zip(ic,ref['ic95']))
    P={}
    for key,p in block['frecuencia_por_significado'].items():
        fracs={Fraction(i,j) for j in range(1,n+1) for i in range(j+1) if abs(i/j-p)<.000050000001};assert len(fracs)==1;P[key]=fracs.pop()
    prods={t:float(math.prod(P[k] for k in ks)) for t,ks in [('todos_los_numerales',[k for k in P if k.startswith('N')]),('todos_los_otros',[k for k in P if not k.startswith('N')]),('todo_el_conjunto',list(P))]};assert all(math.isclose(v,block['independencia'][k],rel_tol=1e-14) for k,v in prods.items());out[rule]={'recuentos':{k:len(v) for k,v in groups.items()},'filas_comprobadas':len(rows),'registros_conjunto':len(P),'productos_recalculados':prods,'ic0_41':list(binomtest(0,n).proportion_ci(method='exact')),'marcados':{x['lengua']:x for x in rows if x['lengua'] in {'Japanese','Thai','TarifiytBerber','Yaqui','Wichi','Gurindji'}}}
Path(sys.argv[2]).write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
