"""Auditoría 4J. Uso: python verifica.py RUTA_CLON RUTA_SALIDA_JSON. No modifica el clon.
Solo se importan los lectores / reductores de NorthEuraLex y la medida de perfil para el diagnóstico
exploratorio. No se importan t34, t08 ni t18. Para reproducir exactamente los percentiles se
emplea la secuencia registrada; las tasas y la transformación de Bayes se recalculan con fracciones.
"""
from pathlib import Path
import argparse, json, sys, re, itertools
from collections import Counter
from fractions import Fraction as F
import numpy as np
p=argparse.ArgumentParser();p.add_argument('repo',type=Path);p.add_argument('salida',type=Path);args=p.parse_args()
repo=args.repo.resolve(); rd=lambda f: json.loads((repo/'resultados'/f).read_text())
t11=rd('t11_t13_estables.json'); orig=rd('t34_razon_verosimilitud.json'); t18=rd('t18_perfil_contacto.json')['parejas']; out={}
rows=t11['parejas']; groups=[[r for r in rows if isinstance(r[3],dict) and r[0] in labels] for labels in [('emparentadas cercanas','emparentadas lejanas'),('solo contacto',)]]
e='estables'; c='poco estables'; s='estables sin los numerales del dos al cinco'; ib=t11['iberico']['Basque']; thresholds={k:ib[k]['ventaja'] for k in [e,c,s]}
features=[lambda x:x[e]['ventaja']>x[c]['ventaja'],lambda x:x[e]['ventaja']>=thresholds[e],lambda x:x[s]['ventaja']>=thresholds[s]]
pairs=[[ [sum(bool(j(r[3])) for r in g),len(g)] for g in groups] for j in features]
sys.path.insert(0,str(repo/'4_programas'));from ibcomp import fuentes; from ibcomp.pruebas import perfil,divergencia
lex,meta=fuentes.northeuralex(); L=sorted(lex); names={l:meta[l]['Name'] for l in L}; inv={n:k for k,n in names.items()}; fam={l:meta[l].get('Family','') for l in L}; counts=Counter(fam.values()); eligible=[l for l in L if fam[l] and counts[fam[l]]>1]; prof={l:perfil(lex[l]) for l in L}; distances={l:{} for l in L}
for a,b in itertools.combinations(L,2): distances[a][b]=distances[b][a]=divergencia(prof[a],prof[b]);
lookup={a:sorted(row,key=lambda b:(row[b],b)) for a,row in distances.items()}; OK=[a for a in eligible if fam[a]==fam[lookup[a][0]]]; den=sum(counts[fam[l]]-1 for l in eligible); halves=den//2
contacts=[{'x':f['toma'],'y':f['da'],'rango':lookup[inv[f['toma']]].index(inv[f['da']])+1, 'misma_familia':fam[inv[f['toma']]]==fam[inv[f['da']]]} for f in t18]; assert all(r['rango']==t['puesto'] for r,t in zip(contacts,t18)); pairs.append([[len(OK),len(eligible)],[sum(r['rango']==1 for r in contacts),len(contacts)]])
priors=list(map(F,['.1','.25','.5','.75','.9'])); table={}
for i,((k,n),(h,m)) in enumerate(pairs,1):
 key=f'R{i}'; rr=F(2*k+1,2*(n+1))/F(2*h+1,2*(m+1)); post={str(float(x)):float(rr*x/(rr*x+1-x)) for x in priors}; seed=20261122+sum(map(ord,key)); rng=np.random.default_rng(seed); distr=rng.beta(k+.5,n-k+.5,100000)/rng.beta(h+.5,m-h+.5,100000); pts=np.quantile(distr,[.025,.975]).tolist(); base=orig[key]; assert base['emparentadas']==[k,n] and base['contacto']==[h,m] and base['razon']==round(float(rr),2); assert list(np.round(pts,2))==base['ic95'] and {a:round(b,3) for a,b in post.items()}==base['posterior']; table[key]={'grupos':[[k,n],[h,m]],'razon':float(rr),'razon_exacta':str(rr),'posterior_exacta':post,'cuantiles_registrados_sin_redondeo':pts,'semilla':seed,'sensibilidad_previa_uniforme':float(F(k+1,n+2)/F(h+1,m+2))}
out['rasgos']=table; out['umbrales_ibericos']=thresholds
pres=[]
for _,x,y,d in groups[0]:
 if x in inv and y in inv:
  order=lookup[inv[x]];pres.append(dict(x=x,y=y,puesto=order.index(inv[y])+1,primera=names[order[0]]))
out['diagnostico_R4']={'familias':dict(counts),'lenguas':len(eligible),'aciertos_por_lengua':len(OK),'pares_orientados_emparentados':den,'aciertos_por_pareja_designada':len(OK),'proporcion_parejas_uniformes':len(OK)/den,'proporcion_lengua_uniforme_luego_pariente_uniforme':sum(1/(counts[fam[l]]-1) for l in OK)/len(eligible),'prob_azar_cualquier_pariente':sum(counts[fam[l]]-1 for l in eligible)/len(eligible)/(len(L)-1),'prob_azar_comparador_unico':1/(len(L)-1),'contacto_pares':contacts,'receptoras_distintas':len({a['x'] for a in contacts}),'en_dos_grupos_mismas_lenguas':len(set(eligible)&{inv[a['x']] for a in contacts}),'pares_de_tabla11_presentes_con_nombres_exactos_en_NEL':pres,'solo_diagnostico_no_sustituye_resultado':True}
# Suprimir por turno todas las parejas que mencionen la misma lengua. Es sensibilidad, no un IC.
loo={}
for l in sorted(set(r[j] for g in groups for r in g for j in [1,2])):
 gg=[[r for r in g if l not in r[1:3]] for g in groups]; (k,n),(h,m)=[(sum(features[0](r[3]) for r in g),len(g)) for g in gg];loo[l]=((k+.5)/(n+1))/((h+.5)/(m+1))
out['R1_omision_por_lengua']=loo
html=(repo/'resultados/figuras/t32b_proximidad_lexica.html').read_text(); data=json.loads(re.search('const D=(.*?);\n',html).group(1)); matrix=np.array(rd('t32_mapa_distancias.json')['lexico']['matriz_normalizada']); ref=matrix[np.triu_indices(len(matrix),1)]; visor=np.array(data['M'])[np.triu_indices(len(matrix),1)]; diff=np.abs(visor-ref); out['visor']={'pares':len(diff),'error_maximo':float(diff.max()),'no_identicos':int((diff>1e-12).sum()),'radio_saturado':int((ref>1.08).sum()),'ejemplos_umbral':[(float(u),int((visor<u).sum()),int((ref<u).sum())) for u in [x/100 for x in range(91)] if (visor<u).sum()!=(ref<u).sum()]}
args.salida.write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
