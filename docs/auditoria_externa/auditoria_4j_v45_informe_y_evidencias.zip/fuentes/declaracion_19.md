## 19. Razón de verosimilitud de los resultados de la segunda parte frente a parejas emparentadas y de contacto (declarada el 22-11-2026, antes de calcular; artículo I)

La hora verificable de esta declaración es la de su commit.

**Pregunta.** ¿Cuántas veces es más frecuente cada resultado observado entre el ibérico y el euskera en las parejas de lenguas emparentadas que en las parejas de solo contacto del propio estudio? Es una medida de respaldo que no exige probabilidad previa y que permite ordenar las pruebas de la segunda parte.

**Programa.** `4_programas/t34_razon_verosimilitud.py` (nuevo). Lee solo resultados ya publicados: `t11_t13_estables.json`, `t08_perfil.json` y `t18_perfil_contacto.json`. Salida: `resultados/t34_razon_verosimilitud.json`.

**Rasgos** (resultado del ibérico con el euskera, y su frecuencia en cada grupo de control):
- R1 (11.1): ventaja en los significados estables mayor que en los poco estables.
- R2 (11.1): ventaja en los estables igual o mayor que la del ibérico con el euskera (0,533).
- R3 (11.1): ventaja en los estables sin los numerales del dos al cinco igual o mayor que la del ibérico con el euskera en ese mismo conjunto.
- R4 (11.3): la lengua emparejada es la más próxima por perfil. Emparentadas: validación del apartado 7.4 (NorthEuraLex, clases completas; la más próxima es de su familia), 77 de 98. Contacto: las 17 parejas de préstamo masivo de la tabla 15, donante primera.

**Grupos.** R1–R3: emparentadas = «emparentadas cercanas» + «emparentadas lejanas»; contacto = «solo contacto» (tabla 11). Se excluyen «parentesco lejano y préstamos» y «sin relación».

**Estimación.** Proporción de Jeffreys, (k + 0,5)/(n + 1), en cada grupo; razón = emparentadas / contacto. Intervalo del 95 %: 100.000 extracciones de Beta(k + 0,5, n − k + 0,5) en cada grupo, semilla fija; percentiles 2,5 y 97,5 de la razón. Para cada rasgo por separado, probabilidad posterior de la herencia frente al contacto con probabilidades previas de 0,10, 0,25, 0,50, 0,75 y 0,90 (posterior = R·π / (R·π + 1 − π)). Las razones de rasgos distintos no se multiplican, porque no son independientes.

**Orden.** Las pruebas se ordenan por el límite inferior del intervalo de su razón (de mayor a menor); las que no tienen controles de los dos tipos (11.2, 11.4, 11.5, 11.6) van al final, con su lectura cualitativa.

**Previsión.** R4: razón mayor que 10. R1: entre 1,5 y 4. R2 y R3: mayores que 1, sin cifra.

**Qué contaría en contra.** Una razón menor que 1 en cualquier rasgo. Se publica el resultado sea cual sea.

**Límites declarados.** Las parejas de control son pocas y no son independientes; los grupos de R4 proceden de la misma base (NorthEuraLex) pero de dos selecciones distintas; las razones describen estas muestras de control, no la población de todas las parejas de lenguas.

### 19. English summary

Likelihood ratios (Jeffreys proportions; 95 % interval by Beta sampling) of four features of the Iberian–Basque result, computed in related vs contact-only control pairs from published outputs (t11_t13, t08, t18); posterior probabilities for priors 0.10–0.90, per feature, not combined. Tests ordered by the lower bound of their ratio; tests without both control groups go last. Predictions: R4 > 10; R1 between 1.5 and 4; R2, R3 > 1.
