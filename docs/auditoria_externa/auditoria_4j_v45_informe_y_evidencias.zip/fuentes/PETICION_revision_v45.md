# Fase 4J: artículo I, v44 → v45

Parto de la v44 de tu acta 4I. Nada de lo auditado se repite: los programas t01–t33 no cambian y el texto solo cambia donde indica el parche.

1. **Tu reserva de 11.8:** la frase inicial queda con tu pregunta literal; en 12.4 f), «con su alcance».
2. **Nuevo, declarado antes de calcular (declaración 19, commit 65f2e78, 08:52:33; programa y resultado en b97aea8, 08:53:14):** razón de verosimilitud de cuatro rasgos de la segunda parte frente a las parejas emparentadas y de contacto del propio estudio (t34). Responde a tu objeción de 4I de que «no se ha medido la frecuencia de ese puesto bajo herencia»: para R4 se usa la validación de 7.4 (77/98) frente a las 17 parejas de la tabla 15 (0/17). Se declara en el texto que los recuentos de R1 y R4 ya eran públicos y que hubo una estimación orientativa antes de la declaración, de modo que sus previsiones no son ciegas.
   - Resultados: R4 28,2 [5,8; →]; R1 2,35 [1,39; 5,69]; R2 2,1 [0,13; 1672]; R3 0,7 [0; 418]. R3 por debajo de 1 cuenta en contra según la declaración y así se dice; no discrimina porque ningún control de ningún grupo alcanza el valor.
   - Uso en el texto: la tabla S2 pasa a ordenarse por el límite inferior del intervalo de la razón (R4, R1, magnitud R2/R3), con las pruebas sin controles de los dos tipos al final (11.2, 11.4, 11.5, 11.6) y su lectura de la v44. Nueva tabla S3: probabilidad posterior para previas 0,10–0,90, por rasgo, sin combinar. Nuevo 11.9 con la tabla 17.
   - Resumen, S1 y conclusión 5: «no se decide, pero el respaldo de cada prueba se puede medir» con las dos razones.
3. **t32c (comprobación posterior que propusiste):** 200/200 sin proyectar, recíprocos 200/200, distancia 0,33–0,58, segunda lengua ≥ 0,70; en 11.7.
4. **Visor interactivo** de la misma matriz (t32b_proximidad_lexica.html), citado en 11.7.
5. **Transparencia:** añadido cómo puede repetir cualquiera la auditoría.

Pido: (a) que la razón de verosimilitud sea una medida aceptable para ordenar las pruebas por respaldo, y si los rasgos, grupos y estimador son adecuados; (b) que S2, S3, resumen y conclusiones no afirmen más de lo que sostienen; (c) dictamen.

Paquete: v45, diff v44→v45, t34 (programa y JSON), t32c (JSON), log y bundle 181c7d6..b97aea8 (base: 4I).
