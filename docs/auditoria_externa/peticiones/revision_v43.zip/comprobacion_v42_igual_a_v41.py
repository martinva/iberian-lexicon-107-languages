import re,sys
src=open('BORRADOR_v41_articulo_estadistica_2026-11-21.md',encoding='utf-8').read().split('\n')
out=[]
hist=src[2]
def sents(p):
    # sentence split avoiding parentheses/brackets
    res=[];buf='';depth=0
    i=0
    while i<len(p):
        c=p[i];buf+=c
        if c in '([':depth+=1
        elif c in ')]':depth=max(0,depth-1)
        if c=='.' and depth==0 and i+2<len(p) and p[i+1]==' ' and (p[i+2].isupper() or p[i+2] in '¿«*(') and not re.search(r'(\bs\. v|\bp|\bcf|\bvol|\bed|\bn|\bfig|\btab|\bpp|\bet al|\by otros|[A-Z])\.$',buf[-8:]):
            res.append(buf);buf='';i+=1
        i+=1
    if buf:res.append(buf)
    return res
def split(p,target=600):
    s=sents(p)
    if len(s)<2:return [p]
    n=max(2,round(len(p)/target))
    n=min(n,len(s))
    chunks=[];cur=''
    goal=len(p)/n
    for x in s:
        if cur and len(cur)>=goal*0.85 and len(chunks)<n-1:
            chunks.append(cur.strip());cur=''
        cur+=(' ' if cur and not cur.endswith(' ') else '')+x.strip() if cur else x.strip()
    chunks.append(cur.strip())
    return chunks
for i,l in enumerate(src):
    ln=i+1
    if ln==3:
        out.append('**Borrador v42 (22-11-2026).** Misma versión que la v41 (dictamen CONFORME, fase 4H), con la redacción reordenada para facilitar la lectura: párrafos largos divididos y el historial de versiones trasladado al anexo G. No cambia ningún dato, cifra ni formulación auditada.')
        continue
    is_body=(14<=ln<=985)
    if is_body and len(l)>900 and not l.lstrip().startswith(('|','-','#','>')) and not re.match(r'^\d+\.',l):
        parts=split(l, 550 if ln==14 else 650)
        for k,pp in enumerate(parts):
            if k: out.append('')
            out.append(pp)
        continue
    out.append(l)
# insert history annex before Bibliografía heading
txt='\n'.join(out)
idx=txt.find('\n## Bibliograf')
annex='\n## Anexo G. Historial de versiones\n\nEl texto siguiente es el encabezamiento de la v41, conservado sin cambios.\n\n'+hist+'\n'
txt=txt[:idx]+annex+txt[idx:]
open(sys.argv[1],'w',encoding='utf-8').write(txt)
