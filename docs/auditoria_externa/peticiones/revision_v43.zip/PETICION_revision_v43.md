# Petición de revisión acotada (fase 4I): artículo I, v41 → v43

## Qué ha cambiado

1. **v42 = v41 con saltos de párrafo.** Solo se dividieron párrafos largos y el historial de versiones pasó al anexo G. Comprobación automática: quitando saltos de párrafo, el encabezamiento y el título del anexo, el texto es idéntico carácter a carácter (`diff_v41_v42_solo_saltos_de_parrafo.patch`; script `comprobacion_v42_igual_a_v41.py`).
2. **v43: presentación del resultado sin valoración propia** (`diff_v42_v43.patch`):
   - Resumen reescrito, más breve; mismas cifras.
   - Síntesis: nueva **tabla S2**, que ordena las seis pruebas de la segunda parte (11.1 a 11.6) de más a menos concluyente, con la dirección en que apunta cada una; «Qué no se afirma» pasa a «Qué no se concluye».
   - 11.7 «Valoración conjunta» se sustituye por 11.9 «Las pruebas, ordenadas».
   - Conclusiones: se abre con una lista de cinco puntos; 12.4 d) remite a la tabla S2; 12.4 f) «Valoración» se sustituye por «Lo que queda abierto», sin la frase «El origen común … es una interpretación compatible con los resultados y merece contraste adicional».
3. **Dos análisis descriptivos nuevos, declarados antes de ejecutar** (declaraciones 17 y 18, commit `97bf5fe`, 22-11-2026 07:25:23 +0100; programas y resultados en commits posteriores, véase `git_log_35c8f27_181c7d6.txt`):
   - **11.7 Mapa de distancias** (`t32_mapa_distancias.py`): 35 lenguas del Wikcionario y el ibérico, todas contra todas, distancia normalizada al estilo LDND (Wichmann y otros 2010), árbol UPGMA. Previsiones: (1) las familias se agrupan → 21 de 24; (2) la lengua más próxima al ibérico es el euskera → 0,45 (turco 0,86). Se informa también de que el tagalo queda a 0,39 del asturiano y del gallego (contacto) y de que la proyección en dos ejes recoge solo el 27 % de la variación; por eso la figura 4 es la matriz ordenada por el árbol (`t32b_figuras_mapa.py`, sin cálculos nuevos, añadido después de ver el resultado y señalado así). Hay una salida declarada no empleada en el texto: la nube de remuestreos en dos ejes, cuyo «vecino más próximo en el plano» no es interpretable por la deformación de la proyección.
   - **11.8 Préstamo conjunto en WOLD** (`t33_prestamo_conjunto_wold.py`, lexibank/wold commit 1df62b9): 0 de 41 lenguas con todos los numerales y la mitad o más de los demás significados prestados (IC 95 % hasta 8,6 %); japonés y tarifit quedan cerca (observación posterior, señalada como tal).

Ningún resultado anterior cambia; los programas t01–t31 no se han tocado.

## Razonamiento del cambio de presentación

Un artículo estadístico no tiene criterio definido para **afirmar** o **negar** una hipótesis: las pruebas dan frecuencias bajo modelos de azar especificados (Wasserstein y Lazar 2016, declaración de la ASA). Las versiones anteriores ya no afirmaban el parentesco, pero cerraban la segunda parte con una valoración del autor («compatible…, merece contraste adicional») y con frases de «preferencia firme» que el lector leía como contradictorias con los resultados parciales. La v43 sustituye la valoración por los resultados ordenados y su dirección, mantiene «no se decide» y deja la ponderación al lector. Es una presentación más restrictiva, no más favorable: se retira la única valoración interpretativa del autor sobre el origen común. Tampoco se ofrece un porcentaje de herencia frente a préstamo, porque exigiría una probabilidad previa no neutral y más parejas de control de las disponibles; así se dice en 11.9.

## Qué se pide

1. Que la tabla S2, el resumen y las conclusiones no afirmen más de lo que sostienen 11.1 a 11.6, y que el orden de concluyencia esté justificado.
2. Que 11.7 y 11.8 se ajusten a las declaraciones 17 y 18 (anterioridad en el grafo de Git; desviaciones señaladas).
3. Dictamen: CONFORME / CONFORME con reservas de redacción / NO CONFORME, con las correcciones concretas.

Contenido del paquete: artículo v43; los dos diffs; script de comprobación; figura 4; log de Git; bundle incremental `35c8f27..181c7d6` (base: estado dictaminado en 4H).
