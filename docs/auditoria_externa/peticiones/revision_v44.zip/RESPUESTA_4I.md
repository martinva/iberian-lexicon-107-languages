# Respuesta a las reservas de la fase 4I (v43 → v44)

Solo cambia el artículo; el repositorio sigue en 775a70d (sin programas ni resultados nuevos respecto a 181c7d6, salvo dos visores HTML en resultados/figuras que leen la misma matriz).

| Reserva 4I | Corrección en v44 |
|---|---|
| S2 como jerarquía de concluyencia y «tres a favor de la herencia» | Título «Qué patrón examina cada prueba y qué permite concluir»; columna «Lectura que sostienen los datos» con tu redacción para cada prueba; se abre con 11.1 y se dice que no hay escala común para ordenar las demás |
| Atribución tagalo, línea 66 | −0,003 tagalo–catalán y 0,055 tagalo–gallego, en la fila de 11.1 |
| Línea 14, «más de cien lenguas» | «de 4 a 32 lenguas, según la fuente; la prueba sin significados abarca 107» |
| Línea 18 y S1, «las lenguas romances pierden la significación» | Gallego y albanés la pierden; el euskera es la única de 31 que la conserva (8.5). También en 12.4 a) |
| Líneas 20, 56, 781, 795 | Sustituidas por tu redacción («…no establecen una preferencia histórica entre herencia y contacto») |
| Línea 823, frase propia tras Akbih Verdaguer | Retirada |
| 11.7, «las familias se agrupan solas» | «21/24 por vecinos (17/24 en la del perfil); no implica ramas exclusivas» |
| 11.7, salida declarada de remuestreos | 32/200 en el plano (yoruba 36/200) y 200/200 sin proyectar, identificado como comprobación posterior de la auditoría |
| 11.7, contacto | «0,387 / 0,390, compatible con los préstamos del castellano; el mapa mide la distancia actual» |
| 27,7 %, 35,0 %, 0,1065, leyenda ≥ 1 (143/630) | Aplicado |
| 11.8, suceso de WOLD | Regla amplia y estricta; intervalo como límite binomial; producto de independencia referido a los 35; tu párrafo de conclusión literal |

Adicional, por iniciativa del autor: en la síntesis, «Revisión externa» declara que la auditoría computacional se hizo con un modelo de lenguaje (ChatGPT) en sesiones independientes y que el jurado fueron tres modelos de lenguaje; queda pendiente una réplica humana.

¿Se levantan las reservas y queda CONFORME la v44?
