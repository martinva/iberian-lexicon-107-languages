#!/usr/bin/env python3
"""Verificación acotada del cierre de 4H: textos, bytes y precedencia en Git.

Uso:
    python verificar_cierre_v41.py --archivos /ruta/adjuntos \
        --repo /ruta/repositorio.git --salida /ruta/evidencias

Requiere Git y un clon que contenga acb66ef. No ejecuta cálculos lingüísticos.
Mantiene intacta la rama del clon: importa el bundle a refs/auditoria/v41.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path
from zipfile import ZipFile

EXPECTED_ZIP = 'edd9b3092313978a0d1229831f4c09f7450ff77e5394e130c83a655f43e3e647'
V40_HASH = '4da4b5cb7945c0ff86c7709fcdfb9f667831f64a2ed380f4b379c0e4cdb1ec91'
OLD = ('Como esa división depende en parte del propio parecido con el euskera, '
       'indica dónde está el parecido, no si la clasificación es independiente; '
       'esa pregunta la responde el jurado ciego.')
NEW = ('Como esa división depende en parte del propio parecido con el euskera, '
       'indica dónde se concentra el parecido, no si la clasificación es independiente. '
       'El jurado ciego aporta una segunda codificación de las fichas, descrita a '
       'continuación; no verifica las fuentes ni certifica la independencia histórica de cada glosa.')

def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archivos', type=Path, required=True)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--salida', type=Path, required=True)
    a = p.parse_args()
    a.salida.mkdir(parents=True, exist_ok=True)
    transcript = []
    def git(*args: str, allowed=(0,)) -> subprocess.CompletedProcess:
        cmd = ['git', '-C', str(a.repo), *args]
        cp = subprocess.run(cmd, capture_output=True)
        transcript.append({'args': list(args), 'codigo': cp.returncode,
                           'stdout': cp.stdout.decode('utf-8', errors='replace'),
                           'stderr': cp.stderr.decode('utf-8', errors='replace')})
        if cp.returncode not in allowed:
            raise RuntimeError(f'Git falló: {args}: {cp.stderr.decode(errors="replace")}')
        return cp
    def show(commit: str, path: str) -> bytes:
        return git('show', f'{commit}:{path}').stdout
    def ancestor(x: str, y: str) -> bool:
        return git('merge-base', '--is-ancestor', x, y, allowed=(0, 1)).returncode == 0

    zipbytes = (a.archivos/'revision_v41.zip').read_bytes()
    assert sha(zipbytes) == EXPECTED_ZIP, 'No coincide el ZIP comunicado.'
    with ZipFile(a.archivos/'revision_v41.zip') as z:
        v41name = next(n for n in z.namelist() if n.startswith('BORRADOR_v41'))
        v41 = z.read(v41name)
        patch = z.read('diff_v40_v41.patch')
        errata = z.read('ERRATAS.md')
        log_delivered = z.read('git_log_acb66ef_35c8f27.txt')
        bundlebytes = z.read('repo_acb66ef_a_35c8f27.bundle')
        inventory = [{'nombre': n, 'sha256': sha(z.read(n)), 'bytes': len(z.read(n))}
                     for n in z.namelist() if not n.endswith('/')]
    with ZipFile(a.archivos/'revision_v40_delta.zip') as z:
        v40name = next(n for n in z.namelist() if n.startswith('BORRADOR_v40'))
        v40 = z.read(v40name)
        t31_previous = {Path(n).name: z.read(n) for n in z.namelist() if n.startswith('t31_')}
    assert sha(v40) == V40_HASH, 'La v40 no coincide con la auditada en 4H.'
    l40, l41 = v40.decode().splitlines(), v41.decode().splitlines()
    assert len(l40) == len(l41)
    changed = [i for i, (x, y) in enumerate(zip(l40, l41), 1) if x != y]
    assert changed == [3, 427, 877], changed
    expected = v40.decode().replace(OLD, NEW).replace(
        'ningún programa del repositorio usa estas siglas',
        'ningún programa lee esta columna del anexo').splitlines()
    expected[2] = l41[2]  # Encabezamiento e historial de versión actualizado.
    assert expected == l41, 'Existen cambios de contenido adicionales.'
    calculated_patch = ''.join(difflib.unified_diff(
        v40.decode().splitlines(True), v41.decode().splitlines(True),
        fromfile=v40name, tofile=v41name))
    assert patch.decode().splitlines()[2:] == calculated_patch.splitlines()[2:]
    (a.salida/'diff_independiente.patch').write_text(calculated_patch)

    with tempfile.TemporaryDirectory() as td:
        bp = Path(td)/'v41.bundle'; bp.write_bytes(bundlebytes)
        git('bundle', 'verify', str(bp))
        git('fetch', str(bp), 'refs/heads/main:refs/auditoria/v41')
    git('fsck', '--full')
    head = git('rev-parse', 'refs/auditoria/v41').stdout.decode().strip()
    assert head.startswith('35c8f27')
    commits = []
    for c in ['acb66ef', '2694d28', 'da4b512', '35c8f27']:
        raw = git('show', '-s', '--format=%H%n%P%n%aI%n%cI%n%s', c).stdout.decode().splitlines()
        commits.append(dict(zip(['hash','padres','fecha_autor','fecha_commit','asunto'],raw)))
    assert ancestor('acb66ef','2694d28') and ancestor('2694d28','da4b512') and ancestor('da4b512',head)
    pre = show('2694d28','resultados/DECLARACIONES_PREVIAS.md')
    post = show('da4b512','resultados/DECLARACIONES_PREVIAS.md')
    assert post.startswith(pre)
    assert b'**Resultado' not in pre.split(b'## 16.',1)[1]
    (a.salida/'declaracion16_previa.txt').write_text('\n'.join(
        f'{i}: {s}' for i,s in enumerate(pre.decode().splitlines(),1) if i>=567)+'\n')
    t31 = []
    for path in ['4_programas/t31_reclasificacion_m4.py',
                 'resultados/t31_reclasificacion_m4.json',
                 'resultados/t31_reclasificacion_m4.log']:
        before = git('cat-file','-e',f'2694d28:{path}',allowed=(0,128)).returncode == 0
        assert not before
        result = show('da4b512',path)
        current = show(head,path)
        assert result == current == t31_previous[Path(path).name]
        t31.append({'archivo':path, 'ausente_en_declaracion':not before,
                    'identico_a_4h_y_sin_cambios':True, 'sha256':sha(current)})
    change_names = git('diff','--name-only','da4b512',head).stdout.decode().splitlines()
    assert change_names == ['ERRATAS.md']
    assert show(head,'ERRATAS.md') == errata
    log = git('log','--format=%h %ad %s','--date=iso',f'acb66ef..{head}').stdout
    assert log == log_delivered
    (a.salida/'git_log_verificado.txt').write_bytes(log)
    report = {
        'dictamen':'CONFORME', 'alcance':'Cierre de la reserva puntual de 4H, artículo I v41',
        'zip_sha256':sha(zipbytes), 'zip_sha256_coincide':True,
        'articulo_v41':v41name,'articulo_v41_sha256':sha(v41),
        'articulo_v40_sha256':sha(v40),'numero_lineas_articulo':len(l41),
        'lineas_modificadas':[3,427,877],
        'solo_encabezamiento_y_dos_correcciones':True,
        'diff_entregado_coincide_con_cotejo_independiente':True,
        'frase_reserva_corregida_exactamente':True,
        'nota_errata_corregida':True, 'erratas_coincide_git':True,
        'inventario_zip':inventory, 'bundle_sha256':sha(bundlebytes),
        'head':head, 'git_fsck_correcto':True,
        'declaracion_antecede_resultado_en_grafo':True,
        'texto_declarado_se_conserva_en_resultado':True,
        'commits':commits, 't31':t31,
        'cambios_repositorio_desde_resultado_t31':change_names,
        'log_entregado_coincide_git':True,
        'programas_linguisticos_reejecutados_en_este_cierre':[],
        'nota_no_bloqueante':{
            'archivo':'resultados/DECLARACIONES_PREVIAS.md',
            'lineas':[567,579,583],
            'horas_escritas_manualmente':['23:05','23:20'],
            'horas_git':['22:56:34+01:00','22:58:41+01:00'],
            'efecto':'Discrepancia editorial de horas; no altera la precedencia documental verificada en el grafo.'}}
    (a.salida/'verificacion_cierre_v41.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    (a.salida/'comandos_git.json').write_text(json.dumps(transcript,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'dictamen': report['dictamen'], 'head':head,
                      'lineas_modificadas':changed, 'anterioridad_verificada':True},ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
