# Cierre de la revisión 4H: artículo I v41

## Dictamen: CONFORME

**Se levanta la reserva puntual de redacción formulada en 4H. El artículo I v41 queda CONFORME dentro del alcance computacional y de concordancia entre resultados y afirmaciones establecido en las auditorías anteriores.** No se reabre la revisión global ni el artículo II.

### 1. Identificación de los materiales

- ZIP recibido: `revision_v41.zip`.
- SHA-256 comprobado: `edd9b3092313978a0d1229831f4c09f7450ff77e5394e130c83a655f43e3e647`. Coincide con el comunicado.
- Artículo: `BORRADOR_v41_articulo_estadistica_2026-11-21.md`.
- SHA-256 del artículo: `324f644ab1f444eda757ebe9aeffe9261b1e468bb5463b1b9c70d0ea0fe260ff`.
- Estado del repositorio verificado: `35c8f2753432db60c8393d2a4cb0667740143471`.

El artículo se identifica por separado del commit: se entrega como documento en el ZIP, no como archivo del árbol Git.

### 2. Cierre de las correcciones de texto

| Punto | Localización | Resultado |
|---|---|---|
| Alcance del jurado ciego | Artículo v41, línea 427 | Se aplica exactamente el texto propuesto en 4H. Declara una segunda codificación de fichas, sin atribuirle verificación de fuentes ni certificación de independencia histórica de las glosas. Reserva cerrada. |
| Alcance de la errata de D.2 | Artículo v41, línea 877 | Dice «ningún programa lee esta columna del anexo». Precisión correcta. |
| Registro de la errata | `ERRATAS.md`, líneas 5 y 7 | La precisión se refleja en español y en inglés; el archivo coincide byte a byte con el del commit verificado. |
| Ausencia de cambios adicionales | Comparación independiente v40/v41 | Solo cambian las líneas 3, 427 y 877: encabezamiento de versión y las dos correcciones declaradas. Las cifras y tablas no cambian. |

El diff entregado coincide con el cotejo independiente, salvo las marcas de fecha de sus dos líneas de cabecera. Se conserva el diff calculado en las evidencias.

La frase corregida dice:

> Como esa división depende en parte del propio parecido con el euskera, indica dónde se concentra el parecido, no si la clasificación es independiente. El jurado ciego aporta una segunda codificación de las fichas, descrita a continuación; no verifica las fuentes ni certifica la independencia histórica de cada glosa.

[Artículo cotejado, con líneas](fuentes/articulo_v41.html#L427).

### 3. Anterioridad de la declaración 16 verificada en Git

Se reconstruyó el repositorio a partir del bundle completo y los incrementales entregados en fases anteriores. Se verificó e incorporó el bundle nuevo y `git fsck --full` terminó sin errores.

| Estado | Commit | Fecha y hora de Git, Madrid (UTC+01:00) |
|---|---|---|
| Declaración 16 | `2694d28b000ae88ceacc49735c7306a0e59854e6` | 21-11-2026, 22:56:34 |
| Incorporación del programa y resultados t31 | `da4b512a4795eb765d6cf25939a2544954135b0d` | 21-11-2026, 22:58:41 |
| Precisión de `ERRATAS.md` | `35c8f2753432db60c8393d2a4cb0667740143471` | 21-11-2026, 23:47:35 |

`git merge-base --is-ancestor 2694d28 da4b512` devuelve éxito. En el estado previo ya está escrito el plan de la entrada 16 y todavía no están el programa, JSON o log de t31. El commit del resultado conserva íntegramente el texto del plan y añade su resultado. Ambos estados son antecesores del estado final. El log entregado coincide exactamente con el obtenido de Git.

**Queda resuelta la limitación documental de 4H:** ahora se ha inspeccionado el grafo y sus contenidos, no solo un parche o una relación de identificadores. Esto acredita precedencia documental interna, no un sello externo de tiempo ni la inexistencia de ensayos no registrados.

**Precisión documental no bloqueante.** Los encabezamientos de la entrada 16 (`resultados/DECLARACIONES_PREVIAS.md:567,579`) escriben 23:05 y la nota de resultado (línea 583) escribe 23:20. No coinciden con las horas de los commits indicadas arriba. El orden verificable en el grafo no cambia; esta discrepancia editorial no mantiene abierta la reserva de redacción ni la anterior limitación de acceso a Git. Para citar la cronología comprobada, deben usarse las horas de Git y distinguirlas de las anotaciones manuales.

### 4. Permanencia de los cálculos de 4H

El programa `4_programas/t31_reclasificacion_m4.py` y sus dos salidas, JSON y log, son idénticos byte a byte a los recibidos y comprobados en 4H. Entre `da4b512` y `35c8f27`, el único archivo modificado del repositorio es `ERRATAS.md`: no cambian programas, datos ni resultados.

No se ha reejecutado t31 en este cierre ni se han generado sorteos nuevos. Se conserva la validación numérica de 4H, sustentada aquí en la identidad de los archivos. No procede declarar una semilla nueva.

### 5. Conclusión

**CONFORME para el artículo I v41 y el estado de repositorio `35c8f27`, dentro del alcance de la auditoría.** La única objeción material de 4H está corregida y la precedencia documental de la declaración 16 queda comprobada. No queda pendiente ninguna condición para levantar aquella reserva.

El dictamen mantiene el alcance ya acordado: reproducibilidad computacional y concordancia de las afirmaciones con los análisis auditados. No constituye certificación filológica de todas las glosas ni demostración de parentesco; esos límites no se transforman en nuevas condiciones de cierre.

### Evidencias y reproducción de esta verificación

El archivo `evidencias/verificacion_cierre_v41.json` contiene hashes, localizaciones, verificaciones de texto y estado Git. `evidencias/comandos_git.json` conserva las órdenes y sus salidas. `programas/verificar_cierre_v41.py` repite estas verificaciones con los adjuntos v40 y v41 y un clon que contenga la base `acb66ef`.
