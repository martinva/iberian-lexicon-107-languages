"""Uso: python cotejar.py RAIZ_REPO > cotejo.json. Solo examina t35 y las cifras de S3.
Reutiliza lector/reductor de NorthEuraLex, no las funciones de t35, t34 ni de perfil.
"""
import sys, json, ast
from pathlib import Path
from collections import Counter
from fractions import Fraction as F
import numpy as np
from scipy.spatial.distance import jensenshannon
r=Path(sys.argv[1]).resolve(); sys.path.insert(0,str(r/'4_programas'))
from ibcomp import fuentes
lex, meta=fuentes.northeuralex(); ids=sorted(lex); names={i:meta[i]['Name'] for i in ids}; inverse={v:k for k,v in names.items()}; fa={i:meta[i]['Family'] for i in ids}; sizes=Counter(fa.values()); actual=json.loads((r/'resultados/t35_perfil_suceso_equivalente.json').read_text()); cols=set(); counters={}
for i in ids:
    c=Counter()
    for w in lex[i]:
        s='^'+w+'$'; c.update(zip(s[:-1],s[1:]))
    counters[i]=c; cols.update(c)
cols=sorted(cols); matrix=np.array([[counters[i][g] for g in cols] for i in ids],dtype=float); matrix/=matrix.sum(1,keepdims=True)
cache={}
def ranking(i):
    if i not in cache:
        d=jensenshannon(matrix,np.broadcast_to(matrix[ids.index(i)],matrix.shape),base=2,axis=1)**2
        cache[i]=[j for _,j in sorted(zip(d,ids)) if j!=i]
    return cache[i]
small=[i for i in ids if sizes[fa[i]]==2]; small3=[i for i in ids if sizes[fa[i]] in (2,3)]
b=[]
for i in small:
    j,=[k for k in small if k!=i and fa[k]==fa[i]]; b.append(dict(lengua=names[i], designada=names[j],familia=fa[i],puesto=ranking(i).index(j)+1))
c=[dict(lengua=names[i],familia=fa[i],mas_proxima=names[ranking(i)[0]],acierto=fa[i]==fa[ranking(i)[0]]) for i in small3]
tree=ast.parse((r/'4_programas/t18_perfil_contacto.py').read_text()); pairs=next(ast.literal_eval(x.value) for x in tree.body if isinstance(x,ast.Assign) and any(isinstance(k,ast.Name) and k.id=='PAREJAS' for k in x.targets)); contact=[dict(toma=x,da=y,puesto=ranking(inverse[x]).index(inverse[y])+1) for x,y in pairs if fa[inverse[x]]!=fa[inverse[y]]]; assert [b,c,contact]==[actual[k] for k in ['emparentadas_R4b','emparentadas_R4c','contacto']]; kc=sum(p['puesto']==1 for p in contact); ratios={}
for label, k,n in [('R4b',sum(row['puesto']==1 for row in b),len(b)),('R4c',sum(row['acierto'] for row in c),len(c))]:
    nc=len(contact); ratio=F(2*k+1,2*n+2)/F(2*kc+1,2*nc+2); seed=20261122+sum(map(ord,label)); rng=np.random.Generator(np.random.PCG64(seed)); q=np.quantile(rng.beta(k+0.5,n-k+0.5,100000)/rng.beta(kc+0.5,nc-kc+0.5,100000),[0.025,0.975]).tolist(); assert [round(x,2) for x in q]==actual[label]['ic95'] and round(float(ratio),2)==actual[label]['razon']; ratios[label]={'razon_exacta':str(ratio),'intervalo':q,'semilla':seed}
prior=[F(1,10),F(1,4),F(1,2),F(3,4),F(9,10)]; out={'conteos':ratios,'emparentadas_b':b,'control':contact,'numero_receptoras':len({x['toma'] for x in contact}),'filas_R4c_comprobadas':len(c),'S3':{str(rr):[float(rr*p/(rr*p+1-p)) for p in prior] for rr in (F(259,110),F(12,5))}}; print(json.dumps(out,ensure_ascii=False,indent=2))
